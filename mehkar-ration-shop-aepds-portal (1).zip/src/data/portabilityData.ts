export interface PortabilityTransaction {
  slNo: number;
  homeFpsId: string;
  rcNo: string;
  scheme: 'AAY' | 'PHH';
  availType: 'Authenticated' | 'Bio' | 'OTP';
  receiptNo: string;
  date: string; // DD-MM-YYYY
  month: string; // October, September, etc.
  year: string; // 2026
  wheatKg: number;
  riceKg: number;
  sugarKg: number;
  foodgrainKitPkts: number;
  anandachaShidhaPkts: number;
  sareePkts: number;
  chanaWholeKg: number;
  kOilKg: number;
  maizeKg: number;
  jowarKg: number;
  bajraKg: number;
  ragiKg: number;
  wheatPmgkayKg: number;
  ricePmgkayKg: number;
  fRiceKg: number;
  pmgkayBagPkts: number;
  amountRs: number;
  portabilityFpsId: string; // The FPS where transaction occurred
  authTransTime: string; // e.g. 00.1149
  cardHolderName?: string;
}

export const OFFICIAL_PORTABILITY_TRANSACTIONS: PortabilityTransaction[] = [
  // Exact row from Screenshot 1 for FPS 150024600320 in October 2026:
  {
    slNo: 1,
    homeFpsId: '150024600320',
    rcNo: '272014430940',
    scheme: 'PHH',
    availType: 'Authenticated',
    receiptNo: '5125278334836485363',
    date: '05-10-2026',
    month: 'October',
    year: '2026',
    wheatKg: 3.000,
    riceKg: 0.000,
    sugarKg: 0.000,
    foodgrainKitPkts: 0.000,
    anandachaShidhaPkts: 0.000,
    sareePkts: 0.000,
    chanaWholeKg: 0.000,
    kOilKg: 0.000,
    maizeKg: 0.000,
    jowarKg: 3.000,
    bajraKg: 0.000,
    ragiKg: 0.000,
    wheatPmgkayKg: 0.000,
    ricePmgkayKg: 0.000,
    fRiceKg: 6.000,
    pmgkayBagPkts: 0.000,
    amountRs: 0.00,
    portabilityFpsId: '150024600323',
    authTransTime: '00.1149',
    cardHolderName: 'GOSIYA PRVIN J.JURGAMUR RHEMAN KHATIK'
  },
  // September Portability Transactions
  {
    slNo: 1,
    homeFpsId: '150024600320',
    rcNo: '272014426720',
    scheme: 'AAY',
    availType: 'Authenticated',
    receiptNo: '5123278334836481105',
    date: '24-09-2026',
    month: 'September',
    year: '2026',
    wheatKg: 11.000,
    riceKg: 0.000,
    sugarKg: 1.000,
    foodgrainKitPkts: 0.000,
    anandachaShidhaPkts: 0.000,
    sareePkts: 0.000,
    chanaWholeKg: 0.000,
    kOilKg: 0.000,
    maizeKg: 0.000,
    jowarKg: 10.000,
    bajraKg: 0.000,
    ragiKg: 0.000,
    wheatPmgkayKg: 0.000,
    ricePmgkayKg: 0.000,
    fRiceKg: 14.000,
    pmgkayBagPkts: 0.000,
    amountRs: 0.00,
    portabilityFpsId: '150024600323',
    authTransTime: '00.2230',
    cardHolderName: 'UZMA ISA KURESHI'
  },
  {
    slNo: 2,
    homeFpsId: '150024600320',
    rcNo: '272014425086',
    scheme: 'PHH',
    availType: 'Authenticated',
    receiptNo: '5123278334836481155',
    date: '28-09-2026',
    month: 'September',
    year: '2026',
    wheatKg: 6.000,
    riceKg: 0.000,
    sugarKg: 0.000,
    foodgrainKitPkts: 0.000,
    anandachaShidhaPkts: 0.000,
    sareePkts: 0.000,
    chanaWholeKg: 0.000,
    kOilKg: 0.000,
    maizeKg: 0.000,
    jowarKg: 6.000,
    bajraKg: 0.000,
    ragiKg: 0.000,
    wheatPmgkayKg: 0.000,
    ricePmgkayKg: 0.000,
    fRiceKg: 8.000,
    pmgkayBagPkts: 0.000,
    amountRs: 0.00,
    portabilityFpsId: '150024600326',
    authTransTime: '00.1912',
    cardHolderName: 'RADHA TUKARAM PAWAR'
  }
];

export function getPortabilityTransactions(fpsId?: string, month?: string, year?: string): PortabilityTransaction[] {
  let list = OFFICIAL_PORTABILITY_TRANSACTIONS;
  if (fpsId && fpsId !== 'ALL') {
    list = list.filter((t) => t.homeFpsId === fpsId || t.portabilityFpsId === fpsId);
  }
  if (month) {
    const cleanM = month.toLowerCase();
    list = list.filter((t) => t.month.toLowerCase().includes(cleanM) || cleanM.includes(t.month.toLowerCase()));
  }
  if (year) {
    list = list.filter((t) => t.year === year);
  }
  return list;
}
