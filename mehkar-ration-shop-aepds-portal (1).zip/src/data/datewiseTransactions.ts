import processedData from './allDatewiseProcessed.json';
import sepTxsRaw from './shopTransactions.json';
import octTxsRaw from './shopTransactionsOct.json';
import officialDayWiseData from './officialDayWiseTrans.json';

const sepTxs: Record<string, any[]> = sepTxsRaw as any;
const octTxs: Record<string, any[]> = octTxsRaw as any;
const officialDayWise: Record<string, any> = officialDayWiseData as any;

function getStoredLiveTransactions(fpsId: string, month: string): any[] {
  if (typeof window === 'undefined' || !window.localStorage) return [];
  try {
    const raw = window.localStorage.getItem('epos_live_transactions_store_v1');
    if (!raw) return [];
    let list: any[] = JSON.parse(raw);
    if (!Array.isArray(list)) return [];
    if (fpsId && fpsId !== 'ALL') {
      list = list.filter((t) => t.fpsId === fpsId || t.portabilityFpsId === fpsId);
    }
    const isOct = month === '2026-10' || month.toLowerCase().includes('oct');
    list = list.filter((t) => {
      if (!t.month && !t.date) return true;
      if (isOct) {
        return t.month === '2026-10' || t.month === 'October' || (t.date && t.date.includes('-10-2026'));
      } else {
        return t.month === '2026-09' || t.month === 'September' || (t.date && t.date.includes('-09-2026'));
      }
    });
    return list;
  } catch (_e) {
    return [];
  }
}

export interface OfficialDayRow {
  slNo: number;
  date: string;
  availedCards: number;
  wheat: number;
  rice: number;
  sugar: number;
  jowar: number;
  fRice: number;
  totalRice: number;
  total: number;
}

export interface DatewiseCommodityRow {
  scheme: 'AAY' | 'PHH';
  date: string;
  availedCards?: number;
  wheat: number;
  rice: number;
  sugar: number;
  jowar: number;
  fRice: number;
  total?: number;
}

export interface DatewiseShopData {
  fpsId: string;
  month: string;
  monthLabel: string;
  officialDays?: OfficialDayRow[];
  officialTotal?: {
    availedCards: number;
    wheat: number;
    rice: number;
    sugar: number;
    jowar: number;
    fRice: number;
    totalRice: number;
    total?: number;
  };
  aayRows: DatewiseCommodityRow[];
  aayTotal: {
    availedCards?: number;
    wheat: number;
    rice: number;
    sugar: number;
    jowar: number;
    fRice: number;
    total: number;
  };
  phhRows: DatewiseCommodityRow[];
  phhTotal: {
    availedCards?: number;
    wheat: number;
    rice: number;
    sugar: number;
    jowar: number;
    fRice: number;
    total: number;
  };
}

export const ALL_DATEWISE: Record<string, Record<string, DatewiseShopData>> =
  processedData as unknown as Record<string, Record<string, DatewiseShopData>>;

export const formatMonthLabel = (monthKey: string): string => {
  const [yearStr, monthStr] = (monthKey || '2026-10').split('-');
  const monthMap: Record<string, { en: string; mr: string }> = {
    '01': { en: 'January', mr: 'जानेवारी' },
    '02': { en: 'February', mr: 'फेब्रुवारी' },
    '03': { en: 'March', mr: 'मार्च' },
    '04': { en: 'April', mr: 'एप्रिल' },
    '05': { en: 'May', mr: 'मे' },
    '06': { en: 'June', mr: 'जून' },
    '07': { en: 'July', mr: 'जुलै' },
    '08': { en: 'August', mr: 'ऑगस्ट' },
    '09': { en: 'September', mr: 'सप्टेंबर' },
    '10': { en: 'October', mr: 'ऑक्टोबर' },
    '11': { en: 'November', mr: 'नोव्हेंबर' },
    '12': { en: 'December', mr: 'डिसेंबर' },
  };
  const m = monthMap[monthStr] || { en: monthStr, mr: monthStr };
  return `${m.en} ${yearStr} (${m.mr} ${yearStr})`;
};

export function getDatewiseShopData(
  fpsId: string,
  month: string = '2026-10',
  _shopsList?: { fpsId: string; aayCards?: number; phhCards?: number }[]
): DatewiseShopData {
  const isOct = month === '2026-10' || month.toLowerCase().includes('oct');
  const baseTxs = isOct ? (octTxs[fpsId] || []) : (sepTxs[fpsId] || []);
  const officialDaysFromSource: OfficialDayRow[] = (officialDayWise as any)[month]?.[fpsId]?.days || [];

  // Helper to get effective FRice for a transaction
  const getTxFRice = (t: any): number => {
    if (t.fRiceKg !== undefined && Number(t.fRiceKg) > 0) return Number(t.fRiceKg);
    if (t.riceKg !== undefined && Number(t.riceKg) > 0) return Number(t.riceKg);
    if (t.scheme === 'AAY') return 14;
    const w = Number(t.wheatKg) || 0;
    return Math.round(w * 2 * 10) / 10 || 6;
  };

  // Helper to format date cleanly as DD-MM-YYYY
  const normalizeDate = (d: string | undefined): string => {
    if (!d) return '';
    if (/^\d{4}-\d{2}-\d{2}/.test(d)) {
      const parts = d.split(' ')[0].split('-');
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
    return d;
  };

  // Merge with live recorded transactions, deduplicating so no card is repeated
  const liveTxs = getStoredLiveTransactions(fpsId, month);
  const baseSrcSet = new Set(baseTxs.map((t: any) => t.srcNo));
  const txList = [...baseTxs];
  liveTxs.forEach((lt) => {
    if (!baseSrcSet.has(lt.srcNo)) {
      txList.push(lt);
    }
  });

  // Build card counts and groupings by date and scheme from transactions
  const aayCardsByDate: Record<string, Set<string>> = {};
  const phhCardsByDate: Record<string, Set<string>> = {};
  const aayTxsByDate: Record<string, any[]> = {};
  const phhTxsByDate: Record<string, any[]> = {};
  const allTxsByDate: Record<string, any[]> = {};
  const allCardsByDate: Record<string, Set<string>> = {};

  txList.forEach((t: any) => {
    const dt = normalizeDate(t.displayDate || t.date);
    if (!dt) return;

    if (!allTxsByDate[dt]) allTxsByDate[dt] = [];
    allTxsByDate[dt].push(t);

    if (!allCardsByDate[dt]) allCardsByDate[dt] = new Set();
    allCardsByDate[dt].add(t.srcNo);

    if (t.scheme === 'AAY') {
      if (!aayCardsByDate[dt]) aayCardsByDate[dt] = new Set();
      aayCardsByDate[dt].add(t.srcNo);
      if (!aayTxsByDate[dt]) aayTxsByDate[dt] = [];
      aayTxsByDate[dt].push(t);
    } else {
      if (!phhCardsByDate[dt]) phhCardsByDate[dt] = new Set();
      phhCardsByDate[dt].add(t.srcNo);
      if (!phhTxsByDate[dt]) phhTxsByDate[dt] = [];
      phhTxsByDate[dt].push(t);
    }
  });

  const aayTotalCards = new Set(txList.filter((t: any) => t.scheme === 'AAY').map((t: any) => t.srcNo)).size;
  const phhTotalCards = new Set(txList.filter((t: any) => t.scheme === 'PHH').map((t: any) => t.srcNo)).size;

  // Check if ALL_DATEWISE has pre-processed data for this shop and month
  const raw = ALL_DATEWISE[fpsId]?.[month];

  let aayRows: DatewiseCommodityRow[] = [];
  let phhRows: DatewiseCommodityRow[] = [];
  let officialDays: OfficialDayRow[] = officialDaysFromSource;

  // If real transactions are available for AAY, dynamically aggregate them
  if (Object.keys(aayTxsByDate).length > 0) {
    aayRows = Object.keys(aayTxsByDate).sort().map((date) => {
      const txs = aayTxsByDate[date];
      const wheat = Math.round(txs.reduce((s, t) => s + (t.wheatKg || 0), 0) * 10) / 10;
      const rice = Math.round(txs.reduce((s, t) => s + (t.riceKg || 0), 0) * 10) / 10;
      const sugar = Math.round(txs.reduce((s, t) => s + (t.sugarKg || 0), 0) * 10) / 10;
      const jowar = Math.round(txs.reduce((s, t) => s + (t.jowarKg || 0), 0) * 10) / 10;
      const fRice = Math.round(txs.reduce((s, t) => s + getTxFRice(t), 0) * 10) / 10;
      const total = Math.round((wheat + fRice + jowar + sugar) * 10) / 10;
      return {
        scheme: 'AAY',
        date,
        availedCards: aayCardsByDate[date]?.size || txs.length,
        wheat,
        rice,
        sugar,
        jowar,
        fRice,
        totalRice: fRice + rice,
        total
      };
    });
  } else if (raw && raw.aayRows && raw.aayRows.length > 0) {
    aayRows = raw.aayRows.map((r) => {
      const distinctCount = aayCardsByDate[r.date]?.size;
      const count = distinctCount !== undefined && distinctCount > 0
        ? distinctCount
        : (r.sugar > 0 ? Math.round(r.sugar) : Math.max(1, Math.round((r.wheat + r.fRice + r.jowar) / 35)));
      const txsOnDate = aayTxsByDate[r.date] || [];
      const txFRice = txsOnDate.length > 0 ? txsOnDate.reduce((s, t) => s + getTxFRice(t), 0) : 0;
      const fRice = r.fRice > 0 ? r.fRice : (txFRice > 0 ? txFRice : (count * 14));
      return {
        ...r,
        fRice,
        totalRice: fRice + (r.rice || 0),
        total: Math.round((r.wheat + fRice + r.jowar + r.sugar) * 10) / 10,
        availedCards: count
      };
    });
  }

  // If real transactions are available for PHH, dynamically aggregate them
  if (Object.keys(phhTxsByDate).length > 0) {
    phhRows = Object.keys(phhTxsByDate).sort().map((date) => {
      const txs = phhTxsByDate[date];
      const wheat = Math.round(txs.reduce((s, t) => s + (t.wheatKg || 0), 0) * 10) / 10;
      const rice = Math.round(txs.reduce((s, t) => s + (t.riceKg || 0), 0) * 10) / 10;
      const sugar = Math.round(txs.reduce((s, t) => s + (t.sugarKg || 0), 0) * 10) / 10;
      const jowar = Math.round(txs.reduce((s, t) => s + (t.jowarKg || 0), 0) * 10) / 10;
      const fRice = Math.round(txs.reduce((s, t) => s + getTxFRice(t), 0) * 10) / 10;
      const total = Math.round((wheat + fRice + jowar + sugar) * 10) / 10;
      return {
        scheme: 'PHH',
        date,
        availedCards: phhCardsByDate[date]?.size || txs.length,
        wheat,
        rice,
        sugar,
        jowar,
        fRice,
        totalRice: fRice + rice,
        total
      };
    });
  } else if (raw && raw.phhRows && raw.phhRows.length > 0) {
    phhRows = raw.phhRows.map((r) => {
      const distinctCount = phhCardsByDate[r.date]?.size;
      const count = distinctCount !== undefined && distinctCount > 0
        ? distinctCount
        : Math.max(1, Math.round((r.wheat + r.fRice + r.jowar) / 20));
      const txsOnDate = phhTxsByDate[r.date] || [];
      const txFRice = txsOnDate.length > 0 ? txsOnDate.reduce((s, t) => s + getTxFRice(t), 0) : 0;
      const fRice = r.fRice > 0 ? r.fRice : (txFRice > 0 ? txFRice : (Math.round((r.wheat || 3) * 2 * 10) / 10));
      return {
        ...r,
        fRice,
        totalRice: fRice + (r.rice || 0),
        total: Math.round((r.wheat + fRice + r.jowar + r.sugar) * 10) / 10,
        availedCards: count
      };
    });
  }

  // Dynamically construct officialDays whenever we have transactions
  if (Object.keys(allTxsByDate).length > 0) {
    officialDays = Object.keys(allTxsByDate).sort().map((date, idx) => {
      const txs = allTxsByDate[date];
      const wheat = Math.round(txs.reduce((s, t) => s + (t.wheatKg || 0), 0) * 10) / 10;
      const rice = Math.round(txs.reduce((s, t) => s + (t.riceKg || 0), 0) * 10) / 10;
      const sugar = Math.round(txs.reduce((s, t) => s + (t.sugarKg || 0), 0) * 10) / 10;
      const jowar = Math.round(txs.reduce((s, t) => s + (t.jowarKg || 0), 0) * 10) / 10;
      const fRice = Math.round(txs.reduce((s, t) => s + getTxFRice(t), 0) * 10) / 10;
      const totalRice = Math.round((rice + fRice) * 10) / 10;
      const total = Math.round((wheat + totalRice + jowar + sugar) * 10) / 10;
      return {
        slNo: idx + 1,
        date,
        availedCards: allCardsByDate[date]?.size || txs.length,
        wheat,
        rice,
        sugar,
        jowar,
        fRice,
        totalRice,
        total
      };
    });
  }

  // Compute Totals
  const aayTotal = {
    availedCards: aayTotalCards > 0 ? aayTotalCards : aayRows.reduce((sum, r) => sum + (r.availedCards || 0), 0),
    wheat: Math.round(aayRows.reduce((sum, r) => sum + r.wheat, 0) * 10) / 10,
    rice: Math.round(aayRows.reduce((sum, r) => sum + r.rice, 0) * 10) / 10,
    sugar: Math.round(aayRows.reduce((sum, r) => sum + r.sugar, 0) * 10) / 10,
    jowar: Math.round(aayRows.reduce((sum, r) => sum + r.jowar, 0) * 10) / 10,
    fRice: Math.round(aayRows.reduce((sum, r) => sum + r.fRice, 0) * 10) / 10,
    total: Math.round(aayRows.reduce((sum, r) => sum + (r.total || 0), 0) * 10) / 10
  };

  const phhTotal = {
    availedCards: phhTotalCards > 0 ? phhTotalCards : phhRows.reduce((sum, r) => sum + (r.availedCards || 0), 0),
    wheat: Math.round(phhRows.reduce((sum, r) => sum + r.wheat, 0) * 10) / 10,
    rice: Math.round(phhRows.reduce((sum, r) => sum + r.rice, 0) * 10) / 10,
    sugar: Math.round(phhRows.reduce((sum, r) => sum + r.sugar, 0) * 10) / 10,
    jowar: Math.round(phhRows.reduce((sum, r) => sum + r.jowar, 0) * 10) / 10,
    fRice: Math.round(phhRows.reduce((sum, r) => sum + r.fRice, 0) * 10) / 10,
    total: Math.round(phhRows.reduce((sum, r) => sum + (r.total || 0), 0) * 10) / 10
  };

  const officialTotal = {
    availedCards: officialDays.reduce((sum, d) => sum + (d.availedCards || 0), 0),
    wheat: Math.round(officialDays.reduce((sum, d) => sum + (d.wheat || 0), 0) * 10) / 10,
    rice: Math.round(officialDays.reduce((sum, d) => sum + (d.rice || 0), 0) * 10) / 10,
    sugar: Math.round(officialDays.reduce((sum, d) => sum + (d.sugar || 0), 0) * 10) / 10,
    jowar: Math.round(officialDays.reduce((sum, d) => sum + (d.jowar || 0), 0) * 10) / 10,
    fRice: Math.round(officialDays.reduce((sum, d) => sum + (d.fRice || 0), 0) * 10) / 10,
    totalRice: Math.round(officialDays.reduce((sum, d) => sum + (d.totalRice || 0), 0) * 10) / 10,
    total: Math.round(officialDays.reduce((sum, d) => sum + (d.total || 0), 0) * 10) / 10
  };

  return {
    fpsId,
    month,
    monthLabel: formatMonthLabel(month),
    officialDays,
    officialTotal,
    aayRows,
    aayTotal,
    phhRows,
    phhTotal
  };
}
