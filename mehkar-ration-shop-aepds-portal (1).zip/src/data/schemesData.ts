import { EposSchemeData, EposDateSale } from '../types/epos.js';

export const MEHKAR_SCHEMES: EposSchemeData[] = [
  {
    schemeCode: 'PMGKAY_PHH',
    schemeNameMr: 'प्रधानमंत्री गरीब कल्याण अन्न योजना (PHH - प्राधान्य कुटुंब)',
    schemeNameEn: 'PMGKAY - Priority Household (NFSA)',
    description: 'प्रति व्यक्ती ५ किलो मोफत अन्नधान्य (३ किलो गहू + २ किलो तांदूळ)',
    totalBeneficiaries: 38450,
    allotmentMt: 192.25,
    distributedMt: 154.80,
    balanceMt: 37.45,
    percentage: 80.52,
    commodities: [
      { nameMr: 'गहू (Wheat)', ratePerKg: 'मोफत (₹०)', quota: '११५.३५ मे.टन', distributed: '९२.८० मे.टन' },
      { nameMr: 'तांदूळ / फोर्टिफाइड (Rice)', ratePerKg: 'मोफत (₹०)', quota: '७६.९० मे.टन', distributed: '६२.०० मे.टन' }
    ]
  },
  {
    schemeCode: 'PMGKAY_AAY',
    schemeNameMr: 'अंत्योदय अन्न योजना (AAY - पिवळे कार्डधारक)',
    schemeNameEn: 'Antyodaya Anna Yojana (AAY)',
    description: 'प्रति शिधापत्रिका ३५ किलो मोफत अन्नधान्य (१४ किलो गहू + २१ किलो तांदूळ)',
    totalBeneficiaries: 7820,
    allotmentMt: 273.70,
    distributedMt: 232.65,
    balanceMt: 41.05,
    percentage: 85.00,
    commodities: [
      { nameMr: 'गहू (Wheat)', ratePerKg: 'मोफत (₹०)', quota: '१०९.४८ मे.टन', distributed: '९३.०६ मे.टन' },
      { nameMr: 'तांदूळ (Rice)', ratePerKg: 'मोफत (₹०)', quota: '१६४.२२ मे.टन', distributed: '१३९.५९ मे.टन' },
      { nameMr: 'साखर (Sugar)', ratePerKg: '₹२० / किलो', quota: '७.८२ मे.टन', distributed: '६.९५ मे.टन' }
    ]
  },
  {
    schemeCode: 'ANANDACHA_SHIDHA',
    schemeNameMr: 'आनंदाचा शिधा (सणासुदीचे विशेष पॅकेट)',
    schemeNameEn: 'Anandacha Shidha Special Kit',
    description: 'रवा १ किलो, चणाडाळ १ किलो, साखर १ किलो, पामतेल १ लिटर पॅकेट',
    totalBeneficiaries: 46270,
    allotmentMt: 185.08,
    distributedMt: 168.42,
    balanceMt: 16.66,
    percentage: 91.00,
    commodities: [
      { nameMr: 'चणाडाळ (१ किलो)', ratePerKg: 'किटमध्ये समाविष्ट', quota: '४६,२७० पाकिटे', distributed: '४२,१०५ पाकिटे' },
      { nameMr: 'साखर (१ किलो)', ratePerKg: 'किटमध्ये समाविष्ट', quota: '४६,२७० पाकिटे', distributed: '४२,१०५ पाकिटे' },
      { nameMr: 'रवा (१ किलो)', ratePerKg: 'किटमध्ये समाविष्ट', quota: '४६,२७० पाकिटे', distributed: '४२,१०५ पाकिटे' },
      { nameMr: 'खाद्यतेल (१ लिटर)', ratePerKg: 'किटमध्ये समाविष्ट', quota: '४६,२७० पाकिटे', distributed: '४२,१०५ पाकिटे' }
    ]
  },
  {
    schemeCode: 'NON_NFSA_APL',
    schemeNameMr: 'एपीएल शेतकरी योजना (नॉन-एनएफएसए केशरी कार्डे)',
    schemeNameEn: 'Non-NFSA APL Farmer Scheme',
    description: 'दुष्काळग्रस्त व आत्महत्याग्रस्त भागातील केशरी शिधापत्रिकाधारकांना सवलतीच्या दरात अन्नधान्य',
    totalBeneficiaries: 12540,
    allotmentMt: 62.70,
    distributedMt: 48.30,
    balanceMt: 14.40,
    percentage: 77.03,
    commodities: [
      { nameMr: 'गहू (Wheat)', ratePerKg: '₹२ / किलो', quota: '३७.६२ मे.टन', distributed: '२८.९८ मे.टन' },
      { nameMr: 'तांदूळ (Rice)', ratePerKg: '₹३ / किलो', quota: '२५.०८ मे.टन', distributed: '१९.३२ मे.टन' }
    ]
  }
];

export const MEHKAR_DATEWISE: EposDateSale[] = Array.from({ length: 30 }, (_, i) => {
  const day = i + 1;
  const isWeekend = (day % 7 === 0) || (day % 7 === 6);
  const baseTrans = day <= 15 ? 3200 - day * 80 : 1800 - (day - 15) * 45;
  const variance = (day * 13) % 150;
  const transactions = Math.max(120, baseTrans + (isWeekend ? -250 : variance));
  const activeShops = Math.min(185, Math.max(30, 95 - Math.floor(day * 1.5) + (isWeekend ? -20 : (day % 5))));
  
  return {
    date: `2026-09-${String(day).padStart(2, '0')}`,
    day,
    transactions,
    activeShops,
    wheatDistributedKg: Math.round(transactions * 14.5),
    riceDistributedKg: Math.round(transactions * 10.2),
    sugarDistributedKg: Math.round(transactions * 1.8),
    peakHour: day % 2 === 0 ? '०८:०० ते ११:०० AM' : '०९:३० ते १२:३० PM'
  };
});
