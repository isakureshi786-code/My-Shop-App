import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Store,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Clock,
  Search,
  Edit3,
  Eye,
  EyeOff,
  Power,
  PlusCircle,
  RefreshCw,
  Sliders,
  DollarSign,
  UserCheck,
  UserX,
  Package,
  Layers,
  Save,
  X,
  Filter,
  Check,
  Trash2,
  MessageCircle,
  Phone
} from 'lucide-react';
import { DealerAccount, PaymentRecord, UserSession } from '../types/auth.js';
import {
  getRegisteredAccounts,
  setAccountActiveStatus,
  updateDealerAccount,
  getAllPayments,
  approvePayment,
  rejectPayment,
  addManualPayment,
  updatePaymentRecord,
  deletePaymentRecord,
  saveCustomShopStock,
  getPaymentRecipient,
  savePaymentRecipient,
  PAYMENT_RECIPIENT,
  OWNER_CREDENTIALS,
  SUPPORT_CONTACT
} from '../services/authService.js';
import { EposShop } from '../types/epos.js';
import { BUNDLED_SHOPS } from '../services/eposClientData.js';

interface OwnerDashboardProps {
  userSession: UserSession;
  shops: EposShop[];
  onUpdateShops: (updatedShops: EposShop[]) => void;
  onRefreshShops?: () => Promise<void> | void;
  onLogout: () => void;
  onSwitchToShopView: () => void;
  lang?: 'mr' | 'hi' | 'en';
}

export const OwnerDashboard: React.FC<OwnerDashboardProps> = ({
  userSession,
  shops,
  onUpdateShops,
  onRefreshShops,
  onLogout,
  onSwitchToShopView,
  lang = 'mr'
}) => {
  const [activeTab, setActiveTab] = useState<'dealers' | 'payments'>('dealers');
  const [accounts, setAccounts] = useState<DealerAccount[]>(() => getRegisteredAccounts());
  const [payments, setPayments] = useState<PaymentRecord[]>(() => getAllPayments());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'deactive' | 'paid'>('all');
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Recipient Payment Details State (Payee Name & UPI ID change option for Owner)
  const [recipientConfig, setRecipientConfig] = useState(() => getPaymentRecipient());
  const [isEditRecipientOpen, setIsEditRecipientOpen] = useState(false);
  const [recipientForm, setRecipientForm] = useState({
    payeeName: '',
    upiId: '',
    monthlyFee: 100,
    note: '',
    phone: '7709229567',
    whatsapp: '7709229567'
  });

  // Password visibility map for accounts
  const [revealedPasswords, setRevealedPasswords] = useState<Record<string, boolean>>({});

  // Edit Account / Shop Modal State
  const [editingAccount, setEditingAccount] = useState<DealerAccount | null>(null);
  const [editFormData, setEditFormData] = useState({
    dealerName: '',
    gmailId: '',
    password: '',
    shopAddress: '',
    totalCards: 500,
    aayCards: 78,
    phhCards: 422,
    extendDays: 0
  });

  // Edit Payment Modal State (Change Payer Name, Real UTR, Amount, Shop/FPS ID, Status)
  const [editingPayment, setEditingPayment] = useState<PaymentRecord | null>(null);
  const [editPaymentForm, setEditPaymentForm] = useState({
    dealerName: '',
    utr: '',
    amount: 100,
    fpsId: '',
    status: 'SUCCESS' as 'SUCCESS' | 'PENDING' | 'REJECTED',
    method: 'UPI' as 'UPI' | 'CASH',
    planDurationMonths: 1,
    date: ''
  });

  // Manual Payment Modal State
  const [isManualPayOpen, setIsManualPayOpen] = useState(false);
  const [manualPayShopId, setManualPayShopId] = useState('');
  const [manualPayAmount, setManualPayAmount] = useState(100);
  const [manualPayUtr, setManualPayUtr] = useState('');
  const [manualPayMethod, setManualPayMethod] = useState<'UPI' | 'CASH'>('UPI');
  const [manualPayMonths, setManualPayMonths] = useState(1);

  // Refresh data: ensure 100% of Mehkar shops (all 14 shops) are visible in Owner Admin Portal ("पुरे दुकान दिखना")
  const refreshAllData = () => {
    const freshAccounts = getRegisteredAccounts();
    const existingIds = new Set(freshAccounts.map((a) => a.fpsId));
    const allKnownShops = (shops && shops.length >= 14) ? shops : BUNDLED_SHOPS;
    const extraFromShops: DealerAccount[] = allKnownShops
      .filter((s) => !existingIds.has(s.fpsId))
      .map((s) => ({
        fpsId: s.fpsId,
        gmailId: '',
        password: '',
        dealerName: s.dealerName,
        shopAddress: s.area || 'मेहकर शहर, जि. बुलढाणा',
        totalCards: s.totalCards || 500,
        aayCards: s.aayCards || 78,
        phhCards: s.phhCards || 422,
        isRegistered: false,
        registeredAt: '',
        trialEndsAt: '',
        isSubscribed: false,
        isActive: true,
        payments: []
      }));
    const fullMerged = [...freshAccounts, ...extraFromShops];
    // Sort neatly by FPS ID
    fullMerged.sort((a, b) => a.fpsId.localeCompare(b.fpsId));
    const freshPayments = getAllPayments();
    setAccounts(fullMerged);
    setPayments(freshPayments);
    setRecipientConfig(getPaymentRecipient());
  };

  useEffect(() => {
    refreshAllData();
  }, []);

  // Open Edit Recipient Modal (Payee Name & UPI ID)
  const handleOpenEditRecipient = () => {
    const current = getPaymentRecipient();
    setRecipientForm({
      payeeName: current.payeeName,
      upiId: current.upiId,
      monthlyFee: current.monthlyFee || 100,
      note: current.note || '',
      phone: current.phone || '7709229567',
      whatsapp: current.whatsapp || '7709229567'
    });
    setIsEditRecipientOpen(true);
  };

  // Save Recipient Changes (Payee Name & UPI ID)
  const handleSaveRecipient = (e: React.FormEvent) => {
    e.preventDefault();
    const res = savePaymentRecipient(recipientForm);
    if (res.success) {
      setRecipientConfig(res.data);
      showToast(res.message, 'success');
      setIsEditRecipientOpen(false);
    } else {
      showToast(res.message, 'error');
    }
  };

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Explicit Manual Refresh with tactile UI feedback
  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      if (onRefreshShops) {
        await onRefreshShops();
      }
      refreshAllData();
      showToast('सर्व १४ दुकाने, पेमेंट व स्टॉक डेटा यशस्वीरीत्या रीफ्रेश झाला!', 'success');
    } catch (_e) {
      showToast('डेटा रीफ्रेश झाला.', 'success');
    } finally {
      setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  // Toggle ID Active / Deactive
  const handleToggleActive = (account: DealerAccount) => {
    const newStatus = !account.isActive;
    const res = setAccountActiveStatus(account.fpsId, newStatus);
    if (res.success) {
      showToast(res.message, newStatus ? 'success' : 'error');
      refreshAllData();
    } else {
      showToast(res.message, 'error');
    }
  };

  // Open Edit Modal for Dealer & Shop
  const handleOpenEdit = (account: DealerAccount) => {
    const shopInList = shops.find((s) => s.fpsId === account.fpsId);
    setEditingAccount(account);
    setEditFormData({
      dealerName: account.dealerName || shopInList?.dealerName || '',
      gmailId: account.gmailId || '',
      password: account.password || '123456',
      shopAddress: account.shopAddress || shopInList?.area || '',
      totalCards: account.totalCards || shopInList?.totalCards || 500,
      aayCards: account.aayCards || shopInList?.aayCards || 78,
      phhCards: account.phhCards || shopInList?.phhCards || 422,
      extendDays: 0
    });
  };

  // Save Edit Form
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAccount) return;

    let newSubEnd = editingAccount.subscriptionEndsAt;
    let isSub = editingAccount.isSubscribed;
    if (editFormData.extendDays > 0) {
      const baseTime = editingAccount.subscriptionEndsAt && new Date(editingAccount.subscriptionEndsAt).getTime() > Date.now()
        ? new Date(editingAccount.subscriptionEndsAt).getTime()
        : Date.now();
      newSubEnd = new Date(baseTime + editFormData.extendDays * 86400000).toISOString();
      isSub = true;
    }

    const updates: Partial<DealerAccount> = {
      dealerName: editFormData.dealerName.trim(),
      gmailId: editFormData.gmailId.trim().toLowerCase(),
      password: editFormData.password.trim(),
      shopAddress: editFormData.shopAddress.trim(),
      totalCards: Number(editFormData.totalCards),
      aayCards: Number(editFormData.aayCards),
      phhCards: Number(editFormData.phhCards),
      isSubscribed: isSub,
      subscriptionEndsAt: newSubEnd
    };

    const res = updateDealerAccount(editingAccount.fpsId, updates);
    if (res.success) {
      // Permanently persist custom edits to localStorage
      saveCustomShopStock(editingAccount.fpsId, {
        dealerName: editFormData.dealerName.trim(),
        shopAddress: editFormData.shopAddress.trim(),
        totalCards: Number(editFormData.totalCards),
        aayCards: Number(editFormData.aayCards),
        phhCards: Number(editFormData.phhCards)
      });

      // Also update shop in shops array
      const updatedShops = shops.map((s) => {
        if (s.fpsId === editingAccount.fpsId) {
          return {
            ...s,
            dealerName: editFormData.dealerName.trim(),
            totalCards: Number(editFormData.totalCards),
            aayCards: Number(editFormData.aayCards),
            phhCards: Number(editFormData.phhCards),
            area: editFormData.shopAddress.trim()
          };
        }
        return s;
      });
      onUpdateShops(updatedShops);

      showToast(res.message, 'success');
      setEditingAccount(null);
      refreshAllData();
    } else {
      showToast(res.message, 'error');
    }
  };

  // Open Edit Payment Modal
  const handleOpenEditPayment = (p: PaymentRecord) => {
    setEditingPayment(p);
    setEditPaymentForm({
      dealerName: p.dealerName || '',
      utr: p.utr || '',
      amount: p.amount || 100,
      fpsId: p.fpsId || '',
      status: p.status || 'SUCCESS',
      method: (p.method as any) || 'UPI',
      planDurationMonths: p.planDurationMonths || 1,
      date: p.date ? p.date.substring(0, 10) : new Date().toISOString().substring(0, 10)
    });
  };

  // Save Payment Edit Form
  const handleSavePaymentEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPayment) return;
    const res = updatePaymentRecord(editingPayment.id || '', editPaymentForm);
    if (res.success) {
      showToast(res.message, 'success');
      setEditingPayment(null);
      refreshAllData();
    } else {
      showToast(res.message, 'error');
    }
  };

  // Delete Payment Record
  const handleDeletePayment = (payment: PaymentRecord) => {
    if (!window.confirm(`खरोखर ही पेमेंट नोंद (UTR: ${payment.utr}, ₹${payment.amount}) हटवायची आहे का?`)) {
      return;
    }
    const res = deletePaymentRecord(payment.id || '');
    if (res.success) {
      showToast(res.message, 'success');
      refreshAllData();
    } else {
      showToast(res.message, 'error');
    }
  };

  // Handle Approve Payment
  const handleApprovePayment = (payment: PaymentRecord) => {
    const res = approvePayment(payment.fpsId, payment.utr || '');
    if (res.success) {
      showToast(res.message, 'success');
      refreshAllData();
    } else {
      showToast(res.message, 'error');
    }
  };

  // Handle Reject Payment
  const handleRejectPayment = (payment: PaymentRecord) => {
    const reason = window.prompt('पेमेंट नाकारण्याचे कारण टाका (Reason for rejection):', 'बँक खात्यात रक्कम जमा झालेली नाही');
    if (reason === null) return;
    const res = rejectPayment(payment.fpsId, payment.utr || '', reason);
    if (res.success) {
      showToast(res.message, 'error');
      refreshAllData();
    }
  };

  // Submit Manual Payment
  const handleSubmitManualPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualPayShopId) {
      showToast('कृपया दुकान निवडा.', 'error');
      return;
    }
    const res = addManualPayment(
      manualPayShopId,
      manualPayAmount,
      manualPayMethod,
      manualPayUtr || `OFFLINE-${Date.now().toString().slice(-6)}`,
      manualPayMonths
    );
    if (res.success) {
      showToast(res.message, 'success');
      setIsManualPayOpen(false);
      setManualPayUtr('');
      refreshAllData();
    } else {
      showToast(res.message, 'error');
    }
  };

  // Calculations
  const totalAccounts = accounts.length;
  const activeCount = accounts.filter((a) => a.isActive !== false).length;
  const deactiveCount = accounts.filter((a) => a.isActive === false).length;
  const totalSuccessPayments = payments.filter((p) => p.status === 'SUCCESS');
  const totalRevenue = totalSuccessPayments.reduce((acc, p) => acc + (p.amount || 0), 0);
  const pendingPaymentsCount = payments.filter((p) => p.status === 'PENDING').length;

  // Filter accounts
  const filteredAccounts = accounts.filter((acc) => {
    const q = searchQuery.toLowerCase();
    const matchQuery =
      acc.fpsId.includes(q) ||
      acc.dealerName?.toLowerCase().includes(q) ||
      acc.gmailId?.toLowerCase().includes(q);

    if (!matchQuery) return false;

    if (statusFilter === 'active') return acc.isActive !== false;
    if (statusFilter === 'deactive') return acc.isActive === false;
    if (statusFilter === 'paid') return acc.isSubscribed;
    return true;
  });

  return (
    <div className="space-y-5 font-sans animate-in fade-in">
      {/* Toast Alert */}
      {toastMessage && (
        <div
          className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-xs sm:text-sm font-bold font-devanagari animate-in slide-in-from-top-3 ${
            toastMessage.type === 'success'
              ? 'bg-emerald-900 text-white border-emerald-500'
              : 'bg-rose-900 text-white border-rose-500'
          }`}
        >
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-300 shrink-0" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Owner Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 text-white rounded-3xl p-5 sm:p-6 shadow-xl border border-amber-500/30">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 text-slate-950 flex items-center justify-center font-black shadow-lg border-2 border-white/30 shrink-0">
              <span className="text-2xl">👑</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black font-devanagari text-white tracking-tight">
                  मालक नियंत्रण पॅनेल (Owner Admin Portal)
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950 border border-amber-300 shadow-xs">
                  सुपर ॲडमिन
                </span>
              </div>
              <p className="text-xs text-amber-200/90 font-medium font-devanagari mt-0.5">
                सर्व दुकाने, आयडी ऍक्टिव्ह/डेअक्टिव्ह, डेटा संपादन व पेमेंट मंजुरी व्यवस्थापन · {OWNER_CREDENTIALS.name}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleManualRefresh}
              disabled={isRefreshing}
              className={`px-3.5 py-2 rounded-xl border text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95 ${
                isRefreshing
                  ? 'bg-amber-600/80 border-amber-400 cursor-not-allowed text-amber-100'
                  : 'bg-white/15 hover:bg-white/25 border-white/25'
              }`}
              title="डेटा रीफ्रेश करा"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-300' : 'text-white'}`} />
              <span>{isRefreshing ? 'रीफ्रेश होत आहे...' : 'रीफ्रेश'}</span>
            </button>
            <a
              href={SUPPORT_CONTACT.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 border border-emerald-400 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
              title="WhatsApp सपोर्ट उघडा"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp मदत: {SUPPORT_CONTACT.phone}</span>
            </a>
            <button
              type="button"
              onClick={handleOpenEditRecipient}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
              title="खातेदार नाव (Payee Name) व UPI ID बदला"
            >
              <CreditCard className="w-4 h-4" />
              <span>खातेदार व UPI ID बदला</span>
            </button>
            <button
              type="button"
              onClick={() => setIsManualPayOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <PlusCircle className="w-4 h-4" />
              <span>मॅन्युअल पेमेंट जोडा</span>
            </button>
            <button
              type="button"
              onClick={onSwitchToShopView}
              className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Store className="w-4 h-4" />
              <span>दुकानदार ॲप पहा</span>
            </button>
            <button
              type="button"
              onClick={onLogout}
              className="px-3 py-2 rounded-xl bg-rose-900/60 hover:bg-rose-800 border border-rose-500/50 text-rose-100 text-xs font-bold transition-all cursor-pointer"
            >
              <span>बाहेर पडा (Logout)</span>
            </button>
          </div>
        </div>

        {/* 5 High-Impact Stat Tiles */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mt-5 pt-4 border-t border-amber-500/20">
          {/* Card 1 */}
          <div className="bg-black/30 backdrop-blur-sm p-3 rounded-2xl border border-white/10">
            <div className="text-[11px] font-bold text-amber-200/80 font-devanagari">एकूण दुकाने (सर्व १४ दुकाने)</div>
            <div className="text-xl sm:text-2xl font-black font-mono text-white mt-0.5">{totalAccounts}</div>
            <div className="text-[10px] text-slate-400 mt-0.5">मेहकर शहर व परिसर</div>
          </div>

          {/* Card 2 */}
          <div className="bg-emerald-950/40 backdrop-blur-sm p-3 rounded-2xl border border-emerald-500/30">
            <div className="text-[11px] font-bold text-emerald-300 font-devanagari flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>सक्रिय आयडी (Active)</span>
            </div>
            <div className="text-xl sm:text-2xl font-black font-mono text-emerald-300 mt-0.5">{activeCount}</div>
            <div className="text-[10px] text-emerald-200/70 mt-0.5">लॉगिन सुरू आहे</div>
          </div>

          {/* Card 3 */}
          <div className="bg-rose-950/40 backdrop-blur-sm p-3 rounded-2xl border border-rose-500/30">
            <div className="text-[11px] font-bold text-rose-300 font-devanagari flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              <span>निष्क्रिय आयडी (Deactive)</span>
            </div>
            <div className="text-xl sm:text-2xl font-black font-mono text-rose-300 mt-0.5">{deactiveCount}</div>
            <div className="text-[10px] text-rose-200/70 mt-0.5">लॉगिन बंद केले</div>
          </div>

          {/* Card 4 */}
          <div className="bg-amber-950/40 backdrop-blur-sm p-3 rounded-2xl border border-amber-500/30">
            <div className="text-[11px] font-bold text-amber-300 font-devanagari">एकूण जमा वर्गणी</div>
            <div className="text-xl sm:text-2xl font-black font-mono text-amber-300 mt-0.5">₹ {totalRevenue.toLocaleString('en-IN')}</div>
            <div className="text-[10px] text-amber-200/70 mt-0.5">{totalSuccessPayments.length} यशस्वी पेमेंट्स</div>
          </div>

          {/* Card 5 */}
          <div className="bg-blue-950/40 backdrop-blur-sm p-3 rounded-2xl border border-blue-500/30 col-span-2 sm:col-span-1">
            <div className="text-[11px] font-bold text-blue-300 font-devanagari">पडताळणी प्रलंबित (Pending)</div>
            <div className="text-xl sm:text-2xl font-black font-mono text-blue-300 mt-0.5">{pendingPaymentsCount}</div>
            <div className="text-[10px] text-blue-200/70 mt-0.5">मंजुरीची वाट पाहत आहे</div>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap gap-1 font-devanagari">
        <button
          type="button"
          onClick={() => setActiveTab('dealers')}
          className={`flex-1 min-w-[140px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'dealers'
              ? 'bg-amber-700 text-white shadow-md'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>१. दुकानदार व आयडी नियंत्रण ({accounts.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('payments')}
          className={`flex-1 min-w-[140px] py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer relative ${
            activeTab === 'payments'
              ? 'bg-amber-700 text-white shadow-md'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>२. सर्व पेमेंट रजिस्टर ({payments.length})</span>
          {pendingPaymentsCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-rose-500 text-white animate-pulse">
              {pendingPaymentsCount}
            </span>
          )}
        </button>
      </div>

      {/* ============================================================== */}
      {/* TAB 1: DEALERS & ID ACTIVE / DEACTIVE MANAGEMENT */}
      {/* ============================================================== */}
      {activeTab === 'dealers' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
            <div className="relative w-full sm:w-80">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="दुकान आयडी, नाव किंवा Gmail शोधा..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-800 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            </div>

            <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
              <button
                type="button"
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-colors whitespace-nowrap ${
                  statusFilter === 'all'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                सर्व ({accounts.length})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('active')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-colors whitespace-nowrap flex items-center gap-1 ${
                  statusFilter === 'active'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                }`}
              >
                <span>सक्रिय ({activeCount})</span>
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('deactive')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-colors whitespace-nowrap flex items-center gap-1 ${
                  statusFilter === 'deactive'
                    ? 'bg-rose-700 text-white'
                    : 'bg-rose-50 text-rose-800 border border-rose-200'
                }`}
              >
                <span>निष्क्रिय ({deactiveCount})</span>
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('paid')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-colors whitespace-nowrap ${
                  statusFilter === 'paid'
                    ? 'bg-amber-600 text-white'
                    : 'bg-amber-50 text-amber-900 border border-amber-200'
                }`}
              >
                वर्गणी चालू
              </button>
            </div>
          </div>

          {/* Dealers List */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {filteredAccounts.map((account) => {
              const isPasswordVisible = revealedPasswords[account.fpsId] || false;
              const isActive = account.isActive !== false;

              return (
                <div
                  key={account.fpsId}
                  className={`bg-white rounded-3xl border transition-all shadow-sm overflow-hidden flex flex-col justify-between ${
                    isActive
                      ? 'border-slate-200 hover:border-amber-400'
                      : 'border-rose-300 bg-rose-50/30'
                  }`}
                >
                  <div className="p-4 space-y-3">
                    {/* Top Row: FPS ID & Active/Deactive Badge */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-9 h-9 rounded-xl text-white font-mono font-black text-xs flex items-center justify-center shrink-0 ${
                            isActive ? 'bg-amber-800' : 'bg-rose-700'
                          }`}
                        >
                          {account.fpsId.slice(-3)}
                        </div>
                        <div>
                          <span className="font-mono font-black text-xs text-slate-900 block">
                            FPS: {account.fpsId}
                          </span>
                        </div>
                      </div>

                      {/* Prominent Active/Deactive Badge */}
                      <span
                        className={`px-2 py-1 rounded-xl text-[11px] font-black border flex items-center gap-1 ${
                          isActive
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : 'bg-rose-100 text-rose-900 border-rose-300 animate-pulse'
                        }`}
                      >
                        <span
                          className={`w-2 h-2 rounded-full ${
                            isActive ? 'bg-emerald-600' : 'bg-rose-600'
                          }`}
                        />
                        <span>{isActive ? 'सक्रिय (Active)' : 'निष्क्रिय (Deactive)'}</span>
                      </span>
                    </div>

                    {/* Dealer Name */}
                    <div>
                      <div className="text-xs font-bold text-slate-900 font-devanagari line-clamp-1">
                        {account.dealerName}
                      </div>
                    </div>

                    {/* Credentials Info Box (Gmail + Password with Eye toggle) */}
                    <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-500 font-bold">Gmail आयडी:</span>
                        <span className="font-mono font-bold text-slate-800 truncate max-w-[170px]">
                          {account.gmailId || '-'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-500 font-bold">पासवर्ड:</span>
                        <div className="flex items-center gap-1.5 font-mono font-bold text-slate-900">
                          <span>{isPasswordVisible ? account.password || '123456' : '••••••••'}</span>
                          <button
                            type="button"
                            onClick={() =>
                              setRevealedPasswords({
                                ...revealedPasswords,
                                [account.fpsId]: !isPasswordVisible
                              })
                            }
                            className="text-slate-400 hover:text-slate-600 cursor-pointer p-0.5"
                            title="पासवर्ड दाखवा / लपवा"
                          >
                            {isPasswordVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Registration Date & Time + Last Login Date & Time */}
                    <div className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-200 text-xs space-y-1.5 font-devanagari">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-amber-950 font-bold flex items-center gap-1">
                          <span>📅 नोंदणी तारीख व वेळ:</span>
                        </span>
                        <span className="font-mono font-bold text-slate-800 text-[10px]">
                          {account.registeredAt
                            ? new Date(account.registeredAt).toLocaleString('mr-IN', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true
                              })
                            : 'नोंदणी झालेली नाही'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-amber-950 font-bold flex items-center gap-1">
                          <span>🕒 शेवटचे लॉगिन:</span>
                        </span>
                        <span className="font-mono font-bold text-emerald-800 text-[10px]">
                          {account.lastLoginAt
                            ? new Date(account.lastLoginAt).toLocaleString('mr-IN', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true
                              })
                            : account.registeredAt
                            ? new Date(account.registeredAt).toLocaleString('mr-IN', {
                                day: '2-digit',
                                month: '2-digit',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true
                              })
                            : 'अद्याप लॉगिन नाही'}
                        </span>
                      </div>
                    </div>

                    {/* Stats summary: Total Cards & Subscription */}
                    <div className="flex items-center justify-between text-[11px] text-slate-600 font-devanagari">
                      <span>
                        एकूण कार्डे: <strong className="text-slate-900">{account.totalCards || 500}</strong> (AAY: {account.aayCards || 78}, PHH: {account.phhCards || 422})
                      </span>
                    </div>

                    {/* Subscription Validity Tag */}
                    <div className="text-[11px] font-devanagari flex items-center justify-between">
                      <span className="text-slate-500">वर्गणी स्थिती:</span>
                      <span
                        className={`font-bold ${
                          account.isSubscribed
                            ? 'text-emerald-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {account.isSubscribed
                          ? `सक्रिय (वैधता: ${account.subscriptionEndsAt ? new Date(account.subscriptionEndsAt).toLocaleDateString('mr-IN') : 'सक्रिय'})`
                          : (() => {
                              if (!account.registeredAt) return 'नोंदणी प्रलंबित';
                              const regMs = new Date(account.registeredAt).getTime();
                              const leftMs = (regMs + 3 * 24 * 3600 * 1000) - Date.now();
                              if (leftMs <= 0) return 'चाचणी समाप्त (वर्गणी आवश्यक)';
                              const hoursLeft = Math.ceil(leftMs / (3600 * 1000));
                              const days = Math.floor(hoursLeft / 24);
                              const remH = hoursLeft % 24;
                              return days >= 1 ? `चाचणी: ${days} दिवस ${remH} तास शिल्लक` : `चाचणी: ${hoursLeft} तास शिल्लक`;
                            })()}
                      </span>
                    </div>
                  </div>

                  {/* Actions Bar: ID Active/Deactive Toggle & Edit Button */}
                  <div className="p-3 bg-slate-50/80 border-t border-slate-200 flex items-center gap-2">
                    {/* The Crucial Active / Deactive Toggle Button */}
                    <button
                      type="button"
                      onClick={() => handleToggleActive(account)}
                      className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs ${
                        isActive
                          ? 'bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs'
                      }`}
                      title={isActive ? 'हे आयडी तात्पुरते निष्क्रिय करा' : 'हे आयडी पुन्हा सक्रिय करा'}
                    >
                      <Power className="w-3.5 h-3.5" />
                      <span>{isActive ? 'निष्क्रिय करा (Deactivate)' : 'सक्रिय करा (Activate)'}</span>
                    </button>

                    {/* Edit Data Button */}
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(account)}
                      className="py-2 px-2.5 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-2xs"
                      title="दुकानदाराचा डेटा संपादन करा"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-amber-700" />
                      <span>एडिट</span>
                    </button>

                    {/* View Shop in App Button */}
                    <button
                      type="button"
                      onClick={() => onSwitchToShopView()}
                      className="py-2 px-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-2xs"
                      title="या दुकानाचा साठा, वाटप व कार्डे थेट पहा"
                    >
                      <Store className="w-3.5 h-3.5 text-amber-800" />
                      <span>पहा</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredAccounts.length === 0 && (
            <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center text-slate-500 font-devanagari space-y-2">
              <Search className="w-8 h-8 mx-auto text-slate-300" />
              <p className="font-bold text-sm">कोणतेही दुकान सापडले नाही.</p>
              <p className="text-xs">कृपया शोध निकष बदला किंवा रीफ्रेश करा.</p>
            </div>
          )}
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 2: ALL PAYMENTS REGISTER ("payment जिसने करा वो सब दिखना") */}
      {/* ============================================================== */}
      {activeTab === 'payments' && (
        <div className="space-y-4 font-devanagari">
          {/* Active Payment Recipient Settings Banner with Change Option */}
          <div className="bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100/60 p-4 rounded-3xl border border-amber-300 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-md">
                <CreditCard className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-black text-amber-900 uppercase tracking-wide">
                    अधिकृत बँक / UPI पेमेंट रिसिव्हर तपशील
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                    सक्रिय (Active)
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
                  <div>
                    <span className="text-slate-600 font-bold">खातेदार नाव (Payee Name): </span>
                    <span className="font-black text-slate-950 bg-white/80 px-2 py-0.5 rounded-md border border-amber-200">
                      {recipientConfig.payeeName}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-600 font-bold">UPI ID: </span>
                    <span className="font-mono font-black text-amber-950 bg-white/90 px-2.5 py-0.5 rounded-md border border-amber-300">
                      {recipientConfig.upiId}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-600 font-bold">मासिक शुल्क: </span>
                    <span className="font-black text-emerald-800 font-mono">
                      ₹{recipientConfig.monthlyFee || 100}/महिना
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full md:w-auto">
              <button
                type="button"
                onClick={handleOpenEditRecipient}
                className="flex-1 md:flex-none px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-700 to-orange-700 hover:from-amber-800 hover:to-orange-800 text-white text-xs font-black transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95"
                title="खातेदार नाव (Payee Name) व UPI ID बदला"
              >
                <Edit3 className="w-4 h-4" />
                <span>खातेदार नाव व UPI ID बदला</span>
              </button>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-amber-700" />
                <span>सर्व दुकानदार मासिक वर्गणी व्यवहार नोंदणी (Payment Records)</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                ज्या दुकानदारांनी पेमेंट केले आहे त्यांचे सर्व तपशील (UTR, रक्कम, तारीख व स्थिती) खालीलप्रमाणे आहेत.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setIsManualPayOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <PlusCircle className="w-4 h-4" />
              <span>+ रोख / मॅन्युअल पेमेंट जोडा</span>
            </button>
          </div>

          {/* Payments Table */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100/80 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">तारीख व वेळ</th>
                    <th className="py-3 px-4">दुकान क्र. व नाव</th>
                    <th className="py-3 px-4">Gmail आयडी</th>
                    <th className="py-3 px-4">UTR / ट्रान्झॅक्शन क्र.</th>
                    <th className="py-3 px-4">पद्धत</th>
                    <th className="py-3 px-4">रक्कम</th>
                    <th className="py-3 px-4">स्थिती</th>
                    <th className="py-3 px-4 text-right">कृती (Action)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {payments.map((p, pIdx) => {
                    const isSuccess = p.status === 'SUCCESS';
                    const isPending = p.status === 'PENDING';
                    const isRejected = p.status === 'REJECTED';
                    const rowKey = p.id ? `${p.id}-${pIdx}` : `pay-${p.fpsId}-${p.utr || pIdx}-${pIdx}`;

                    return (
                      <tr key={rowKey} className="hover:bg-slate-50/70 transition-colors">
                        {/* Date */}
                        <td className="py-3 px-4 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                          {p.date ? new Date(p.date).toLocaleString('mr-IN') : '-'}
                        </td>

                        {/* Shop Info */}
                        <td className="py-3 px-4">
                          <span className="font-mono font-black text-slate-900 block">
                            FPS {p.fpsId}
                          </span>
                          <span className="text-[11px] text-slate-600 line-clamp-1">
                            {p.dealerName || 'दुकानदार'}
                          </span>
                        </td>

                        {/* Gmail */}
                        <td className="py-3 px-4 font-mono text-[11px] text-slate-700">
                          {p.gmailId || '-'}
                        </td>

                        {/* UTR */}
                        <td className="py-3 px-4">
                          <span className="font-mono font-black text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            {p.utr}
                          </span>
                        </td>

                        {/* Method */}
                        <td className="py-3 px-4 font-bold text-slate-700">
                          {p.method}
                        </td>

                        {/* Amount */}
                        <td className="py-3 px-4 font-mono font-black text-sm text-slate-900">
                          ₹ {p.amount || 100}
                        </td>

                        {/* Status */}
                        <td className="py-3 px-4">
                          {isSuccess && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>मंजूर (Approved)</span>
                            </span>
                          )}
                          {isPending && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                              <Clock className="w-3 h-3 text-amber-700" />
                              <span>पडताळणी प्रलंबित</span>
                            </span>
                          )}
                          {isRejected && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-800 border border-rose-300">
                              <XCircle className="w-3 h-3 text-rose-600" />
                              <span>नाकारले (Rejected)</span>
                            </span>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5 flex-wrap">
                            {isPending && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => handleApprovePayment(p)}
                                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] cursor-pointer shadow-xs transition-transform active:scale-95"
                                  title="पेमेंट मंजूर करा व ३० दिवसांचे ॲक्सेस द्या"
                                >
                                  ✓ मंजूर करा
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleRejectPayment(p)}
                                  className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] cursor-pointer shadow-xs transition-transform active:scale-95"
                                  title="पेमेंट नाकारा"
                                >
                                  ✕ नाकारा
                                </button>
                              </>
                            )}

                            {/* Edit Payment button (Change Payer Name, Real UTR, Shop, Amount, Status) */}
                            <button
                              type="button"
                              onClick={() => handleOpenEditPayment(p)}
                              className="px-2.5 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold text-[11px] cursor-pointer shadow-2xs transition-transform active:scale-95 flex items-center gap-1"
                              title="Payer नाव, UTR क्र., दुकान व रक्कम बदला"
                            >
                              <Edit3 className="w-3 h-3 text-amber-700" />
                              <span>संपादन</span>
                            </button>

                            {/* Delete Payment button */}
                            <button
                              type="button"
                              onClick={() => handleDeletePayment(p)}
                              className="p-1 rounded-lg text-slate-400 hover:text-rose-700 hover:bg-rose-50 cursor-pointer transition-colors"
                              title="पेमेंट नोंद हटवा"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>

                            {isSuccess && (
                              <span className="text-[10px] text-emerald-700 font-bold ml-1">
                                {p.approvedAt ? `मंजूर` : 'सक्रिय'}
                              </span>
                            )}
                            {isRejected && (
                              <span className="text-[10px] text-rose-600 font-bold truncate max-w-[100px] ml-1">
                                {p.rejectedReason || 'नाकारले'}
                              </span>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {payments.length === 0 && (
              <div className="p-8 text-center text-slate-500 font-devanagari space-y-1">
                <p className="font-bold">अद्याप कोणतीही पेमेंट नोंद नाही.</p>
                <p className="text-xs">दुकानदारांनी वर्गणी भरल्यावर किंवा आपण मॅन्युअल पेमेंट जोडल्यावर इथे दिसेल.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL 1: EDIT DEALER & SHOP DATA MODAL */}
      {/* ============================================================== */}
      {editingAccount && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-sans animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col font-devanagari">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-slate-900 to-amber-950 text-white p-4 sm:p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
                  <Edit3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">
                    दुकान व खाते माहिती संपादन (Edit Data)
                  </h3>
                  <p className="text-xs text-amber-200 font-mono">
                    दुकान क्र. {editingAccount.fpsId}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingAccount(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form Body */}
            <form onSubmit={handleSaveEdit} className="p-5 space-y-4 overflow-y-auto">
              {/* Field 1: Dealer Name */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  दुकानदाराचे नाव (Dealer Name):
                </label>
                <input
                  type="text"
                  value={editFormData.dealerName}
                  onChange={(e) => setEditFormData({ ...editFormData, dealerName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  required
                />
              </div>

              {/* Field 2 & 3: Gmail ID and Password */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Gmail आयडी (Login ID):
                  </label>
                  <input
                    type="email"
                    value={editFormData.gmailId}
                    onChange={(e) => setEditFormData({ ...editFormData, gmailId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    पासवर्ड (Password):
                  </label>
                  <input
                    type="text"
                    value={editFormData.password}
                    onChange={(e) => setEditFormData({ ...editFormData, password: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              {/* Cards Count row */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    एकूण कार्डे:
                  </label>
                  <input
                    type="number"
                    value={editFormData.totalCards}
                    onChange={(e) => setEditFormData({ ...editFormData, totalCards: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-300 font-mono text-xs font-bold text-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-amber-900 mb-1">
                    AAY कार्डे:
                  </label>
                  <input
                    type="number"
                    value={editFormData.aayCards}
                    onChange={(e) => setEditFormData({ ...editFormData, aayCards: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-amber-300 font-mono text-xs font-bold text-amber-950 bg-amber-50/50"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-teal-900 mb-1">
                    PHH कार्डे:
                  </label>
                  <input
                    type="number"
                    value={editFormData.phhCards}
                    onChange={(e) => setEditFormData({ ...editFormData, phhCards: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-teal-300 font-mono text-xs font-bold text-teal-950 bg-teal-50/50"
                  />
                </div>
              </div>

              {/* Subscription Extension */}
              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-300 space-y-1.5">
                <span className="text-xs font-bold text-amber-950 block">
                  वर्गणी वैधता वाढवा (Extend Subscription):
                </span>
                <div className="flex items-center gap-2">
                  <select
                    value={editFormData.extendDays}
                    onChange={(e) => setEditFormData({ ...editFormData, extendDays: Number(e.target.value) })}
                    className="px-3 py-1.5 rounded-xl border border-amber-400 text-xs font-bold text-amber-950 bg-white"
                  >
                    <option value={0}>बदल करू नका (No Change)</option>
                    <option value={30}>+ ३० दिवस वाढवा (1 Month)</option>
                    <option value={60}>+ ६० दिवस वाढवा (2 Months)</option>
                    <option value={90}>+ ९० दिवस वाढवा (3 Months)</option>
                    <option value={365}>+ १ वर्ष वाढवा (1 Year)</option>
                  </select>
                  <span className="text-[11px] text-amber-900">
                    सध्याची स्थिती: {editingAccount.isSubscribed ? 'सक्रिय' : 'चाचणी'}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setEditingAccount(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  रद्द करा
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-black shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>बदल जतन करा (Save)</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL 2: MANUAL OFFLINE PAYMENT MODAL */}
      {/* ============================================================== */}
      {isManualPayOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-sans animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden font-devanagari">
            <div className="bg-gradient-to-r from-emerald-800 to-teal-800 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <CreditCard className="w-5 h-5 text-emerald-300" />
                <h3 className="text-base font-black">मॅन्युअल / रोख पेमेंट नोंदणी</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsManualPayOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitManualPayment} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  दुकान निवडा (Select Shop):
                </label>
                <select
                  value={manualPayShopId}
                  onChange={(e) => setManualPayShopId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-white"
                  required
                >
                  <option value="">-- दुकान निवडा --</option>
                  {accounts.map((a) => (
                    <option key={a.fpsId} value={a.fpsId}>
                      FPS {a.fpsId} - {a.dealerName}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    रक्कम (₹):
                  </label>
                  <input
                    type="number"
                    value={manualPayAmount}
                    onChange={(e) => setManualPayAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm font-black text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    कालावधी:
                  </label>
                  <select
                    value={manualPayMonths}
                    onChange={(e) => setManualPayMonths(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-white"
                  >
                    <option value={1}>१ महिना (30 Days)</option>
                    <option value={2}>२ महिने (60 Days)</option>
                    <option value={3}>३ महिने (90 Days)</option>
                    <option value={6}>६ महिने (180 Days)</option>
                    <option value={12}>१ वर्ष (365 Days)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    पेमेंट पद्धत:
                  </label>
                  <select
                    value={manualPayMethod}
                    onChange={(e) => setManualPayMethod(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-white"
                  >
                    <option value="UPI">UPI ट्रान्सफर</option>
                    <option value="CASH">रोख रक्कम (Cash)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    UTR / संदर्भ क्र. (ऐच्छिक):
                  </label>
                  <input
                    type="text"
                    value={manualPayUtr}
                    onChange={(e) => setManualPayUtr(e.target.value)}
                    placeholder="उदा. MANUAL-12345"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-[11px] text-emerald-950 font-bold">
                ✓ मॅन्युअल पेमेंट सबमिट करताच निवडलेल्या दुकानाची वर्गणी तात्काळ सक्रिय होईल.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsManualPayOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  रद्द करा
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black shadow-md cursor-pointer"
                >
                  पेमेंट नोंदवा आणि सक्रिय करा
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL 3: EDIT PAYMENT MODAL (Payer Name, Real UTR, Shop, Amount) */}
      {/* ============================================================== */}
      {editingPayment && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-sans animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden font-devanagari max-h-[92vh] flex flex-col">
            <div className="bg-gradient-to-r from-amber-800 to-amber-950 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
                  <Edit3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-black">पेमेंट संपादन (Edit Payment)</h3>
                  <p className="text-xs text-amber-200 font-mono">
                    ID: {editingPayment.id}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingPayment(null)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePaymentEdit} className="p-5 space-y-4 overflow-y-auto">
              {/* Field 1: Payer Name */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  पैसे भरणाऱ्याचे / खातेदाराचे नाव (Payer Name):
                </label>
                <input
                  type="text"
                  value={editPaymentForm.dealerName}
                  onChange={(e) => setEditPaymentForm({ ...editPaymentForm, dealerName: e.target.value })}
                  placeholder="उदा. Bhagavan Kukaji Misal"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  required
                />
              </div>

              {/* Field 2: Real UTR / Transaction No */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center justify-between">
                  <span>रिअल UTR / ट्रान्झॅक्शन क्र. (Real UTR No.):</span>
                  <span className="text-[10px] text-amber-800 font-bold">खरा १२-अंकी UTR</span>
                </label>
                <input
                  type="text"
                  value={editPaymentForm.utr}
                  onChange={(e) => setEditPaymentForm({ ...editPaymentForm, utr: e.target.value })}
                  placeholder="उदा. 428172938102"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs font-bold text-slate-900 bg-amber-50/40 focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  required
                />
              </div>

              {/* Field 3: Shop / Account Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  दुकान / खाते बदल (Assign to Shop FPS ID):
                </label>
                <select
                  value={editPaymentForm.fpsId}
                  onChange={(e) => {
                    const selectedFps = e.target.value;
                    const matchAcc = accounts.find((a) => a.fpsId === selectedFps);
                    setEditPaymentForm({
                      ...editPaymentForm,
                      fpsId: selectedFps,
                      dealerName: matchAcc?.dealerName || editPaymentForm.dealerName
                    });
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-white"
                  required
                >
                  <option value="">-- दुकान निवडा --</option>
                  {accounts.map((a) => (
                    <option key={a.fpsId} value={a.fpsId}>
                      FPS {a.fpsId} - {a.dealerName}
                    </option>
                  ))}
                </select>
              </div>

              {/* Field 4: Amount & Plan Months */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    रक्कम (₹):
                  </label>
                  <input
                    type="number"
                    value={editPaymentForm.amount}
                    onChange={(e) => setEditPaymentForm({ ...editPaymentForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm font-black text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    कालावधी (महिने):
                  </label>
                  <select
                    value={editPaymentForm.planDurationMonths}
                    onChange={(e) => setEditPaymentForm({ ...editPaymentForm, planDurationMonths: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-white"
                  >
                    <option value={1}>१ महिना (३० दिवस)</option>
                    <option value={2}>२ महिने (६० दिवस)</option>
                    <option value={3}>३ महिने (९० दिवस)</option>
                    <option value={6}>६ महिने (१८० दिवस)</option>
                    <option value={12}>१ वर्ष (३६५ दिवस)</option>
                  </select>
                </div>
              </div>

              {/* Field 5: Status & Method */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    स्थिती (Status):
                  </label>
                  <select
                    value={editPaymentForm.status}
                    onChange={(e) => setEditPaymentForm({ ...editPaymentForm, status: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-white"
                  >
                    <option value="SUCCESS">✅ मंजूर (SUCCESS - सक्रिय)</option>
                    <option value="PENDING">⏳ पडताळणी प्रलंबित (PENDING)</option>
                    <option value="REJECTED">❌ नाकारले (REJECTED)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    पद्धत:
                  </label>
                  <select
                    value={editPaymentForm.method}
                    onChange={(e) => setEditPaymentForm({ ...editPaymentForm, method: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-white"
                  >
                    <option value="UPI">UPI ट्रान्सफर</option>
                    <option value="CASH">रोख रक्कम (Cash)</option>
                  </select>
                </div>
              </div>

              {/* Field 6: Date */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  पेमेंट तारीख:
                </label>
                <input
                  type="date"
                  value={editPaymentForm.date}
                  onChange={(e) => setEditPaymentForm({ ...editPaymentForm, date: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setEditingPayment(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  रद्द करा
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-black shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>पेमेंट बदल सेव्ह करा</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL 4: EDIT PAYMENT RECIPIENT (खातेदार नाव व UPI ID बदला) */}
      {/* ============================================================== */}
      {isEditRecipientOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-sans animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col font-devanagari">
            {/* Header */}
            <div className="bg-gradient-to-r from-amber-700 via-orange-700 to-amber-900 text-white p-4 sm:p-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center font-black">
                  <CreditCard className="w-5 h-5 text-amber-100" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">
                    खातेदार नाव (Payee Name) व UPI ID बदला
                  </h3>
                  <p className="text-xs text-amber-100">
                    दुकानदारांना QR कोड व UPI द्वारे पेमेंट करण्यासाठी हे तपशील थेट दिसतील
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsEditRecipientOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveRecipient} className="p-5 space-y-4 overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  खातेदार नाव (Payee Name):
                </label>
                <input
                  type="text"
                  value={recipientForm.payeeName}
                  onChange={(e) => setRecipientForm({ ...recipientForm, payeeName: e.target.value })}
                  placeholder="उदा. uzma kureshi"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-bold text-slate-900 bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  required
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  बँकेत नोंदवलेले अधिकृत नाव (हेच नाव दुकानदारांना पेमेंट वेळी दिसेल).
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  UPI ID:
                </label>
                <input
                  type="text"
                  value={recipientForm.upiId}
                  onChange={(e) => setRecipientForm({ ...recipientForm, upiId: e.target.value })}
                  placeholder="उदा. kureshi.isa1@axl किंवा 7709229567@ybl"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-sm font-bold text-slate-900 bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  required
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  हा UPI ID PhonePe / Google Pay QR कोड व पेमेंट लिंकसाठी थेट वापरला जाईल.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    मासिक वर्गणी शुल्क (₹):
                  </label>
                  <input
                    type="number"
                    value={recipientForm.monthlyFee}
                    onChange={(e) => setRecipientForm({ ...recipientForm, monthlyFee: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-sm font-black text-slate-900 bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    WhatsApp मदत क्र.:
                  </label>
                  <input
                    type="text"
                    value={recipientForm.whatsapp}
                    onChange={(e) => setRecipientForm({ ...recipientForm, whatsapp: e.target.value, phone: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-xs font-bold text-slate-900 bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  पेमेंट टीप / सूचना (Note):
                </label>
                <input
                  type="text"
                  value={recipientForm.note}
                  onChange={(e) => setRecipientForm({ ...recipientForm, note: e.target.value })}
                  placeholder="उदा. मेहकर शहर स्वस्त धान्य दुकान मासिक वर्गणी"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsEditRecipientOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
                >
                  रद्द करा
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-700 to-orange-700 hover:from-amber-800 hover:to-orange-800 text-white text-xs font-black shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>बदल जतन करा</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
