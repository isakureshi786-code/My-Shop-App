import React, { useState, useEffect } from 'react';
import { Calendar, TrendingUp, Clock, Store, Layers, BarChart2 } from 'lucide-react';
import { EposDateSale } from '../types/epos.js';

interface DatewiseSalesProps {
  lang: 'mr' | 'hi' | 'en';
}

export const DatewiseSales: React.FC<DatewiseSalesProps> = ({ lang }) => {
  const [dateSales, setDateSales] = useState<EposDateSale[]>([]);
  const [selectedDay, setSelectedDay] = useState<number>(30);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/epos/datewise')
      .then((res) => res.json())
      .then((data) => {
        setDateSales(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load datewise sales:', err);
        setLoading(false);
      });
  }, []);

  const activeSale = dateSales.find((d) => d.day === selectedDay) || dateSales[dateSales.length - 1];

  const totalMonthTransactions = dateSales.reduce((sum, d) => sum + d.transactions, 0);
  const totalMonthWheat = dateSales.reduce((sum, d) => sum + d.wheatDistributedKg, 0);
  const totalMonthRice = dateSales.reduce((sum, d) => sum + d.riceDistributedKg, 0);

  const t = {
    mr: {
      title: 'तारखेनिहाय रेशन वाटप व कार्ड तपशील (September 2026)',
      subtitle: 'मेहकर तालुक्यातील दैनंदिन ई-पॉस व्यवहार व धान्य वाटप आकडेवारी',
      selectDate: 'तारीख निवडा (१ ते ३० सप्टेंबर)',
      totalTrans: 'निवडलेल्या दिवशीचे व्यवहार',
      activeShops: 'त्या दिवशी सक्रिय दुकाने',
      wheatDist: 'वाटप झालेला गहू',
      riceDist: 'वाटप झालेला तांदूळ',
      peakHours: 'सर्वाधिक गर्दीची वेळ (Peak Hours)',
      monthTotal: 'महिन्यातील एकूण व्यवहार',
      grainSummary: 'मासिक एकूण धान्य वाटप'
    },
    hi: {
      title: 'तिथिवार राशन वितरण व कार्ड विवरण (September 2026)',
      subtitle: 'मेहकर तहसील में दैनिक ई-पॉस लेन-देन व खाद्यान्न वितरण आंकड़े',
      selectDate: 'तारीख चुनें (1 से 30 सितंबर)',
      totalTrans: 'चयनित दिन के लेन-देन',
      activeShops: 'उस दिन सक्रिय दुकानें',
      wheatDist: 'वितरित गेहूं',
      riceDist: 'वितरित चावल',
      peakHours: 'अधिकतम भीड़ का समय',
      monthTotal: 'महीने के कुल लेन-देन',
      grainSummary: 'मासिक कुल अनाज वितरण'
    },
    en: {
      title: 'Date-wise Ration Distribution (September 2026)',
      subtitle: 'Daily ePOS transactions & grain distribution stats in Mehkar',
      selectDate: 'Select Date (1 to 30 September)',
      totalTrans: 'Transactions on Selected Day',
      activeShops: 'Active Shops that Day',
      wheatDist: 'Wheat Distributed',
      riceDist: 'Rice Distributed',
      peakHours: 'Peak Distribution Hours',
      monthTotal: 'Month Total Transactions',
      grainSummary: 'Monthly Total Grain Dispensed'
    }
  }[lang];

  if (loading) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 shadow-xs">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-amber-600 border-t-transparent mb-3"></div>
        <p className="text-sm font-medium text-slate-600 font-devanagari">
          तारखेनिहाय डेटा लोड होत आहे...
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4 font-devanagari">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-amber-700" />
              {t.title}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.subtitle}</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200/60 text-right">
              <div className="text-[10px] text-amber-900 font-semibold">{t.monthTotal}</div>
              <div className="text-base font-extrabold text-amber-950 tabular-nums">
                {totalMonthTransactions.toLocaleString('en-IN')}
              </div>
            </div>
          </div>
        </div>

        {/* Date Selector Ribbon (Days 1 to 30) */}
        <div className="mt-4 pt-4 border-t border-slate-100">
          <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center justify-between">
            <span>{t.selectDate}</span>
            <span className="text-amber-800 font-bold">
              निवडलेली तारीख: {selectedDay} सप्टेंबर २०२६
            </span>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 no-scrollbar">
            {dateSales.map((sale) => {
              const isSelected = sale.day === selectedDay;
              const isToday = sale.day === 30;

              return (
                <button
                  key={sale.day}
                  type="button"
                  onClick={() => setSelectedDay(sale.day)}
                  className={`flex flex-col items-center justify-center min-w-[42px] h-14 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-amber-700 text-white border-amber-800 shadow-sm scale-105'
                      : isToday
                      ? 'bg-amber-50 text-amber-950 border-amber-300 hover:bg-amber-100'
                      : 'bg-slate-50 text-slate-700 border-slate-200/80 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-[10px] font-normal uppercase opacity-75">
                    {isToday ? 'आज' : `Day`}
                  </span>
                  <span className="text-sm font-extrabold tabular-nums">{sale.day}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Selected Day Highlights */}
      {activeSale && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <div className="text-xs text-slate-500 font-medium">{t.totalTrans}</div>
            <div className="text-2xl font-extrabold text-blue-600 mt-1 tabular-nums">
              {activeSale.transactions.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              {selectedDay} सप्टेंबर २०२६ रोजी ई-पॉसद्वारे वाटप
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <div className="text-xs text-slate-500 font-medium">{t.activeShops}</div>
            <div className="text-2xl font-extrabold text-emerald-600 mt-1 tabular-nums">
              {activeSale.activeShops} <span className="text-sm text-slate-500">/ 185</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              मेहकर तालुक्यातील सक्रिय दुकाने
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <div className="text-xs text-slate-500 font-medium">{t.wheatDist}</div>
            <div className="text-2xl font-extrabold text-amber-900 mt-1 tabular-nums">
              {(activeSale.wheatDistributedKg / 100).toFixed(1)} <span className="text-sm text-slate-500">क्विंटल</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              ({activeSale.wheatDistributedKg.toLocaleString('en-IN')} Kg गहू)
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
            <div className="text-xs text-slate-500 font-medium">{t.peakHours}</div>
            <div className="text-xl font-bold text-slate-800 mt-1 flex items-center gap-1.5">
              <Clock className="w-5 h-5 text-amber-600 shrink-0" />
              <span>{activeSale.peakHour}</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              दुकानदारांकडील सर्वाधिक गर्दीची वेळ
            </div>
          </div>
        </div>
      )}

      {/* Visual Distribution Trend Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5">
        <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-amber-700" />
          सप्टेंबर २०२६ दैनंदिन व्यवहार आलेख व प्रगती (Day 1 ते Day 30)
        </h3>

        <div className="space-y-2">
          {dateSales.slice(0, 15).map((sale) => {
            const maxTrans = 3400;
            const pct = Math.min(100, Math.round((sale.transactions / maxTrans) * 100));
            const isSelected = sale.day === selectedDay;

            return (
              <div
                key={sale.day}
                onClick={() => setSelectedDay(sale.day)}
                className={`p-2 rounded-xl transition-all cursor-pointer flex items-center gap-3 text-xs ${
                  isSelected ? 'bg-amber-50 border border-amber-200' : 'hover:bg-slate-50'
                }`}
              >
                <div className="w-16 font-bold tabular-nums text-slate-700 shrink-0">
                  {sale.day} सप्टेंबर
                </div>

                {/* Bar */}
                <div className="flex-1 bg-slate-100 rounded-full h-3 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      isSelected ? 'bg-amber-600' : 'bg-slate-400'
                    }`}
                    style={{ width: `${pct}%` }}
                  ></div>
                </div>

                <div className="w-20 text-right font-extrabold tabular-nums text-slate-800 shrink-0">
                  {sale.transactions.toLocaleString('en-IN')}
                </div>

                <div className="w-24 text-right text-[11px] text-slate-500 tabular-nums shrink-0 hidden sm:block">
                  {sale.activeShops} दुकाने
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
