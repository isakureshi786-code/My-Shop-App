import React, { useState, useMemo, useEffect } from 'react';
import {
  Search,
  Printer,
  FileSpreadsheet,
  RefreshCw,
  ArrowUpDown,
  Filter,
  CheckCircle2,
  Calendar,
  Building2,
  Store,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { PortabilityTransaction, getPortabilityTransactions, OFFICIAL_PORTABILITY_TRANSACTIONS } from '../data/portabilityData.js';
import { EposShop } from '../types/epos.js';
import { printFormattedReport } from '../utils/exportUtils.js';

interface PortabilityTransactionsViewProps {
  currentShopId?: string;
  shops?: EposShop[];
  currentMonth?: string;
  lang: 'mr' | 'hi' | 'en';
}

export const PortabilityTransactionsView: React.FC<PortabilityTransactionsViewProps> = ({
  currentShopId = '150024600320',
  shops = [],
  currentMonth = '2026-10',
  lang
}) => {
  const isOctober = currentMonth === '2026-10' || currentMonth.toLowerCase().includes('oct');
  const [selectedMonth, setSelectedMonth] = useState<string>(isOctober ? 'October' : 'September');
  const [selectedYear, setSelectedYear] = useState<string>('2026');
  const [selectedFps, setSelectedFps] = useState<string>(currentShopId);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [perPage, setPerPage] = useState<number>(50);
  const [currentPage, setCurrentPage] = useState<number>(1);

  useEffect(() => {
    if (currentShopId) {
      setSelectedFps(currentShopId);
    }
  }, [currentShopId]);

  // Month change sync
  const monthName = selectedMonth;

  // Filtered transactions strictly for logged in shop (or selected shop if Owner)
  const transactions = useMemo(() => {
    const shopToUse = selectedFps || currentShopId || '150024600320';
    let list = getPortabilityTransactions(shopToUse, selectedMonth, selectedYear);
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      list = list.filter(
        (t) =>
          t.rcNo.toLowerCase().includes(q) ||
          t.receiptNo.toLowerCase().includes(q) ||
          t.scheme.toLowerCase().includes(q) ||
          t.portabilityFpsId.toLowerCase().includes(q) ||
          (t.cardHolderName && t.cardHolderName.toLowerCase().includes(q))
      );
    }
    return list;
  }, [selectedFps, currentShopId, selectedMonth, selectedYear, searchTerm]);

  // Pagination
  const totalEntries = transactions.length;
  const totalPages = Math.max(1, Math.ceil(totalEntries / perPage));
  const displayedEntries = transactions.slice((currentPage - 1) * perPage, currentPage * perPage);

  // Totals
  const totals = useMemo(() => {
    return transactions.reduce(
      (acc, t) => {
        const rowQty = (t.wheatKg || 0) + (t.riceKg || 0) + (t.sugarKg || 0) + (t.maizeKg || 0) + (t.jowarKg || 0) + (t.fRiceKg || 0);
        return {
          wheat: acc.wheat + (t.wheatKg || 0),
          rice: acc.rice + (t.riceKg || 0),
          sugar: acc.sugar + (t.sugarKg || 0),
          saree: acc.saree + (t.sareePkts || 0),
          maize: acc.maize + (t.maizeKg || 0),
          jowar: acc.jowar + (t.jowarKg || 0),
          fRice: acc.fRice + (t.fRiceKg || 0),
          totalQty: acc.totalQty + rowQty
        };
      },
      {
        wheat: 0,
        rice: 0,
        sugar: 0,
        saree: 0,
        maize: 0,
        jowar: 0,
        fRice: 0,
        totalQty: 0
      }
    );
  }, [transactions]);

  // Handle Print
  const handlePrint = () => {
    printFormattedReport({
      title: `Portability Transaction Details for FPS ${selectedFps} in ${monthName}'${selectedYear}`,
      subtitle: `Food, Civil Supplies and Consumer Protection Department, Maharashtra (AePDS) · एकूण व्यवहार: ${transactions.length}`,
      sections: [
        {
          heading: `FPS ID: ${selectedFps} · महिना: ${monthName} ${selectedYear}`,
          headers: [
            'Sl No',
            'RC No',
            'Scheme',
            'Date',
            'Qty in Kgs',
            'Portability',
            'Auth Trans Time',
            'Wheat (Kgs)',
            'Rice (Kgs)',
            'Sugar (Kgs)',
            'SAREE (PKTS)',
            'Maize (Kgs)',
            'Jowar (Kgs)',
            'FRice (Kgs)'
          ],
          rows: transactions.map((t, idx) => {
            const rowQty = (t.wheatKg || 0) + (t.riceKg || 0) + (t.sugarKg || 0) + (t.maizeKg || 0) + (t.jowarKg || 0) + (t.fRiceKg || 0);
            return [
              String(idx + 1),
              t.rcNo,
              t.scheme,
              t.date,
              rowQty.toFixed(3),
              t.portabilityFpsId,
              t.authTransTime,
              t.wheatKg.toFixed(3),
              t.riceKg.toFixed(3),
              t.sugarKg.toFixed(3),
              t.sareePkts.toFixed(0),
              t.maizeKg.toFixed(3),
              t.jowarKg.toFixed(3),
              t.fRiceKg.toFixed(3)
            ];
          })
        }
      ]
    });
  };

  return (
    <div className="space-y-4 font-sans animate-in fade-in pb-12">
      {/* Top Filter & Selector Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 font-devanagari">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#2d1810] text-amber-200 flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
            🔄
          </div>
          <div>
            <h2 className="text-base font-black text-slate-900 tracking-tight font-sans">
              Portability Transaction Details for FPS
            </h2>
            <p className="text-xs text-slate-600 font-medium">
              पोर्टेबिलिटी व्यवहार तपशील · इतर दुकानात किंवा या दुकानात घेतलेले धान्य
            </p>
          </div>
        </div>

        {/* Month & FPS Filter Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Month selector */}
          <select
            value={selectedMonth}
            onChange={(e) => {
              setSelectedMonth(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-800 cursor-pointer shadow-2xs font-sans"
          >
            <option value="October">October (ऑक्टोबर)</option>
            <option value="September">September (सप्टेंबर)</option>
          </select>

          {/* Active FPS Badge or Shop Selector if Owner */}
          {shops && shops.length > 1 ? (
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-slate-700 font-devanagari">दुकान:</span>
              <select
                value={selectedFps}
                onChange={(e) => {
                  setSelectedFps(e.target.value);
                  setCurrentPage(1);
                }}
                className="px-2.5 py-1.5 rounded-xl border border-amber-300 bg-amber-50 text-xs font-mono font-bold text-amber-950 cursor-pointer shadow-2xs font-sans"
              >
                {currentShopId === 'ALL' && <option value="ALL">सर्व दुकाने (All Shops)</option>}
                {shops.map((s) => (
                  <option key={s.fpsId} value={s.fpsId}>
                    {s.fpsId} - {s.dealerName.slice(0, 16)}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div className="px-3 py-1.5 rounded-xl bg-amber-900 text-amber-100 text-xs font-mono font-bold shadow-2xs flex items-center gap-1.5">
              <Store className="w-3.5 h-3.5 text-amber-300" />
              <span>FPS: {currentShopId}</span>
            </div>
          )}

          {/* Print Button */}
          <button
            type="button"
            onClick={handlePrint}
            className="px-3.5 py-1.5 rounded-xl bg-amber-800 hover:bg-amber-900 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print (प्रिंट)</span>
          </button>
        </div>
      </div>

      {/* Main Government AePDS Style Container */}
      <div className="bg-white rounded-2xl border border-slate-300 shadow-sm overflow-hidden">
        {/* Top Controls: Per page and Search Input matching screenshot */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-700 font-medium">
            <span>Per page</span>
            <select
              value={perPage}
              onChange={(e) => {
                setPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-2 py-1 rounded-md border border-slate-300 bg-white font-mono font-bold text-slate-900 shadow-2xs cursor-pointer"
            >
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-slate-700 font-medium">Search</label>
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="RC No / Receipt / Scheme..."
                className="px-2.5 py-1 pr-7 rounded-md border border-slate-300 text-xs font-medium text-slate-900 bg-white focus:outline-hidden focus:ring-1 focus:ring-amber-500 w-48 sm:w-60 shadow-2xs"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Official Black/Brown Header Bar Matching Screenshot 1 */}
        <div className="bg-[#24130a] text-white text-center py-2.5 px-4 font-bold text-xs sm:text-sm tracking-wide font-sans">
          Portability Transaction Details for FPS {selectedFps || currentShopId} in {monthName}'{selectedYear}
        </div>

        {/* Table Viewport with Horizontal Scroll */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans border-collapse">
            {/* Table Header with only requested columns */}
            <thead className="bg-[#24130a] text-white font-bold text-[11px] border-t border-amber-950">
              <tr>
                <th className="py-2.5 px-2 text-center border-r border-[#3d2314] w-12">
                  Sl<br />No
                </th>
                <th className="py-2.5 px-3 border-r border-[#3d2314] min-w-[130px]">
                  <div className="flex items-center justify-between gap-1">
                    <span>RC No</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
                <th className="py-2.5 px-2 text-center border-r border-[#3d2314] w-16">
                  Scheme
                </th>
                <th className="py-2.5 px-2 text-center border-r border-[#3d2314] min-w-[85px]">
                  Date
                </th>
                <th className="py-2.5 px-2 text-right border-r border-[#3d2314] min-w-[75px] bg-[#1a0d07] text-amber-200">
                  Qty in Kgs<br /><span className="text-[9px] font-normal text-amber-300">(एकूण वजन)</span>
                </th>
                <th className="py-2.5 px-2.5 text-center border-r border-[#3d2314] min-w-[100px]">
                  Portability<br /><span className="text-[9px] font-normal text-amber-200">(FPS ID)</span>
                </th>
                <th className="py-2.5 px-2 text-center border-r border-[#3d2314] min-w-[80px]">
                  Auth<br />Trans<br />Time
                </th>
                <th className="py-2.5 px-2 text-right border-r border-[#3d2314] min-w-[65px]">
                  Wheat<br />(Kgs)
                </th>
                <th className="py-2.5 px-2 text-right border-r border-[#3d2314] min-w-[65px]">
                  Rice<br />(Kgs)
                </th>
                <th className="py-2.5 px-2 text-right border-r border-[#3d2314] min-w-[60px]">
                  Sugar<br />(Kgs)
                </th>
                <th className="py-2.5 px-2 text-right border-r border-[#3d2314] min-w-[65px]">
                  SAREE<br />(PKTS)
                </th>
                <th className="py-2.5 px-2 text-right border-r border-[#3d2314] min-w-[60px]">
                  Maize<br />(Kgs)
                </th>
                <th className="py-2.5 px-2 text-right border-r border-[#3d2314] min-w-[65px]">
                  Jowar<br />(Kgs)
                </th>
                <th className="py-2.5 px-2 text-right min-w-[65px]">
                  FRice<br />(Kgs)
                </th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-200">
              {displayedEntries.map((t, idx) => {
                const rowQty = (t.wheatKg || 0) + (t.riceKg || 0) + (t.sugarKg || 0) + (t.maizeKg || 0) + (t.jowarKg || 0) + (t.fRiceKg || 0);
                return (
                  <tr key={`${t.receiptNo}-${t.slNo}`} className="hover:bg-amber-50/40 text-slate-800">
                    <td className="py-2.5 px-2 text-center font-mono font-semibold border-r border-slate-200">
                      {(currentPage - 1) * perPage + idx + 1}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-900 border-r border-slate-200">
                      <div>{t.rcNo}</div>
                      {t.cardHolderName && (
                        <span className="text-[10px] text-slate-500 font-sans font-medium uppercase block">
                          {t.cardHolderName}
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-2 text-center font-bold border-r border-slate-200">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-black ${
                        t.scheme === 'AAY' ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-teal-100 text-teal-900 border border-teal-300'
                      }`}>
                        {t.scheme}
                      </span>
                    </td>
                    <td className="py-2.5 px-2 text-center font-mono text-[11px] font-bold text-slate-900 border-r border-slate-200 whitespace-nowrap">
                      {t.date}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono font-extrabold text-amber-950 bg-amber-50/70 border-r border-slate-200">
                      {rowQty.toFixed(3)}
                    </td>
                    <td className="py-2.5 px-2.5 text-center font-mono font-bold text-indigo-900 bg-indigo-50/40 border-r border-slate-200">
                      {t.portabilityFpsId}
                    </td>
                    <td className="py-2.5 px-2 text-center font-mono text-[11px] font-semibold text-slate-700 border-r border-slate-200">
                      {t.authTransTime}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono font-bold text-slate-900 border-r border-slate-200">
                      {t.wheatKg.toFixed(3)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono text-slate-700 border-r border-slate-200">
                      {t.riceKg.toFixed(3)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono text-slate-700 border-r border-slate-200">
                      {t.sugarKg.toFixed(3)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono text-slate-700 border-r border-slate-200">
                      {t.sareePkts.toFixed(0)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono text-slate-700 border-r border-slate-200">
                      {t.maizeKg.toFixed(3)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono font-bold text-slate-900 border-r border-slate-200">
                      {t.jowarKg.toFixed(3)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono font-bold text-slate-900">
                      {t.fRiceKg.toFixed(3)}
                    </td>
                  </tr>
                );
              })}

              {displayedEntries.length === 0 && (
                <tr>
                  <td colSpan={14} className="py-8 text-center text-slate-500 font-devanagari">
                    या दुकानासाठी किंवा शोध परिणामात कोणतीही पोर्टेबिलिटी नोंद सापडली नाही.
                  </td>
                </tr>
              )}
            </tbody>

            {/* Total Row matching only the requested columns */}
            <tfoot className="bg-[#1a0d07] text-white font-bold text-[11px] border-t-2 border-amber-950">
              <tr>
                <td colSpan={4} className="py-2.5 px-4 text-center font-black tracking-wider border-r border-[#3d2314]">
                  Total (एकूण बेरीज)
                </td>
                <td className="py-2.5 px-2 text-right font-mono font-black text-amber-300 border-r border-[#3d2314]">
                  {totals.totalQty.toFixed(3)}
                </td>
                <td colSpan={2} className="py-2.5 px-2 bg-[#1a0d07] border-r border-[#3d2314]"></td>
                <td className="py-2.5 px-2 text-right font-mono border-r border-[#3d2314]">{totals.wheat.toFixed(3)}</td>
                <td className="py-2.5 px-2 text-right font-mono border-r border-[#3d2314]">{totals.rice.toFixed(3)}</td>
                <td className="py-2.5 px-2 text-right font-mono border-r border-[#3d2314]">{totals.sugar.toFixed(3)}</td>
                <td className="py-2.5 px-2 text-right font-mono border-r border-[#3d2314]">{totals.saree.toFixed(0)}</td>
                <td className="py-2.5 px-2 text-right font-mono border-r border-[#3d2314]">{totals.maize.toFixed(3)}</td>
                <td className="py-2.5 px-2 text-right font-mono border-r border-[#3d2314]">{totals.jowar.toFixed(3)}</td>
                <td className="py-2.5 px-2 text-right font-mono">{totals.fRice.toFixed(3)}</td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Bottom Pagination & Count Matching Screenshot 1 */}
        <div className="p-3 bg-white border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="text-rose-900 font-bold font-sans">
            Showing {totalEntries > 0 ? (currentPage - 1) * perPage + 1 : 0} to{' '}
            {Math.min(currentPage * perPage, totalEntries)} of {totalEntries} entries
          </div>

          <div className="flex items-center gap-1 font-bold">
            <button
              type="button"
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage(1)}
              className="px-2.5 py-1 rounded bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white cursor-pointer shadow-2xs font-sans"
            >
              First
            </button>
            <button
              type="button"
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="px-2.5 py-1 rounded bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white cursor-pointer shadow-2xs font-sans"
            >
              Previous
            </button>
            <span className="px-3 py-1 rounded bg-blue-900 text-white font-mono shadow-2xs">
              {currentPage}
            </span>
            <button
              type="button"
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              className="px-2.5 py-1 rounded bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white cursor-pointer shadow-2xs font-sans"
            >
              Next
            </button>
            <button
              type="button"
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage(totalPages)}
              className="px-2.5 py-1 rounded bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white cursor-pointer shadow-2xs font-sans"
            >
              Last
            </button>
          </div>
        </div>
      </div>

      {/* Official AePDS Disclaimer Footer Matching Screenshot 1 */}
      <footer className="bg-black text-amber-500 py-3 px-4 rounded-xl flex flex-wrap items-center justify-between gap-2 text-[11px] font-sans">
        <span className="font-semibold hover:underline cursor-pointer">Disclaimer</span>
        <span className="text-white font-medium text-center">
          Designed & Developed for <strong className="text-amber-400">Food, Civil Supplies and Consumer Protection Department</strong>, Maharashtra
        </span>
        <div className="flex items-center gap-2">
          <span>Copyright</span>
          <span className="px-2 py-0.5 rounded bg-blue-700 text-white font-bold font-mono text-[10px]">
            NIC
          </span>
        </div>
      </footer>
    </div>
  );
};
