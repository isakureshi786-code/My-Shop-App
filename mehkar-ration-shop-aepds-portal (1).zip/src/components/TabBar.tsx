import React from 'react';
import { LayoutGrid, Store, Layers, Clock, Boxes, FileSearch } from 'lucide-react';

export type TabType = 'home' | 'shops' | 'aay-phh' | 'pending' | 'fps-stock' | 'rc-detail';

interface TabBarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  lang: 'mr' | 'hi' | 'en';
}

export const TabBar: React.FC<TabBarProps> = ({ activeTab, setActiveTab, lang }) => {
  const tabs = [
    {
      id: 'home' as TabType,
      labelMr: '🏠 मुख्य मेनू (Home)',
      labelHi: '🏠 मुख्य मेनू (Home)',
      labelEn: '🏠 Main Dashboard',
      icon: LayoutGrid,
      badge: 'डॅशबोर्ड'
    },
    {
      id: 'shops' as TabType,
      labelMr: '🏬 दुकान सूची व शोध',
      labelHi: '🏬 दुकान सूची व खोज',
      labelEn: '🏬 Shops Directory',
      icon: Store,
      badge: null
    },
    {
      id: 'aay-phh' as TabType,
      labelMr: '📊 योजनानिहाय कार्डे (AAY व PHH)',
      labelHi: '📊 योजनावार राशन कार्ड (AAY व PHH)',
      labelEn: '📊 Scheme Cards (AAY & PHH)',
      icon: Layers,
      badge: 'AAY / PHH'
    },
    {
      id: 'pending' as TabType,
      labelMr: '⏳ प्रलंबित कार्डे (Pending Cards)',
      labelHi: '⏳ लंबित राशन कार्ड (Pending Cards)',
      labelEn: '⏳ Pending Ration Cards',
      icon: Clock,
      badge: 'बाकी कार्डे'
    },
    {
      id: 'fps-stock' as TabType,
      labelMr: '📦 FPS Stock Details (साठा तपशील)',
      labelHi: '📦 FPS Stock Details (स्टॉक विवरण)',
      labelEn: '📦 FPS Stock Details',
      icon: Boxes,
      badge: 'ePOS रजिस्टर'
    },
    {
      id: 'rc-detail' as TabType,
      labelMr: '🔍 RC Detail (शिधापत्रिका तपशील)',
      labelHi: '🔍 RC Detail (राशन कार्ड विवरण)',
      labelEn: '🔍 RC Details (AePDS)',
      icon: FileSearch,
      badge: 'ePOS AePDS'
    }
  ];

  return (
    <div className="bg-white rounded-2xl p-1.5 border border-slate-200/80 shadow-xs overflow-x-auto no-scrollbar">
      <div className="flex items-center gap-1.5 min-w-max">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const label =
            lang === 'mr' ? tab.labelMr : lang === 'hi' ? tab.labelHi : tab.labelEn;

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 cursor-pointer whitespace-nowrap font-devanagari select-none ${
                isActive
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
              }`}
            >
              <span>{label}</span>
              {tab.badge && (
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded tracking-wide font-sans ${
                    isActive
                      ? 'bg-amber-950 text-amber-100'
                      : 'bg-amber-50 text-amber-900 border border-amber-200'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
