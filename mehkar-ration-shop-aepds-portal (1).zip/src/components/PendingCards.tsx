import React, { useState, useMemo, useEffect } from 'react';
import {
  Clock,
  FileSpreadsheet,
  Printer,
  Search,
  ArrowUpDown,
  ChevronDown,
  ChevronUp,
  FileText,
  ShieldCheck,
  RefreshCw,
  CheckCircle2,
  RotateCcw,
  Check
} from 'lucide-react';
import { EposShop } from '../types/epos.js';
import { exportToCsv, printFormattedReport } from '../utils/exportUtils.js';
import { MonthYearPicker } from './MonthYearPicker.js';
import officialDayWiseData from '../data/officialDayWiseTrans.json';
import officialShopCounts from '../data/officialShopCounts.json';
import shopCardRegistry from '../data/shopCardRegistry.json';
import octoberTxs from '../data/shopTransactionsOct.json';
import sepTransactions from '../data/shopTransactions.json';
import { OFFICIAL_PORTABILITY_TRANSACTIONS } from '../data/portabilityData.js';
import {
  recordLivePosTransaction,
  deleteLivePosTransaction,
  getLiveRecordedTransactions
} from '../services/eposClientData.js';

interface PendingCardsProps {
  shops: EposShop[];
  lang: 'mr' | 'hi' | 'en';
  currentMonth?: string;
  onMonthChange?: (month: string) => void;
  onRefresh?: () => void;
  isRefreshing?: boolean;
  onViewRcDetail?: (rcNo: string) => void;
}

export const PendingCards: React.FC<PendingCardsProps> = ({
  shops,
  currentMonth = '2026-10',
  onMonthChange,
  onRefresh,
  isRefreshing = false,
  onViewRcDetail
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [expandedFpsId, setExpandedFpsId] = useState<string | null>(null);
  const [schemeFilter, setSchemeFilter] = useState<'ALL' | 'AAY' | 'PHH'>('ALL');

  // Auto-expand if single logged in shop
  useEffect(() => {
    if (shops.length === 1 && !expandedFpsId) {
      setExpandedFpsId(shops[0].fpsId);
    }
  }, [shops, expandedFpsId]);

  // Exact data from verified epos.mahafood.gov.in Non_Availed_Cards.jsp
  const pendingShops = useMemo(() => {
    return shops.map((s) => {
      const octList = (octoberTxs as any)[s.fpsId] || [];
      const sepList = (sepTransactions as any)[s.fpsId] || [];

      // Official 100% verified government card counts
      const counts = (officialShopCounts as any)[s.fpsId];
      const totalCards = counts?.totalCards || s.totalCards || 0;
      const aayCards = counts?.aayTotal || s.aayCards || 45;
      const phhCards = counts?.phhTotal || s.phhCards || (totalCards - aayCards);

      // All cards in shop
      const allCards = (shopCardRegistry as any)[s.fpsId] || [];

      // Build complete set of cards that already took ration this month online directly from ePOS transactions
      let baseAvailedSrcs: string[] = [];
      if (currentMonth === '2026-10') {
        baseAvailedSrcs = octList.map((t: any) => t.srcNo);
      } else if (currentMonth === '2026-09') {
        baseAvailedSrcs = sepList.map((t: any) => t.srcNo);
      }

      // Automatically include online portability transactions
      const portTxs = OFFICIAL_PORTABILITY_TRANSACTIONS.filter(
        (p) =>
          (p.homeFpsId === s.fpsId || p.portabilityFpsId === s.fpsId) &&
          (currentMonth === '2026-10' ? p.month.toLowerCase().includes('oct') : p.month.toLowerCase().includes('sep'))
      );
      portTxs.forEach((p) => {
        if (!baseAvailedSrcs.includes(p.rcNo)) baseAvailedSrcs.push(p.rcNo);
      });
      const combinedAvailedSet = new Set(baseAvailedSrcs);

      // Cards that have NOT availed ration (Pending Cards)
      const pendingCardsList = allCards.filter((c: any) => !combinedAvailedSet.has(c.srcNo));

      // Cards that have availed ration (Availed Cards)
      const availedCardsList = allCards.filter((c: any) => combinedAvailedSet.has(c.srcNo));

      // Scheme-wise calculations:
      const aayAvailed = allCards.filter((c: any) => c.scheme === 'AAY' && combinedAvailedSet.has(c.srcNo)).length;
      const phhAvailed = allCards.filter((c: any) => c.scheme === 'PHH' && combinedAvailedSet.has(c.srcNo)).length;
      const monthAvailed = aayAvailed + phhAvailed;

      const aayPending = pendingCardsList.filter((c: any) => c.scheme === 'AAY').length;
      const phhPending = pendingCardsList.filter((c: any) => c.scheme === 'PHH').length;
      const totalPending = pendingCardsList.length;
      const pendingPct = totalCards > 0 ? ((totalPending / totalCards) * 100).toFixed(1) : '0';

      return {
        fpsId: s.fpsId,
        dealerName: s.dealerName,
        totalCards,
        monthAvailed,
        aayCards,
        aayAvailed,
        aayPending,
        phhCards,
        phhAvailed,
        phhPending,
        totalPending,
        pendingPct: parseFloat(pendingPct),
        pendingCardsList,
        availedCardsList
      };
    });
  }, [shops, currentMonth]);

  const filteredAndSorted = useMemo(() => {
    let list = pendingShops.filter((s) => {
      if (!searchTerm.trim()) return true;
      const term = searchTerm.toLowerCase().trim();
      return (
        s.fpsId.toLowerCase().includes(term) ||
        s.dealerName.toLowerCase().includes(term) ||
        s.pendingCardsList.some(
          (c: any) =>
            (c.cardHolderName && c.cardHolderName.toLowerCase().includes(term)) ||
            (c.srcNo && c.srcNo.includes(term))
        )
      );
    });

    return list.sort((a, b) => {
      return sortOrder === 'desc'
        ? b.totalPending - a.totalPending
        : a.totalPending - b.totalPending;
    });
  }, [pendingShops, searchTerm, sortOrder]);

  // Grand totals across all 14 shops
  const grandTotals = useMemo(() => {
    return filteredAndSorted.reduce(
      (acc, s) => {
        acc.totalCards += s.totalCards;
        acc.monthAvailed += s.monthAvailed;
        acc.aayCards += s.aayCards;
        acc.aayPending += s.aayPending;
        acc.phhCards += s.phhCards;
        acc.phhPending += s.phhPending;
        acc.totalPending += s.totalPending;
        return acc;
      },
      {
        totalCards: 0,
        monthAvailed: 0,
        aayCards: 0,
        aayPending: 0,
        phhCards: 0,
        phhPending: 0,
        totalPending: 0
      }
    );
  }, [filteredAndSorted]);

  // Export summary table to CSV/Excel
  const handleExportExcel = () => {
    const headers = [
      'FPS ID',
      'दुकानदाराचे नाव',
      'एकूण कार्डे',
      'AAY प्रलंबित कार्डे',
      'PHH प्रलंबित कार्डे',
      'प्रलंबित टक्केवारी (%)'
    ];

    const rows = filteredAndSorted.map((s) => [
      s.fpsId,
      s.dealerName,
      s.totalCards,
      s.aayPending,
      s.phhPending,
      `${s.pendingPct}%`
    ]);

    rows.push([
      'एकूण बेरीज',
      '',
      grandTotals.totalCards,
      grandTotals.aayPending,
      grandTotals.phhPending,
      grandTotals.totalCards > 0
        ? `${((grandTotals.totalPending / grandTotals.totalCards) * 100).toFixed(1)}%`
        : '0%'
    ]);

    exportToCsv(`मेहकर_१४_दुकाने_प्रलंबित_शिधापत्रिका_${currentMonth}`, headers, rows);
  };

  // Print PDF of the summary table
  const handlePrintPdf = () => {
    printFormattedReport({
      title: 'मेहकर शहर अधिकृत १४ दुकाने - प्रलंबित शिधापत्रिका अहवाल (AAY व PHH)',
      subtitle: `महिना: ${currentMonth} · ज्या कार्डधारकांनी धान्य घेतलेले नाही अशा प्रलंबित कार्डांची दुकानानिहाय यादी (epos.mahafood.gov.in)`,
      sections: [
        {
          headers: [
            'FPS ID',
            'दुकानदाराचे नाव',
            'एकूण कार्डे',
            'AAY प्रलंबित',
            'PHH प्रलंबित',
            'प्रलंबित %'
          ],
          rows: filteredAndSorted.map((s) => [
            s.fpsId,
            s.dealerName,
            s.totalCards,
            s.aayPending,
            s.phhPending,
            `${s.pendingPct}%`
          ]),
          footerRow: [
            'एकूण बेरीज',
            '',
            grandTotals.totalCards,
            grandTotals.aayPending,
            grandTotals.phhPending,
            grandTotals.totalCards > 0
              ? `${((grandTotals.totalPending / grandTotals.totalCards) * 100).toFixed(1)}%`
              : '0%'
          ]
        }
      ]
    });
  };

  // Print PDF of a single shop's pending RC list - strictly scheme-wise!
  const handlePrintShopRcList = (
    shop: typeof pendingShops[0],
    filter: 'ALL' | 'AAY' | 'PHH' = schemeFilter
  ) => {
    let list: any[] = [];
    let schemeTitle = 'सर्व प्रलंबित शिधापत्रिका यादी (AAY + PHH)';
    let countText = `एकूण प्रलंबित कार्डे: ${shop.totalPending}`;
    let sectionHeading = '';

    if (filter === 'AAY') {
      // 100% strictly AAY cards only - never mix PHH!
      list = shop.pendingCardsList.filter(
        (c: any) => String(c.scheme || '').trim().toUpperCase() === 'AAY'
      );
      schemeTitle = 'AAY (अंत्योदय) प्रलंबित शिधापत्रिका यादी';
      countText = `फक्त AAY प्रलंबित कार्डे: ${list.length}`;
      sectionHeading = `फक्त AAY (अंत्योदय) प्रलंबित १२-अंकी शिधापत्रिका क्रमांक व कुटुंब प्रमुख यादी (एकूण: ${list.length} कार्डे)`;
    } else if (filter === 'PHH') {
      // 100% strictly PHH cards only - never mix AAY!
      list = shop.pendingCardsList.filter(
        (c: any) => String(c.scheme || '').trim().toUpperCase() === 'PHH'
      );
      schemeTitle = 'PHH (प्राधान्य कुटुंब) प्रलंबित शिधापत्रिका यादी';
      countText = `फक्त PHH प्रलंबित कार्डे: ${list.length}`;
      sectionHeading = `फक्त PHH (प्राधान्य कुटुंब) प्रलंबित १२-अंकी शिधापत्रिका क्रमांक व कुटुंब प्रमुख यादी (एकूण: ${list.length} कार्डे)`;
    } else {
      list = shop.pendingCardsList;
      schemeTitle = 'सर्व प्रलंबित शिधापत्रिका यादी (AAY + PHH एकत्रित)';
      countText = `एकूण प्रलंबित कार्डे: ${list.length}`;
      sectionHeading = `सर्व (AAY + PHH) प्रलंबित १२-अंकी शिधापत्रिका क्रमांक व कुटुंब प्रमुख यादी (एकूण: ${list.length} कार्डे)`;
    }

    printFormattedReport({
      title: `${schemeTitle} - ${shop.dealerName}`,
      subtitle: `दुकान कोड (FPS ID): ${shop.fpsId} · मेहकर शहर · ${countText} · महिना: ${currentMonth}`,
      sections: [
        {
          heading: sectionHeading,
          headers: ['क्र.', 'शिधापत्रिका क्र. (SRC)', 'कुटुंब प्रमुखाचे नाव (English Name)', 'योजना', 'सदस्य'],
          rows: list.map((card, i) => [
            i + 1,
            card.srcNo,
            card.cardHolderName || '-',
            card.scheme,
            card.units ? `${card.units} सदस्य` : '४ सदस्य'
          ])
        }
      ]
    });
  };

  // Print PDF of all shops' pending RC list strictly by scheme (AAY or PHH or ALL)
  const handlePrintAllShopsSchemeRcList = (scheme: 'AAY' | 'PHH' | 'ALL') => {
    const isAay = scheme === 'AAY';
    const isPhh = scheme === 'PHH';
    const schemeLabel = isAay ? 'AAY (अंत्योदय)' : isPhh ? 'PHH (प्राधान्य कुटुंब)' : 'सर्व (AAY + PHH)';
    const totalCount = isAay
      ? grandTotals.aayPending
      : isPhh
      ? grandTotals.phhPending
      : grandTotals.totalPending;

    const sections: any[] = [];
    filteredAndSorted.forEach((shop) => {
      const cards = shop.pendingCardsList.filter((c: any) => {
        const s = String(c.scheme || '').trim().toUpperCase();
        if (isAay) return s === 'AAY';
        if (isPhh) return s === 'PHH';
        return true;
      });

      if (cards.length > 0) {
        sections.push({
          heading: `${shop.dealerName} (FPS: ${shop.fpsId}) - ${schemeLabel} प्रलंबित ${cards.length} कार्डे`,
          headers: ['क्र.', 'शिधापत्रिका क्र. (SRC)', 'कुटुंब प्रमुखाचे नाव (English Name)', 'योजना', 'सदस्य'],
          rows: cards.map((c: any, i: number) => [
            i + 1,
            c.srcNo,
            c.cardHolderName || '-',
            c.scheme,
            c.units ? `${c.units} सदस्य` : '४ सदस्य'
          ])
        });
      }
    });

    printFormattedReport({
      title: `मेहकर शहर १४ दुकाने - ${schemeLabel} प्रलंबित शिधापत्रिका यादी`,
      subtitle: `महिना: ${currentMonth} · एकूण प्रलंबित कार्डे: ${totalCount} (epos.mahafood.gov.in)`,
      sections
    });
  };

  // Export full pending RC list for all shops to Excel
  const handleExportAllRcsExcel = () => {
    const headers = [
      'क्र.',
      'FPS ID',
      'दुकानदाराचे नाव',
      'शिधापत्रिका क्र. (SRC Number)',
      'कुटुंब प्रमुखाचे नाव (English Name)',
      'योजना',
      'सदस्य संख्या'
    ];

    const rows: (string | number)[][] = [];
    let count = 1;

    filteredAndSorted.forEach((shop) => {
      shop.pendingCardsList.forEach((c: any) => {
        rows.push([
          count++,
          shop.fpsId,
          shop.dealerName,
          c.srcNo,
          c.cardHolderName || '-',
          c.scheme,
          c.units || 4
        ]);
      });
    });

    exportToCsv('मेहकर_सर्व_१४_दुकाने_प्रलंबित_RC_कार्डधारक_यादी', headers, rows);
  };

  return (
    <div className="space-y-4 font-devanagari">
      {/* Toast Alert for Avail/Undo Action */}
      {toastMsg && (
        <div className="bg-emerald-800 text-white text-xs sm:text-sm font-bold px-4 py-3 rounded-2xl shadow-lg flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2 border border-emerald-600">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
            <span>{toastMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setToastMsg(null)}
            className="text-emerald-200 hover:text-white font-mono text-sm px-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-700" />
              दुकाननिहाय व योजनानिहाय प्रलंबित शिधापत्रिका अहवाल
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              चालू महिन्यात ज्यांनी धान्य घेतलेले नाही अशा १४ दुकानांमधील AAY व PHH प्रलंबित शिधापत्रिका (epos.mahafood.gov.in)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Government-style Month & Year Picker */}
            {onMonthChange && (
              <MonthYearPicker
                currentMonth={currentMonth}
                onMonthChange={onMonthChange}
              />
            )}

            {/* Export All RCs to Excel */}
            <button
              type="button"
              onClick={handleExportAllRcsExcel}
              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              title="सर्व प्रलंबित RC नंबर Excel मध्ये सेव्ह करा"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>सर्व RC Excel</span>
            </button>

            {/* Scheme-wise PDF buttons across all 14 shops */}
            <button
              type="button"
              onClick={() => handlePrintAllShopsSchemeRcList('AAY')}
              className="px-3 py-1.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              title="सर्व १४ दुकानांमधील फक्त AAY (अंत्योदय) प्रलंबित यादी PDF डाऊनलोड करा"
            >
              <Printer className="w-3.5 h-3.5 text-amber-200" />
              <span>AAY यादी PDF ({grandTotals.aayPending})</span>
            </button>

            <button
              type="button"
              onClick={() => handlePrintAllShopsSchemeRcList('PHH')}
              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              title="सर्व १४ दुकानांमधील फक्त PHH (प्राधान्य कुटुंब) प्रलंबित यादी PDF डाऊनलोड करा"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-200" />
              <span>PHH यादी PDF ({grandTotals.phhPending})</span>
            </button>

            {/* Print Summary PDF */}
            <button
              type="button"
              onClick={handlePrintPdf}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              title="सर्व १४ दुकानांचा सारांश अहवाल PDF"
            >
              <Printer className="w-3.5 h-3.5 text-slate-300" />
              <span>१४ दुकाने सारांश PDF</span>
            </button>

            {/* Live Data Sync & Refresh Button */}
            {onRefresh && (
              <button
                type="button"
                onClick={onRefresh}
                disabled={isRefreshing}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-all ${
                  isRefreshing
                    ? 'bg-amber-100 text-amber-800 border border-amber-300 cursor-not-allowed'
                    : 'bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-700 hover:to-amber-700 text-white active:scale-97'
                }`}
                title="महाफूड ePOS सर्व्हरशी थेट जोडणी करून ताजी आकडेवारी व प्रलंबित कार्डे त्वरित सिंक करा"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-200' : ''}`} />
                <span>{isRefreshing ? 'सिंक...' : 'डेटा सिंक'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Search & Sort Controls */}
        <div className="mt-3.5 pt-3.5 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="दुकानदार, FPS ID किंवा कुटुंब प्रमुखाचे इंग्लिश नाव / SRC शोधा..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
              className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 font-semibold text-slate-700 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>प्रलंबित कार्डे: {sortOrder === 'desc' ? 'सर्वाधिक प्रथम' : 'कमी प्रथम'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Scheme Summary Card matching: बाकी कार्ड मे सर्व (705) | AAY (78) | PHH (627) */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-700">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-extrabold text-amber-300">
                दुकाननिहाय बाकी कार्डे (प्रलंबित तपशील व योजनानिहाय PDF डाउनलोड)
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              खालील योजना निवडून फक्त त्याच योजनेची वेगळी PDF डाऊनलोड करा (AAY व PHH एकत्र होणार नाही).
            </p>
          </div>

          {/* 3 Prominent Stat Badges */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="bg-white/10 border border-white/20 px-3.5 py-2 rounded-xl text-center">
              <div className="text-[11px] text-slate-300 font-bold">बाकी कार्ड सर्व</div>
              <div className="text-base font-black text-white font-mono">{grandTotals.totalPending}</div>
            </div>
            <div className="bg-amber-900/40 border border-amber-500/40 px-3.5 py-2 rounded-xl text-center">
              <div className="text-[11px] text-amber-200 font-bold">AAY बाकी कार्डे</div>
              <div className="text-base font-black text-amber-300 font-mono">{grandTotals.aayPending}</div>
            </div>
            <div className="bg-emerald-900/40 border border-emerald-500/40 px-3.5 py-2 rounded-xl text-center">
              <div className="text-[11px] text-emerald-200 font-bold">PHH बाकी कार्डे</div>
              <div className="text-base font-black text-emerald-300 font-mono">{grandTotals.phhPending}</div>
            </div>
          </div>
        </div>

        {/* Action Buttons for downloading Scheme-wise PDF */}
        <div className="mt-3.5 pt-3.5 border-t border-white/10 flex flex-wrap items-center gap-2.5">
          <span className="text-xs font-bold text-slate-300">थेट योजनानिहाय यादी डाऊनलोड:</span>
          <button
            type="button"
            onClick={() => handlePrintAllShopsSchemeRcList('AAY')}
            className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-97"
            title="सर्व दुकानांची फक्त AAY (अंत्योदय) प्रलंबित यादी PDF (PHH वगळून)"
          >
            <Printer className="w-3.5 h-3.5 text-amber-200" />
            <span>📥 AAY प्रलंबित यादी PDF ({grandTotals.aayPending} कार्डे)</span>
          </button>
          <button
            type="button"
            onClick={() => handlePrintAllShopsSchemeRcList('PHH')}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-97"
            title="सर्व दुकानांची फक्त PHH (प्राधान्य कुटुंब) प्रलंबित यादी PDF (AAY वगळून)"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-200" />
            <span>📥 PHH प्रलंबित यादी PDF ({grandTotals.phhPending} कार्डे)</span>
          </button>
        </div>
      </div>

      {/* Main Table: Shop-wise with AAY & PHH Pending and Expandable Card List */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-devanagari">
            <thead className="bg-slate-100 border-b border-slate-200 text-slate-700 uppercase text-[11px] font-bold">
              <tr>
                <th className="py-2.5 px-3">FPS ID</th>
                <th className="py-2.5 px-3">दुकानदार</th>
                <th className="py-2.5 px-3 text-right">एकूण कार्डे</th>
                <th className="py-2.5 px-3 text-right text-amber-950 bg-amber-50/70">AAY प्रलंबित</th>
                <th className="py-2.5 px-3 text-right text-emerald-950 bg-emerald-50/70">PHH प्रलंबित</th>
                <th className="py-2.5 px-3 text-right">प्रलंबित %</th>
                <th className="py-2.5 px-3 text-center">RC यादी व PDF</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAndSorted.map((shop) => {
                const isExpanded = expandedFpsId === shop.fpsId;
                const activeMode = cardListMode[shop.fpsId] || 'pending';
                const sourceCards = activeMode === 'pending' ? shop.pendingCardsList : shop.availedCardsList;
                const displayedCards = sourceCards.filter((c: any) => {
                  if (schemeFilter !== 'ALL' && c.scheme !== schemeFilter) return false;
                  if (searchTerm.trim()) {
                    const term = searchTerm.toLowerCase().trim();
                    const matchesShop =
                      shop.fpsId.toLowerCase().includes(term) || shop.dealerName.toLowerCase().includes(term);
                    const matchesCard =
                      (c.cardHolderName && c.cardHolderName.toLowerCase().includes(term)) ||
                      (c.srcNo && c.srcNo.includes(term));
                    return matchesShop || matchesCard;
                  }
                  return true;
                });

                return (
                  <React.Fragment key={shop.fpsId}>
                    <tr
                      onClick={() => setExpandedFpsId(isExpanded ? null : shop.fpsId)}
                      className="hover:bg-slate-50/90 cursor-pointer transition-colors"
                    >
                      <td className="py-2.5 px-3 font-mono font-bold text-amber-900">
                        {shop.fpsId}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900">
                        {shop.dealerName}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-800 tabular-nums">
                        {shop.totalCards}
                      </td>
                      <td className="py-2.5 px-3 text-right font-extrabold text-amber-950 tabular-nums bg-amber-50/40">
                        {shop.aayPending}
                      </td>
                      <td className="py-2.5 px-3 text-right font-extrabold text-emerald-950 tabular-nums bg-emerald-50/40">
                        {shop.phhPending}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-800 tabular-nums">
                        {shop.pendingPct}%
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setExpandedFpsId(isExpanded ? null : shop.fpsId);
                          }}
                          className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-amber-100 text-amber-900 hover:bg-amber-200 transition-colors flex items-center gap-1 mx-auto cursor-pointer"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>{isExpanded ? 'बंद करा' : 'RC यादी'}</span>
                          {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                        </button>
                      </td>
                    </tr>

                    {/* EXPANDABLE SECTION: Pending or Availed RC Numbers with Scheme & Cardholder Name */}
                    {isExpanded && (
                      <tr className="bg-amber-50/20">
                        <td colSpan={7} className="p-3 sm:p-5 border-b border-amber-200">
                          <div className="bg-white rounded-2xl p-4 border border-amber-300 shadow-md space-y-3">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                              <div>
                                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2 flex-wrap">
                                  <Clock className="w-4 h-4 text-amber-700" />
                                  <span>{shop.dealerName} (FPS: {shop.fpsId})</span>
                                  {/* Toggle between Pending Cards and Availed Cards */}
                                  <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-xs">
                                    <button
                                      type="button"
                                      onClick={() => setCardListMode((prev) => ({ ...prev, [shop.fpsId]: 'pending' }))}
                                      className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                                        activeMode === 'pending'
                                          ? 'bg-amber-800 text-white shadow-xs'
                                          : 'text-slate-600 hover:text-slate-900'
                                      }`}
                                    >
                                      ⏳ प्रलंबित कार्डे ({shop.totalPending})
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => setCardListMode((prev) => ({ ...prev, [shop.fpsId]: 'availed' }))}
                                      className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                                        activeMode === 'availed'
                                          ? 'bg-emerald-800 text-white shadow-xs'
                                          : 'text-slate-600 hover:text-slate-900'
                                      }`}
                                    >
                                      ✅ वाटप झालेली कार्डे ({shop.availedCardsList.length})
                                    </button>
                                  </div>
                                </h4>
                                <p className="text-xs text-slate-500 mt-1">
                                  {activeMode === 'pending'
                                    ? 'ज्या शिधापत्रिकाधारकांनी अद्याप धान्य घेतलेले नाही त्यांची अधिकृत यादी. (माल दिल्यास ‘धान्य वाटप’ बटण दाबा).'
                                    : 'या महिन्यात चालू दुकानात किंवा पोर्टेबिलिटीने धान्य घेतलेल्या कार्डांची यादी.'}
                                </p>
                              </div>

                              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2.5">
                                {/* Scheme Filter for this list */}
                                <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-bold border border-slate-300">
                                  <button
                                    type="button"
                                    onClick={() => setSchemeFilter('ALL')}
                                    className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all ${
                                      schemeFilter === 'ALL'
                                        ? 'bg-slate-900 text-white shadow-xs'
                                        : 'text-slate-700 hover:text-slate-950'
                                    }`}
                                  >
                                    सर्व ({sourceCards.length})
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setSchemeFilter('AAY')}
                                    className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all ${
                                      schemeFilter === 'AAY'
                                        ? 'bg-amber-700 text-white shadow-xs'
                                        : 'text-slate-700 hover:text-amber-900'
                                    }`}
                                  >
                                    AAY ({sourceCards.filter((c: any) => c.scheme === 'AAY').length})
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setSchemeFilter('PHH')}
                                    className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all ${
                                      schemeFilter === 'PHH'
                                        ? 'bg-emerald-700 text-white shadow-xs'
                                        : 'text-slate-700 hover:text-emerald-900'
                                    }`}
                                  >
                                    PHH ({sourceCards.filter((c: any) => c.scheme === 'PHH').length})
                                  </button>
                                </div>

                                {/* Scheme-wise PDF Download Buttons */}
                                <div className="flex items-center gap-2 flex-wrap">
                                  <button
                                    type="button"
                                    onClick={() => handlePrintShopRcList(shop, 'AAY')}
                                    className="px-3 py-1.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-97"
                                    title="फक्त AAY (अंत्योदय) प्रलंबित यादी PDF डाऊनलोड करा"
                                  >
                                    <Printer className="w-3.5 h-3.5 text-amber-200" />
                                    <span>📥 AAY यादी PDF ({shop.aayPending})</span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => handlePrintShopRcList(shop, 'PHH')}
                                    className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-97"
                                    title="फक्त PHH (प्राधान्य कुटुंब) प्रलंबित यादी PDF डाऊनलोड करा"
                                  >
                                    <Printer className="w-3.5 h-3.5 text-emerald-200" />
                                    <span>📥 PHH यादी PDF ({shop.phhPending})</span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => handlePrintShopRcList(shop, 'ALL')}
                                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-97"
                                    title="सर्व (AAY + PHH) एकत्रित यादी PDF डाऊनलोड करा"
                                  >
                                    <Printer className="w-3.5 h-3.5 text-slate-300" />
                                    <span>📥 सर्व बाकी PDF ({shop.totalPending})</span>
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* Clean Table: Cr., SRC Number, Cardholder Name, Scheme, Units, Actions */}
                            <div className="overflow-x-auto max-h-80 rounded-xl border border-slate-200">
                              <table className="w-full text-left text-xs font-devanagari">
                                <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 text-slate-700 uppercase text-[10px] font-bold z-10">
                                  <tr>
                                    <th className="py-2 px-3 w-12 text-center">क्र.</th>
                                    <th className="py-2 px-3">शिधापत्रिका क्र. (SRC)</th>
                                    <th className="py-2 px-3">कुटुंब प्रमुखाचे नाव (English Name)</th>
                                    <th className="py-2 px-3 w-20 text-center">योजना</th>
                                    <th className="py-2 px-3 w-16 text-center">सदस्य</th>
                                    <th className="py-2 px-3 w-48 text-center">कृती व तपशील</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                  {displayedCards.map((c: any, idx: number) => (
                                    <tr key={c.srcNo + idx} className="hover:bg-slate-50">
                                      <td className="py-2 px-3 font-mono text-slate-400 text-center">{idx + 1}</td>
                                      <td className="py-2 px-3 font-mono font-bold text-slate-900">
                                        {c.srcNo}
                                      </td>
                                      <td className="py-2 px-3 font-bold text-slate-900 font-mono tracking-wide">
                                        {c.cardHolderName || 'उपलब्ध नाही'}
                                      </td>
                                      <td className="py-2 px-3 text-center">
                                        <span
                                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                            c.scheme === 'AAY'
                                              ? 'bg-amber-100 text-amber-950 border border-amber-300'
                                              : 'bg-emerald-100 text-emerald-950 border border-emerald-300'
                                          }`}
                                        >
                                          {c.scheme}
                                        </span>
                                      </td>
                                      <td className="py-2 px-3 text-center font-mono font-semibold text-slate-700">
                                        {c.units ? `${c.units}` : '४'}
                                      </td>

                                      <td className="py-2 px-3 text-center">
                                        <div className="flex items-center justify-center gap-1.5 flex-wrap">
                                          {activeMode === 'pending' ? (
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                handleMarkCardAvailed(shop.fpsId, c);
                                              }}
                                              className="px-2 py-1 rounded-md text-[11px] font-bold bg-emerald-700 hover:bg-emerald-800 text-white transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                                              title="या कार्डला थेट धान्य वाटप करा व ई-पॉस नोंद करा"
                                            >
                                              <Check className="w-3 h-3 text-emerald-200" />
                                              <span>धान्य वाटप</span>
                                            </button>
                                          ) : (
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                handleUndoAvailed(shop.fpsId, c.srcNo);
                                              }}
                                              className="px-2 py-1 rounded-md text-[11px] font-bold bg-rose-700 hover:bg-rose-800 text-white transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                                              title="हे वाटप रद्द करा व कार्ड पुन्हा प्रलंबित करा"
                                            >
                                              <RotateCcw className="w-3 h-3 text-rose-200" />
                                              <span>पूर्ववत करा</span>
                                            </button>
                                          )}

                                          {onViewRcDetail && (
                                            <button
                                              type="button"
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                onViewRcDetail(c.srcNo);
                                              }}
                                              className="px-2 py-1 rounded-md text-[11px] font-bold bg-amber-800 hover:bg-amber-900 text-white transition-colors cursor-pointer inline-flex items-center gap-1 shadow-2xs"
                                              title="या कार्डचा संपूर्ण ePOS तपशील पहा"
                                            >
                                              <FileText className="w-3 h-3 text-amber-200" />
                                              <span>तपशील</span>
                                            </button>
                                          )}
                                        </div>
                                      </td>
                                    </tr>
                                  ))}

                                  {displayedCards.length === 0 && (
                                    <tr>
                                      <td colSpan={6} className="py-8 text-center text-slate-500 font-devanagari">
                                        {activeMode === 'pending'
                                          ? 'अभिनंदन! या योजनेतील सर्व कार्डधारकांना धान्य वाटप पूर्ण झाले आहे (कोणतेही कार्ड बाकी नाही).'
                                          : 'या यादीत अद्याप कोणतीही कार्डे उपलब्ध नाहीत.'}
                                      </td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>

            {/* Table Footer with Grand Totals */}
            <tfoot className="bg-amber-50/95 border-t-2 border-amber-300 font-bold text-xs sticky bottom-0">
              <tr>
                <td colSpan={2} className="py-3 px-3 text-slate-900 font-extrabold">
                  एकूण टोटल ({filteredAndSorted.length} दुकाने)
                </td>
                <td className="py-3 px-3 text-right font-extrabold text-slate-950 tabular-nums">
                  {grandTotals.totalCards}
                </td>
                <td className="py-3 px-3 text-right font-extrabold text-amber-950 tabular-nums bg-amber-100/60">
                  {grandTotals.aayPending}
                </td>
                <td className="py-3 px-3 text-right font-extrabold text-emerald-950 tabular-nums bg-emerald-100/60">
                  {grandTotals.phhPending}
                </td>
                <td className="py-3 px-3 text-right font-extrabold text-rose-950 tabular-nums bg-rose-100/60">
                  {grandTotals.totalPending}
                </td>
                <td className="py-3 px-3 text-right font-extrabold text-slate-900 tabular-nums">
                  {grandTotals.totalCards > 0
                    ? `${((grandTotals.totalPending / grandTotals.totalCards) * 100).toFixed(1)}%`
                    : '0%'}
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
