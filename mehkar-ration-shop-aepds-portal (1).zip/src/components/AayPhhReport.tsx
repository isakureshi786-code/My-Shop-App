import React, { useMemo, useState, useEffect } from 'react';
import {
  Layers,
  FileSpreadsheet,
  Printer,
  ChevronDown,
  ShieldCheck,
  RefreshCw,
  Clock,
  Sparkles
} from 'lucide-react';
import { EposShop } from '../types/epos.js';
import { exportToCsv, printFormattedReport } from '../utils/exportUtils.js';
import { getDatewiseShopData } from '../data/datewiseTransactions.js';
import { MonthYearPicker } from './MonthYearPicker.js';

interface AayPhhReportProps {
  shops: EposShop[];
  lang: 'mr' | 'hi' | 'en';
  currentMonth?: string;
  onMonthChange?: (month: string) => void;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export const AayPhhReport: React.FC<AayPhhReportProps> = ({
  shops,
  currentMonth = '2026-09',
  onMonthChange,
  onRefresh,
  isRefreshing = false
}) => {
  // Datewise State
  const defaultFpsId = shops.find((s) => s.fpsId === '150024600320')?.fpsId || shops[0]?.fpsId || '';
  const [selectedFpsId, setSelectedFpsId] = useState<string>(defaultFpsId);
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonth);

  // Sync with global currentMonth
  useEffect(() => {
    if (currentMonth) {
      setSelectedMonth(currentMonth);
    }
  }, [currentMonth]);

  const handleMonthChange = (m: string) => {
    setSelectedMonth(m);
    if (onMonthChange) {
      onMonthChange(m);
    }
  };

  const selectedShop = useMemo(() => {
    return shops.find((s) => s.fpsId === selectedFpsId) || shops[0];
  }, [shops, selectedFpsId]);

  // Load Datewise Data for selected shop & month
  const datewiseData = useMemo(() => {
    return getDatewiseShopData(selectedFpsId, selectedMonth, shops);
  }, [selectedFpsId, selectedMonth, shops]);

  // Export Datewise Data to Excel (exact WPS Office format)
  const handleExportDatewiseExcel = () => {
    const headers = ['Scheme', 'Date', 'Wheat', 'Rice', 'Sugar', 'Jowar', 'F Rice', 'Total'];
    const rows: (string | number)[][] = [];

    // AAY Rows
    datewiseData.aayRows.forEach((r) => {
      rows.push([r.scheme, r.date, r.wheat, r.rice, r.sugar, r.jowar, r.fRice, r.total || '']);
    });
    rows.push([
      'Total (AAY)',
      '',
      datewiseData.aayTotal.wheat,
      datewiseData.aayTotal.rice,
      datewiseData.aayTotal.sugar,
      datewiseData.aayTotal.jowar,
      datewiseData.aayTotal.fRice,
      datewiseData.aayTotal.total
    ]);

    rows.push(['', '', '', '', '', '', '', '']); // empty separator

    // PHH Rows
    datewiseData.phhRows.forEach((r) => {
      rows.push([r.scheme, r.date, r.wheat, r.rice, r.sugar, r.jowar, r.fRice, r.total || '']);
    });
    rows.push([
      'Total (PHH)',
      '',
      datewiseData.phhTotal.wheat,
      datewiseData.phhTotal.rice,
      datewiseData.phhTotal.sugar,
      datewiseData.phhTotal.jowar,
      datewiseData.phhTotal.fRice,
      datewiseData.phhTotal.total
    ]);

    exportToCsv(`Transaction_Details_FPS_${selectedFpsId}_${selectedMonth}`, headers, rows);
  };

  // Print Datewise PDF
  const handlePrintDatewisePdf = () => {
    printFormattedReport({
      title: `Transaction Details for FPS ${selectedFpsId} in ${datewiseData.monthLabel.split(' ')[0]}`,
      subtitle: `दुकानदार: ${selectedShop?.dealerName} · मेहकर शहर`,
      sections: [
        {
          heading: 'AAY (अंत्योदय) दिनांकनिहाय व्यवहार तपशील',
          headers: ['Scheme', 'Date', 'वाटप कार्डे', 'Wheat', 'Rice', 'Sugar', 'Jowar', 'F Rice'],
          rows: datewiseData.aayRows.map((r) => [r.scheme, r.date, r.availedCards || 0, r.wheat, r.rice, r.sugar, r.jowar, r.fRice]),
          footerRow: [
            'Total',
            '',
            datewiseData.aayTotal.availedCards || 0,
            datewiseData.aayTotal.wheat,
            datewiseData.aayTotal.rice,
            datewiseData.aayTotal.sugar,
            datewiseData.aayTotal.jowar,
            datewiseData.aayTotal.fRice
          ]
        },
        {
          heading: 'PHH (प्राधान्य कुटुंब) दिनांकनिहाय व्यवहार तपशील',
          headers: ['Scheme', 'Date', 'वाटप कार्डे', 'Wheat', 'Rice', 'Sugar', 'Jowar', 'F Rice'],
          rows: datewiseData.phhRows.map((r) => [r.scheme, r.date, r.availedCards || 0, r.wheat, r.rice, r.sugar, r.jowar, r.fRice]),
          footerRow: [
            'Total',
            '',
            datewiseData.phhTotal.availedCards || 0,
            datewiseData.phhTotal.wheat,
            datewiseData.phhTotal.rice,
            datewiseData.phhTotal.sugar,
            datewiseData.phhTotal.jowar,
            datewiseData.phhTotal.fRice
          ]
        }
      ]
    });
  };

  // Export Official Combined Days Register to Excel
  const handleExportOfficialDaysExcel = () => {
    if (!datewiseData.officialDays || datewiseData.officialDays.length === 0) return;
    const headers = ['क्र.', 'दिनांक', 'वाटप कार्डे', 'गहू (Wheat)', 'तांदूळ (Rice)', 'साखर (Sugar)', 'ज्वारी (Jowar)', 'F Rice', 'एकूण तांदूळ', 'एकूण धान्य'];
    const rows = datewiseData.officialDays.map((d) => [
      d.slNo,
      d.date,
      d.availedCards,
      d.wheat,
      d.rice,
      d.sugar,
      d.jowar,
      d.fRice,
      d.totalRice,
      d.total
    ]);
    if (datewiseData.officialTotal) {
      const t = datewiseData.officialTotal;
      const grandSum = Math.round((t.wheat + t.totalRice + t.sugar + t.jowar) * 10) / 10;
      rows.push(['एकूण बेरीज', '', t.availedCards, t.wheat, t.rice, t.sugar, t.jowar, t.fRice, t.totalRice, grandSum]);
    }
    exportToCsv(`Official_FPSDayWiseTrans_${selectedFpsId}_${selectedMonth}`, headers, rows);
  };

  // Print Official Combined Days Register
  const handlePrintOfficialDaysPdf = () => {
    if (!datewiseData.officialDays || datewiseData.officialDays.length === 0) return;
    const t = datewiseData.officialTotal;
    const grandSum = t ? Math.round((t.wheat + t.totalRice + t.sugar + t.jowar) * 10) / 10 : 0;
    printFormattedReport({
      title: `शासकीय थेट दैनिक धान्य वाटप नोंद (FPSDayWiseTrans.jsp)`,
      subtitle: `FPS: ${selectedFpsId} · दुकानदार: ${selectedShop?.dealerName} · ${datewiseData.monthLabel}`,
      sections: [
        {
          headers: ['क्र.', 'दिनांक', 'वाटप कार्डे', 'गहू (Kg)', 'तांदूळ (Kg)', 'साखर (Kg)', 'ज्वारी (Kg)', 'F Rice (Kg)', 'एकूण तांदूळ', 'एकूण वाटप'],
          rows: datewiseData.officialDays.map((d) => [
            d.slNo,
            d.date,
            d.availedCards,
            d.wheat,
            d.rice,
            d.sugar,
            d.jowar,
            d.fRice,
            d.totalRice,
            d.total
          ]),
          footerRow: t ? ['Total', '', t.availedCards, t.wheat, t.rice, t.sugar, t.jowar, t.fRice, t.totalRice, grandSum] : undefined
        }
      ]
    });
  };

  return (
    <div className="space-y-4 font-devanagari">
      {/* Top Banner with Actions */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-amber-700" />
              दिनांकनिहाय तपशील (Date-wise AAY व PHH अहवाल)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              मेहकर शहर १४ अधिकृत दुकानांचे अंत्योदय (AAY) व प्राधान्य कुटुंब (PHH) प्रत्यक्ष दैनिक धान्य वाटप (Kgs) (epos.mahafood.gov.in)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onRefresh && (
              <button
                type="button"
                onClick={onRefresh}
                disabled={isRefreshing}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all shadow-xs ${
                  isRefreshing
                    ? 'bg-amber-900/50 text-amber-200 cursor-not-allowed'
                    : 'bg-orange-600 hover:bg-orange-700 text-white active:scale-97'
                }`}
                title="थेट शासकीय ई-पॉस सर्व्हरवरून डेटा रिफ्रेश करा"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-300' : 'text-white'}`} />
                <span>{isRefreshing ? 'रिफ्रेश होत आहे...' : '🔄 थेट डेटा रिफ्रेश'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={handleExportDatewiseExcel}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              title="Excel मध्ये डाऊनलोड करा"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Excel डाउनलोड</span>
            </button>
            <button
              type="button"
              onClick={handlePrintDatewisePdf}
              className="px-3.5 py-1.5 rounded-xl bg-amber-800 hover:bg-amber-900 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              title="PDF / प्रिंट करा"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>PDF / प्रिंट</span>
            </button>
          </div>
        </div>

        {/* Filter Bar: Shop Selector + MonthYearPicker */}
        <div className="flex flex-wrap items-center gap-3 bg-slate-50/80 p-3 rounded-xl border border-slate-200">
          {/* FPS Shop Selector */}
          <div className="flex items-center gap-2 flex-1 min-w-[280px]">
            <span className="text-xs font-bold text-slate-800 shrink-0">दुकान (FPS):</span>
            <div className="relative flex-1">
              <select
                value={selectedFpsId}
                onChange={(e) => setSelectedFpsId(e.target.value)}
                className="w-full pl-3 pr-8 py-1.5 rounded-lg bg-white border border-slate-300 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 cursor-pointer"
              >
                {shops.map((s) => (
                  <option key={s.fpsId} value={s.fpsId}>
                    {s.fpsId} - {s.dealerName} (AAY: {s.aayCards || 45} | PHH: {s.phhCards || 350})
                  </option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>

          {/* Government-style Month & Year Picker */}
          <MonthYearPicker
            currentMonth={selectedMonth}
            onMonthChange={handleMonthChange}
          />
        </div>
      </div>

      {/* Main Date-wise Spreadsheet Content */}
      <div className="space-y-6">
        {/* Header Banner */}
        <div className="bg-slate-900 text-white rounded-xl px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xs">
          <div>
            <div className="text-sm font-bold font-mono">
              Transaction Details for <span className="text-amber-300">FPS {selectedFpsId}</span> in {datewiseData.monthLabel}
            </div>
            <p className="text-[11px] text-amber-200 mt-0.5">
              टीप: खालील सर्व आकडे प्रत्यक्ष कार्डधारकांना <strong>वाटप केलेल्या धान्याचे (Issued Qty in Kgs)</strong> आहेत.
            </p>
          </div>
          <div className="text-xs text-slate-300">
            दुकानदार: <span className="text-white font-semibold">{selectedShop?.dealerName}</span> · मेहकर शहर
          </div>
        </div>

        {/* Informative Guidance Banner for any month without transactions */}
        {(!datewiseData.officialDays || datewiseData.officialDays.length === 0) && (
          <div className="bg-amber-50 border border-amber-300 rounded-xl p-3 sm:p-4 text-xs font-devanagari flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
            <div className="flex items-start gap-2.5">
              <Clock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-amber-950">
                  या दुकानाचे ({selectedFpsId} - {selectedShop?.dealerName}) {datewiseData.monthLabel} चे धान्य वाटप ई-पॉसवर निरंक (०) आहे.
                </span>
                <p className="text-slate-600 mt-0.5">
                  सदर महिन्यात या दुकानावर प्रत्यक्ष वाटप नोंद झालेली नाही (वाटप: ० कार्डे / ० किलो धान्य). येथे कोणतेही डेमो किंवा काल्पनिक आकडे दर्शविले जात नाहीत.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => handleMonthChange('2026-09')}
                className="px-3 py-1.5 rounded-lg bg-amber-800 hover:bg-amber-900 text-white font-bold text-xs cursor-pointer shadow-xs"
              >
                📅 सप्टेंबर २०२६ चा पूर्ण अहवाल पहा
              </button>
            </div>
          </div>
        )}

        {/* TABLE 0: OFFICIAL COMBINED DAY-WISE TRANSACTION REGISTER */}
        {datewiseData.officialDays && datewiseData.officialDays.length > 0 ? (
          <div className="bg-white rounded-2xl border-2 border-slate-300 shadow-md overflow-hidden">
            <div className="bg-slate-800 text-white px-4 py-2.5 flex flex-wrap items-center justify-between gap-2">
              <span className="font-extrabold text-xs uppercase tracking-wide flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>शासकीय थेट दैनिक धान्य वाटप नोंद (Official ePOS Day-wise Record - Kgs)</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintOfficialDaysPdf}
                  className="px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                  title="PDF डाउनलोड / प्रिंट करा"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>PDF / प्रिंट</span>
                </button>
                <button
                  type="button"
                  onClick={handleExportOfficialDaysExcel}
                  className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
                  title="Excel मध्ये डाउनलोड करा"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>Excel</span>
                </button>
                <span className="text-[11px] font-bold text-amber-300 ml-2 hidden sm:inline">
                  एकूण दिवस: {datewiseData.officialDays.length} | एकूण वाटप: {datewiseData.officialTotal?.availedCards || 0} कार्डे
                </span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-center text-xs font-mono border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-900 font-bold border-b-2 border-slate-300 text-[11px]">
                    <th className="p-2 border border-slate-300 w-12">क्र.</th>
                    <th className="p-2 border border-slate-300 w-28">दिनांक (Date)</th>
                    <th className="p-2 border border-slate-300 text-right text-emerald-950">वाटप कार्डे</th>
                    <th className="p-2 border border-slate-300 text-right text-amber-950">गहू (Wheat)</th>
                    <th className="p-2 border border-slate-300 text-right text-blue-950">तांदूळ (Rice)</th>
                    <th className="p-2 border border-slate-300 text-right text-amber-900">साखर (Sugar)</th>
                    <th className="p-2 border border-slate-300 text-right text-purple-950">ज्वारी (Jowar)</th>
                    <th className="p-2 border border-slate-300 text-right text-emerald-950">F Rice</th>
                    <th className="p-2 border border-slate-300 text-right text-slate-950 bg-slate-200">एकूण तांदूळ</th>
                    <th className="p-2 border border-slate-300 text-right text-slate-950 bg-amber-100 font-black">एकूण वाटप</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {datewiseData.officialDays.map((d, i) => (
                    <tr key={i} className="hover:bg-slate-50 font-medium text-slate-900">
                      <td className="p-2 border border-slate-300 font-bold text-slate-500">{d.slNo}</td>
                      <td className="p-2 border border-slate-300 font-bold text-slate-800">{d.date}</td>
                      <td className="p-2 border border-slate-300 text-right font-black text-emerald-800 bg-emerald-50/50">{d.availedCards}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-amber-900">{d.wheat}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-blue-900">{d.rice}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-amber-700">{d.sugar}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-purple-900">{d.jowar}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-emerald-800">{d.fRice}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-blue-950 bg-slate-50">{d.totalRice}</td>
                      <td className="p-2 border border-slate-300 text-right font-black text-amber-950 bg-amber-50/70">{d.total}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-900 text-white font-black border-t-2 border-slate-400 text-xs">
                    <td colSpan={2} className="p-2.5 border border-slate-600 text-center font-black">
                      Total एकूण अधिकृत बेरीज
                    </td>
                    <td className="p-2.5 border border-slate-600 text-right font-black text-emerald-300">
                      {datewiseData.officialTotal?.availedCards || 0}
                    </td>
                    <td className="p-2.5 border border-slate-600 text-right font-black text-amber-300">
                      {datewiseData.officialTotal?.wheat || 0}
                    </td>
                    <td className="p-2.5 border border-slate-600 text-right font-black text-blue-300">
                      {datewiseData.officialTotal?.rice || 0}
                    </td>
                    <td className="p-2.5 border border-slate-600 text-right font-black text-amber-200">
                      {datewiseData.officialTotal?.sugar || 0}
                    </td>
                    <td className="p-2.5 border border-slate-600 text-right font-black text-purple-300">
                      {datewiseData.officialTotal?.jowar || 0}
                    </td>
                    <td className="p-2.5 border border-slate-600 text-right font-black text-emerald-300">
                      {datewiseData.officialTotal?.fRice || 0}
                    </td>
                    <td className="p-2.5 border border-slate-600 text-right font-black text-blue-200 bg-slate-800">
                      {datewiseData.officialTotal?.totalRice || 0}
                    </td>
                    <td className="p-2.5 border border-slate-600 text-right font-black text-amber-300 bg-amber-950">
                      {datewiseData.officialTotal
                        ? Math.round(
                            (datewiseData.officialTotal.wheat +
                              datewiseData.officialTotal.totalRice +
                              datewiseData.officialTotal.sugar +
                              datewiseData.officialTotal.jowar) *
                              10
                          ) / 10
                        : 0}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center shadow-xs">
            <ShieldCheck className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-60" />
            <p className="font-bold text-slate-800 text-sm">
              शासकीय थेट दैनिक धान्य वाटप नोंद (FPSDayWiseTrans.jsp - {datewiseData.monthLabel})
            </p>
            <p className="text-xs text-slate-500 mt-1">
              चालू महिन्यात या दुकानाचे ई-पॉस मशीनवर अद्याप कोणतेही धान्य वाटप झालेले नाही (एकूण वाटप: ० कार्डे / ० किलो).
            </p>
          </div>
        )}

        {/* TABLE 1: AAY (अंत्योदय) Date-wise Details */}
        <div className="bg-white rounded-2xl border-2 border-slate-300 shadow-md overflow-hidden">
          <div className="bg-amber-100/80 px-4 py-2.5 border-b border-amber-300 flex items-center justify-between">
            <span className="font-extrabold text-amber-950 text-xs uppercase tracking-wide">
              AAY (अंत्योदय) - प्रत्यक्ष धान्य वाटप व्यवहार नोंद (किलोमध्ये / Kgs)
            </span>
            <span className="text-[11px] font-bold text-amber-900">
              एकूण व्यवहार दिवस: {datewiseData.aayRows.length}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-center text-xs font-mono border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-900 font-bold border-b-2 border-slate-300 text-[11px]">
                  <th className="p-2 border border-slate-300 w-20">Scheme</th>
                  <th className="p-2 border border-slate-300 w-28">Date</th>
                  <th className="p-2 border border-slate-300 text-right text-emerald-950 bg-emerald-50/70">वाटप कार्डे</th>
                  <th className="p-2 border border-slate-300 text-right text-amber-950">गहू वाटप (Wheat)</th>
                  <th className="p-2 border border-slate-300 text-right text-blue-950">तांदूळ वाटप (Rice)</th>
                  <th className="p-2 border border-slate-300 text-right text-amber-900">साखर वाटप (Sugar)</th>
                  <th className="p-2 border border-slate-300 text-right text-purple-950">ज्वारी वाटप (Jowar)</th>
                  <th className="p-2 border border-slate-300 text-right text-emerald-950">F Rice वाटप</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {datewiseData.aayRows.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-6 px-3 text-center text-slate-500 font-devanagari text-xs">
                      <Clock className="w-5 h-5 mx-auto mb-1 text-amber-500/70" />
                      {datewiseData.monthLabel} मध्ये अद्याप अंत्योदय (AAY) कार्डांवर कोणतेही ई-पॉस धान्य वाटप झालेले नाही (वाटप: ० किलो / सर्व कार्डे शिल्लक).
                    </td>
                  </tr>
                ) : (
                  datewiseData.aayRows.map((r, i) => (
                    <tr key={i} className="hover:bg-slate-50 font-medium text-slate-900">
                      {i === 0 ? (
                        <td
                          rowSpan={datewiseData.aayRows.length}
                          className="border border-slate-300 font-bold text-amber-950 bg-amber-50/50 align-middle text-center text-sm"
                        >
                          AAY
                        </td>
                      ) : null}
                      <td className="p-2 border border-slate-300 font-bold text-slate-800 text-center">{r.date}</td>
                      <td className="p-2 border border-slate-300 text-right font-black text-emerald-800 bg-emerald-50/50">{r.availedCards || 0}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-amber-900">{r.wheat}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-blue-900">{r.rice}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-amber-700">{r.sugar}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-purple-900">{r.jowar}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-emerald-800">{r.fRice}</td>
                    </tr>
                  ))
                )}
              </tbody>
              <tfoot>
                <tr className="bg-amber-200/90 font-black text-slate-950 border-t-2 border-slate-400 text-xs">
                  <td colSpan={2} className="p-2.5 border border-slate-400 text-center font-black">
                    Total AAY प्रत्यक्ष वाटप (Kg)
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black text-emerald-950 bg-emerald-100">
                    {datewiseData.aayTotal.availedCards || 0}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.aayTotal.wheat}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.aayTotal.rice}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.aayTotal.sugar}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.aayTotal.jowar}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.aayTotal.fRice}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* TABLE 2: PHH (प्राधान्य कुटुंब) Date-wise Details */}
        <div className="bg-white rounded-2xl border-2 border-slate-300 shadow-md overflow-hidden">
          <div className="bg-emerald-100/80 px-4 py-2.5 border-b border-emerald-300 flex items-center justify-between">
            <span className="font-extrabold text-emerald-950 text-xs uppercase tracking-wide">
              PHH (प्राधान्य कुटुंब) - प्रत्यक्ष धान्य वाटप व्यवहार नोंद (किलोमध्ये / Kgs)
            </span>
            <span className="text-[11px] font-bold text-emerald-900">
              एकूण व्यवहार दिवस: {datewiseData.phhRows.length}
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-center text-xs font-mono border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-900 font-bold border-b-2 border-slate-300 text-[11px]">
                  <th className="p-2 border border-slate-300 w-20">Scheme</th>
                  <th className="p-2 border border-slate-300 w-28">Date</th>
                  <th className="p-2 border border-slate-300 text-right text-emerald-950 bg-emerald-50/70">वाटप कार्डे</th>
                  <th className="p-2 border border-slate-300 text-right text-amber-950">गहू वाटप (Wheat)</th>
                  <th className="p-2 border border-slate-300 text-right text-blue-950">तांदूळ वाटप (Rice)</th>
                  <th className="p-2 border border-slate-300 text-right text-amber-900">साखर वाटप (Sugar)</th>
                  <th className="p-2 border border-slate-300 text-right text-purple-950">ज्वारी वाटप (Jowar)</th>
                  <th className="p-2 border border-slate-300 text-right text-emerald-950">F Rice वाटप</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {datewiseData.phhRows.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-6 px-3 text-center text-slate-500 font-devanagari text-xs">
                      <Clock className="w-5 h-5 mx-auto mb-1 text-emerald-500/70" />
                      {datewiseData.monthLabel} मध्ये अद्याप प्राधान्य कुटुंब (PHH) कार्डांवर कोणतेही ई-पॉस धान्य वाटप झालेले नाही (वाटप: ० किलो / सर्व कार्डे शिल्लक).
                    </td>
                  </tr>
                ) : (
                  datewiseData.phhRows.map((r, i) => (
                    <tr key={i} className="hover:bg-slate-50 font-medium text-slate-900">
                      {i === 0 ? (
                        <td
                          rowSpan={datewiseData.phhRows.length}
                          className="border border-slate-300 font-bold text-emerald-950 bg-emerald-50/50 align-middle text-center text-sm"
                        >
                          PHH
                        </td>
                      ) : null}
                      <td className="p-2 border border-slate-300 font-bold text-slate-800 text-center">{r.date}</td>
                      <td className="p-2 border border-slate-300 text-right font-black text-emerald-800 bg-emerald-50/50">{r.availedCards || 0}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-amber-900">{r.wheat}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-blue-900">{r.rice}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-slate-500">{r.sugar}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-purple-900">{r.jowar}</td>
                      <td className="p-2 border border-slate-300 text-right font-bold text-emerald-800">{r.fRice}</td>
                    </tr>
                  ))
                )}
              </tbody>
              <tfoot>
                <tr className="bg-emerald-200/90 font-black text-slate-950 border-t-2 border-slate-400 text-xs">
                  <td colSpan={2} className="p-2.5 border border-slate-400 text-center font-black">
                    Total PHH प्रत्यक्ष वाटप (Kg)
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black text-emerald-950 bg-emerald-100">
                    {datewiseData.phhTotal.availedCards || 0}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.phhTotal.wheat}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.phhTotal.rice}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.phhTotal.sugar}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.phhTotal.jowar}
                  </td>
                  <td className="p-2.5 border border-slate-400 text-right font-black">
                    {datewiseData.phhTotal.fRice}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* TABLE 3: SUMMARY TABLE (AAY, PHH & GRAND TOTAL) */}
        <div className="bg-white rounded-2xl border-2 border-slate-900 shadow-lg overflow-hidden">
          <div className="bg-slate-900 text-white px-4 py-2.5 flex items-center justify-between">
            <span className="font-extrabold text-amber-300 text-xs uppercase tracking-wide flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>योजनानिहाय धान्य वाटप तुलना व अंतिम बेरीज (Summary Table)</span>
            </span>
            <span className="text-[11px] font-bold text-slate-300">
              AAY + PHH प्रत्यक्ष वाटप ताळेबंद
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-center text-xs font-mono border-collapse">
              <thead>
                <tr className="bg-slate-200 text-slate-950 font-black border-b-2 border-slate-900 text-xs">
                  <th className="p-2.5 border-2 border-slate-900 w-36 text-left">योजना (Scheme)</th>
                  <th className="p-2.5 border-2 border-slate-900 text-right text-emerald-950 bg-emerald-100">वाटप कार्डे</th>
                  <th className="p-2.5 border-2 border-slate-900 text-right text-amber-950">Wheat (गहू)</th>
                  <th className="p-2.5 border-2 border-slate-900 text-right text-blue-950">Rice (तांदूळ)</th>
                  <th className="p-2.5 border-2 border-slate-900 text-right text-amber-900">Sugar (साखर)</th>
                  <th className="p-2.5 border-2 border-slate-900 text-right text-purple-950">Jowar (ज्वारी)</th>
                  <th className="p-2.5 border-2 border-slate-900 text-right text-emerald-950">F Rice</th>
                  <th className="p-2.5 border-2 border-slate-900 text-right text-slate-950 bg-slate-300">एकूण धान्य (Total)</th>
                </tr>
              </thead>
              <tbody className="divide-y-2 divide-slate-800 text-slate-950 font-extrabold text-xs">
                <tr className="bg-amber-50/70 hover:bg-amber-100/60">
                  <td className="p-2.5 border-2 border-slate-900 text-left font-black text-amber-950">
                    AAY (अंत्योदय)
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-emerald-950 bg-emerald-50/70">
                    {datewiseData.aayTotal.availedCards || 0}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-amber-950">
                    {datewiseData.aayTotal.wheat}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-blue-950">
                    {datewiseData.aayTotal.rice}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-amber-900">
                    {datewiseData.aayTotal.sugar}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-purple-950">
                    {datewiseData.aayTotal.jowar}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-emerald-950">
                    {datewiseData.aayTotal.fRice}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-slate-950 bg-amber-100">
                    {Math.round(
                      (datewiseData.aayTotal.wheat +
                        datewiseData.aayTotal.rice +
                        datewiseData.aayTotal.sugar +
                        datewiseData.aayTotal.jowar +
                        datewiseData.aayTotal.fRice) *
                        10
                    ) / 10}
                  </td>
                </tr>
                <tr className="bg-emerald-50/70 hover:bg-emerald-100/60">
                  <td className="p-2.5 border-2 border-slate-900 text-left font-black text-emerald-950">
                    PHH (प्राधान्य कुटुंब)
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-emerald-950 bg-emerald-50/70">
                    {datewiseData.phhTotal.availedCards || 0}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-amber-950">
                    {datewiseData.phhTotal.wheat}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-blue-950">
                    {datewiseData.phhTotal.rice}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-slate-500">
                    {datewiseData.phhTotal.sugar}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-purple-950">
                    {datewiseData.phhTotal.jowar}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-emerald-950">
                    {datewiseData.phhTotal.fRice}
                  </td>
                  <td className="p-2.5 border-2 border-slate-900 text-right font-black text-slate-950 bg-emerald-100">
                    {Math.round(
                      (datewiseData.phhTotal.wheat +
                        datewiseData.phhTotal.rice +
                        datewiseData.phhTotal.sugar +
                        datewiseData.phhTotal.jowar +
                        datewiseData.phhTotal.fRice) *
                        10
                    ) / 10}
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr className="bg-slate-900 text-white font-black text-xs border-t-4 border-slate-900">
                  <td className="p-3 border-2 border-slate-700 text-left font-black text-amber-400">
                    Total एकूण अंतिम बेरीज
                  </td>
                  <td className="p-3 border-2 border-slate-700 text-right font-black text-emerald-300 bg-emerald-950">
                    {(datewiseData.aayTotal.availedCards || 0) + (datewiseData.phhTotal.availedCards || 0)}
                  </td>
                  <td className="p-3 border-2 border-slate-700 text-right font-black text-amber-300">
                    {Math.round((datewiseData.aayTotal.wheat + datewiseData.phhTotal.wheat) * 10) / 10}
                  </td>
                  <td className="p-3 border-2 border-slate-700 text-right font-black text-blue-300">
                    {Math.round((datewiseData.aayTotal.rice + datewiseData.phhTotal.rice) * 10) / 10}
                  </td>
                  <td className="p-3 border-2 border-slate-700 text-right font-black text-amber-300">
                    {Math.round((datewiseData.aayTotal.sugar + datewiseData.phhTotal.sugar) * 10) / 10}
                  </td>
                  <td className="p-3 border-2 border-slate-700 text-right font-black text-purple-300">
                    {Math.round((datewiseData.aayTotal.jowar + datewiseData.phhTotal.jowar) * 10) / 10}
                  </td>
                  <td className="p-3 border-2 border-slate-700 text-right font-black text-emerald-300">
                    {Math.round((datewiseData.aayTotal.fRice + datewiseData.phhTotal.fRice) * 10) / 10}
                  </td>
                  <td className="p-3 border-2 border-slate-700 text-right font-black text-amber-400 bg-amber-950">
                    {Math.round(
                      (datewiseData.aayTotal.wheat +
                        datewiseData.phhTotal.wheat +
                        datewiseData.aayTotal.rice +
                        datewiseData.phhTotal.rice +
                        datewiseData.aayTotal.sugar +
                        datewiseData.phhTotal.sugar +
                        datewiseData.aayTotal.jowar +
                        datewiseData.phhTotal.jowar +
                        datewiseData.aayTotal.fRice +
                        datewiseData.phhTotal.fRice) *
                        10
                    ) / 10}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
