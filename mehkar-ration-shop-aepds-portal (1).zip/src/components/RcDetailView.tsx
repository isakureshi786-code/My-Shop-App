import React, { useState, useEffect } from 'react';
import {
  Search,
  Printer,
  Copy,
  Check,
  ShieldCheck,
  Users,
  Wheat,
  Receipt,
  Building2,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  Info,
  CreditCard,
  Fingerprint,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { RcDetailsResult } from '../types/epos.js';
import { fetchRcDetailsClient, fetchRcDetailsByAadhaarClient } from '../services/eposClientData.js';
import { printFormattedReport } from '../utils/exportUtils.js';

interface RcDetailViewProps {
  initialRcNo?: string | null;
  initialSearchMode?: 'rc' | 'aadhaar';
  currentMonth?: string;
  lang: 'mr' | 'hi' | 'en';
}

const POPULAR_MEHKAR_RCS = [
  { rcNo: '272014426720', name: 'UZMA ISA KURESHI (AAY)', scheme: 'AAY', fpsId: '150024600320', defaultMonth: 'September' },
  { rcNo: '272014430940', name: 'GOSIYA PRVIN J.JURGAMUR RHEMAN KHATIK (PHH)', scheme: 'PHH', fpsId: '150024600320', defaultMonth: 'October' }
];

const POPULAR_AADHAAR_SAMPLES = [
  { aadhaar: '842195026720', label: 'UZMA ISA KURESHI (मेहकर)', dist: 'Buldana' },
  { aadhaar: '652144891042', label: 'अकोला जिल्हा', dist: 'Akola' },
  { aadhaar: '782399123456', label: 'अमरावती जिल्हा', dist: 'Amravati' },
  { aadhaar: '910233815670', label: 'नागपूर जिल्हा', dist: 'Nagpur' },
  { aadhaar: '332188409123', label: 'पुणे जिल्हा', dist: 'Pune' },
  { aadhaar: '445211907865', label: 'छत्रपती संभाजीनगर', dist: 'Chhatrapati Sambhajinagar' }
];

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export const RcDetailView: React.FC<RcDetailViewProps> = ({
  initialRcNo,
  initialSearchMode = 'rc',
  currentMonth = '2026-10',
  lang
}) => {
  const defaultMonthName = currentMonth === '2026-10' ? 'October' : 'September';
  const [searchMode, setSearchMode] = useState<'rc' | 'aadhaar'>(initialSearchMode);
  const [selectedMonth, setSelectedMonth] = useState<string>(defaultMonthName);
  const [selectedYear, setSelectedYear] = useState<string>('2026');
  const [rcInput, setRcInput] = useState<string>(initialRcNo || '272014426720');
  const [aadhaarInput, setAadhaarInput] = useState<string>('842195026720');
  const [loading, setLoading] = useState<boolean>(false);
  const [rcData, setRcData] = useState<RcDetailsResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  // Sync initialSearchMode
  useEffect(() => {
    if (initialSearchMode) {
      setSearchMode(initialSearchMode);
    }
  }, [initialSearchMode]);

  // Fetch details by RC function
  const handleSearch = async (rcToSearch: string, m = selectedMonth, y = selectedYear) => {
    const clean = rcToSearch.trim();
    if (!clean) return;

    setLoading(true);
    setErrorMessage(null);

    try {
      const result = await fetchRcDetailsClient(clean, m, y);
      if (result && result.success) {
        setRcData(result);
      } else {
        setRcData(null);
        setErrorMessage(result?.error || 'या क्रमांकाची शिधापत्रिका सापडली नाही. कृपया १२ अंकी अचूक RC नंबर तपासा.');
      }
    } catch (err: any) {
      console.error('RC search error:', err);
      setErrorMessage('सर्व्हरकडून माहिती आणताना अडचण आली. कृपया पुन्हा प्रयत्न करा.');
    } finally {
      setLoading(false);
    }
  };

  // Fetch details by 12-digit Aadhaar Number (All Maharashtra)
  const handleSearchAadhaar = async (aadhaarToSearch: string, m = selectedMonth, y = selectedYear) => {
    const clean = aadhaarToSearch.replace(/\D/g, '').trim();
    if (!clean) {
      setErrorMessage('कृपया १२ अंकी वैध आधार क्रमांक टाका.');
      return;
    }
    if (clean.length < 12) {
      setErrorMessage('आधार क्रमांक १२ अंकी असणे आवश्यक आहे.');
      return;
    }

    setLoading(true);
    setErrorMessage(null);

    try {
      const result = await fetchRcDetailsByAadhaarClient(clean, m, y);
      if (result && result.success) {
        setRcData(result);
        if (result.rcNo) {
          setRcInput(result.rcNo);
        }
      } else {
        setRcData(null);
        setErrorMessage(result?.error || 'सदर आधार क्रमांकाशी संलग्न शिधापत्रिका सापडली नाही.');
      }
    } catch (err: any) {
      console.error('Aadhaar search error:', err);
      setErrorMessage('सर्व्हरकडून आधार माहिती आणताना अडचण आली. कृपया पुन्हा प्रयत्न करा.');
    } finally {
      setLoading(false);
    }
  };

  // Auto-search on initial load or prop change
  useEffect(() => {
    if (initialSearchMode === 'aadhaar') {
      handleSearchAadhaar(aadhaarInput, selectedMonth, selectedYear);
    } else {
      const targetRc = initialRcNo || '272014426720';
      setRcInput(targetRc);
      handleSearch(targetRc, selectedMonth, selectedYear);
    }
  }, [initialRcNo, initialSearchMode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchMode === 'aadhaar') {
      handleSearchAadhaar(aadhaarInput);
    } else {
      handleSearch(rcInput);
    }
  };

  const handleCopyRc = () => {
    if (rcData?.rcNo) {
      navigator.clipboard.writeText(rcData.rcNo);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // PDF Export
  const handlePrintPdf = () => {
    if (!rcData) return;

    printFormattedReport({
      title: `शिधापत्रिका तपशील अहवाल (RC Details) - ${rcData.rcNo}`,
      subtitle: `जिल्हा: ${rcData.headerInfo.district} · तालुका: ${rcData.headerInfo.taluk} · दुकान क्र. (FPS ID): ${rcData.headerInfo.fpsId} · योजना: ${rcData.headerInfo.scheme}`,
      sections: [
        {
          heading: '१. कुटुंबातील सदस्यांची यादी (Member Details)',
          headers: ['क्र.', 'सदस्याचे नाव (Member)', 'लिंग (Gender)', 'वय (Age)', 'स्थिती (Status)', 'UID आधार'],
          rows: rcData.members.map((m) => [m.slNo, m.member, m.gender, m.age, m.status, m.uid])
        },
        ...(rcData.entitlement
          ? [
              {
                heading: `२. मासिक धान्य हक्क कोटा (Entitlement for RC : ${rcData.rcNo})`,
                headers: [
                  `गहू (Wheat - ${selectedMonth})`,
                  `साखर (Sugar - ${selectedMonth})`,
                  `ज्वारी (Jowar - ${selectedMonth})`,
                  `तांदूळ (FRice - ${selectedMonth})`
                ],
                rows: [
                  [
                    `${rcData.entitlement.wheat} किलो`,
                    `${rcData.entitlement.sugar} किलो`,
                    `${rcData.entitlement.jowar} किलो`,
                    `${rcData.entitlement.fRice} किलो`
                  ]
                ]
              }
            ]
          : []),
        {
          heading: `३. धान्य वाटप व्यवहार तपशील (Transaction Details for RC : ${rcData.rcNo})`,
          headers: [
            'क्र.',
            'सदस्य',
            'दुकान क्र. (FPS)',
            'पावती क्र. (Receipt Id)',
            'महिना/वर्ष',
            'वाटप दिनांक',
            'प्रकार',
            'गहू (Kg)',
            'साखर (Kg)',
            'ज्वारी (Kg)',
            'तांदूळ (Kg)'
          ],
          rows:
            rcData.transactions.length > 0
              ? rcData.transactions.map((tx) => [
                  tx.slNo,
                  tx.member,
                  tx.availedFps,
                  tx.receiptId,
                  `${tx.month} ${tx.year}`,
                  tx.availDate,
                  tx.availType,
                  tx.wheat,
                  tx.sugar,
                  tx.jowar,
                  tx.fRice
                ])
              : [['-', 'कोणताही व्यवहार आढळला नाही (प्रलंबित / Non-Availed)', '-', '-', '-', '-', '-', '0.000', '0.000', '0.000', '0.000']]
        }
      ]
    });
  };

  return (
    <div className="space-y-4 font-sans">
      {/* Official AePDS Government Portal Header Banner matching user screenshot */}
      <div className="bg-gradient-to-r from-[#ba4305] via-[#cf4d07] to-[#8f2f01] text-white rounded-2xl p-4 sm:p-5 shadow-sm border border-amber-900/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-950/40 border border-amber-200/30 flex items-center justify-center text-amber-200 shrink-0 shadow-inner">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold tracking-tight font-serif">
                  Aadhaar enabled Public Distribution System - AePDS
                </h2>
                <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-700/80 text-white">
                  <ShieldCheck className="w-3 h-3 text-emerald-200" />
                  MahaFood Govt
                </span>
              </div>
              <p className="text-xs text-amber-100 font-medium">
                Food, Civil Supplies and Consumer Protection Department · Government of Maharashtra
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto text-xs font-mono bg-black/25 px-3 py-1.5 rounded-xl border border-white/10">
            <span className="text-amber-200 font-semibold font-devanagari">पोर्टल:</span>
            <span className="text-white">epos.mahafood.gov.in/SRC_Trans_Details.jsp</span>
          </div>
        </div>
      </div>

      {/* Government-Style Search Form (Official ePOS SRC Details) */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs">
        <form onSubmit={handleSubmit} className="flex flex-wrap items-center gap-3 text-xs sm:text-sm">
          {/* Month Selector */}
          <div className="flex items-center gap-1.5">
            <label className="font-bold text-slate-800 whitespace-nowrap">Month :</label>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 font-medium focus:outline-hidden focus:ring-2 focus:ring-amber-500 cursor-pointer"
            >
              {MONTHS.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          {/* Year Selector */}
          <div className="flex items-center gap-1.5">
            <label className="font-bold text-slate-800 whitespace-nowrap">Year :</label>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 font-medium focus:outline-hidden focus:ring-2 focus:ring-amber-500 cursor-pointer font-mono"
            >
              <option value="2026">2026</option>
              <option value="2025">2025</option>
              <option value="2024">2024</option>
            </select>
          </div>

          {/* RC Input field */}
          <div className="flex items-center gap-1.5 flex-1 min-w-[240px]">
            <label className="font-bold text-slate-800 whitespace-nowrap">RC No :</label>
            <input
              type="text"
              value={rcInput}
              onChange={(e) => setRcInput(e.target.value)}
              placeholder="Enter 12-digit SRC Number"
              className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 font-mono text-slate-900 font-bold focus:outline-hidden focus:ring-2 focus:ring-amber-500 bg-white placeholder:text-slate-400 placeholder:font-normal"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="px-5 py-1.5 rounded-lg text-white font-bold text-xs sm:text-sm cursor-pointer shadow-xs transition-all flex items-center gap-1.5 active:scale-97 disabled:opacity-60 bg-[#27150c] hover:bg-[#1a0e08]"
          >
            {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-300" /> : <Search className="w-3.5 h-3.5 text-amber-300" />}
            <span>{loading ? 'Searching...' : 'Submit'}</span>
          </button>
        </form>
      </div>

      {/* Error state */}
      {errorMessage && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 text-xs sm:text-sm text-rose-800 font-devanagari flex items-center gap-2">
          <Info className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Loading state */}
      {loading && (
        <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-3 shadow-xs">
          <RefreshCw className="w-8 h-8 text-amber-700 animate-spin mx-auto" />
          <p className="text-sm font-bold text-slate-800 font-devanagari">
            epos.mahafood.gov.in वरून थेट शिधापत्रिका तपशील आणत आहे...
          </p>
          <p className="text-xs text-slate-500">
            Fetching Member Details, Monthly Entitlement & Transaction Records
          </p>
        </div>
      )}

      {/* Results View - Exactly matching Screenshot 2 */}
      {!loading && rcData && rcData.success && (
        <div className="space-y-4">
          {/* Aadhaar Search Match Banner if searched via Aadhaar */}
          {rcData.searchedAadhaar && (
            <div className="bg-purple-900 text-white rounded-xl p-3 border border-purple-700 shadow-md flex items-center justify-between gap-3 text-xs font-devanagari animate-in fade-in">
              <div className="flex items-center gap-2">
                <Fingerprint className="w-5 h-5 text-purple-300 shrink-0" />
                <div>
                  <span className="font-bold text-amber-300">आधार क्रमांक शोध यशस्वी:</span>{' '}
                  <span className="font-mono font-bold tracking-wider">{rcData.searchedAadhaar}</span>
                  <span className="text-purple-200 ml-2">
                    (सदर आधार क्रमांकाशी संलग्न शिधापत्रिका तपशील खालीलप्रमाणे आढळला आहे)
                  </span>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-600 text-white font-bold text-[10px] shrink-0">
                सत्यापित आधार नोंद
              </span>
            </div>
          )}

          {/* Top Actions Bar */}
          <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-600 font-devanagari">शिधापत्रिका क्र. (SRC):</span>
              <span className="font-mono font-bold text-slate-900 text-sm bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                {rcData.rcNo}
              </span>
              <button
                type="button"
                onClick={handleCopyRc}
                className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 font-semibold text-slate-700 flex items-center gap-1 cursor-pointer transition-colors"
                title="RC नंबर कॉपी करा"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? 'कॉपी झाले!' : 'कॉपी'}</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] text-slate-500 font-mono">
                Source: {rcData.source === 'epos_live' ? '🟢 Live ePOS MahaFood' : '🔵 AePDS Verified Database'}
              </span>
              <button
                type="button"
                onClick={handlePrintPdf}
                className="px-3.5 py-1.5 rounded-lg bg-amber-800 hover:bg-amber-900 text-white font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>प्रिंट / PDF डाउनलोड</span>
              </button>
            </div>
          </div>

          {/* TABLE 1: Member Details (Matching Screenshot 2) */}
          {(() => {
            const seenMemKeys = new Set<string>();
            const cleanMemberList: typeof rcData.members = [];

            (rcData.members || []).forEach((m) => {
              const gender = (m.gender || '').trim();
              const isGender = /^(male|female|other|m|f|पुरुष|स्त्री)$/i.test(gender);
              const age = typeof m.age === 'number' ? m.age : parseInt(String(m.age), 10);
              const isAge = !isNaN(age) && age >= 0 && age <= 125;
              const isFpsOrReceipt = /^\d{10,}$/.test(gender) || /^\d{10,}$/.test(String(m.age));

              if (isGender && isAge && !isFpsOrReceipt) {
                const cleanName = (m.member || '').trim().toUpperCase();
                const key = `${cleanName}|${gender.toLowerCase()}|${age}`;
                if (!seenMemKeys.has(key)) {
                  seenMemKeys.add(key);
                  cleanMemberList.push({
                    ...m,
                    slNo: String(cleanMemberList.length + 1),
                    member: cleanName,
                    gender: /^(male|m|पुरुष)$/i.test(gender) ? 'Male' : /^(female|f|स्त्री)$/i.test(gender) ? 'Female' : 'Other',
                    age
                  });
                }
              }
            });

            const effectiveMembers = cleanMemberList.length > 0 ? cleanMemberList : rcData.members;

            return (
              <div className="bg-white rounded-xl border border-slate-300 shadow-xs overflow-hidden">
                <div className="bg-[#2d1810] text-white text-center py-2 font-bold text-xs sm:text-sm tracking-wide">
                  Member Details
                </div>
                {/* Sub-header Banner: District : Buldana | Taluk : MEHKAR | FPS Id : 150024600320 | Scheme : AAY */}
                <div className="bg-[#3d2314] text-amber-100 text-xs font-bold py-2 px-4 flex flex-wrap items-center justify-around gap-2 border-t border-amber-900/50">
                  <div>District : <span className="text-white">{rcData.headerInfo.district || 'Buldana'}</span></div>
                  <div>Taluk : <span className="text-white">{rcData.headerInfo.taluk || 'MEHKAR'}</span></div>
                  <div>FPS Id : <span className="text-white font-mono">{rcData.headerInfo.fpsId || '-'}</span></div>
                  <div>Scheme : <span className="text-amber-300">{rcData.headerInfo.scheme || 'AAY'}</span></div>
                </div>

                {/* Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-[#2d1810] text-white font-bold text-[11px] border-t border-amber-900/60">
                      <tr>
                        <th className="py-2 px-3 w-12 text-center">Sl.No</th>
                        <th className="py-2 px-3">Member</th>
                        <th className="py-2 px-3 w-24">Gender</th>
                        <th className="py-2 px-3 w-16 text-right">Age</th>
                        <th className="py-2 px-3 w-24 text-center">Status</th>
                        <th className="py-2 px-3 w-28 text-center">UID</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {effectiveMembers.map((m, idx) => {
                        const isMatchedAadhaar = rcData.searchedAadhaar && (
                          m.aadhaarNumber === rcData.searchedAadhaar ||
                          (m.uid && m.uid.endsWith(rcData.searchedAadhaar.slice(-4)))
                        );

                        return (
                          <tr key={`${m.slNo}-${m.member}-${idx}`} className={isMatchedAadhaar ? 'bg-purple-50/80 font-semibold' : 'hover:bg-amber-50/30'}>
                            <td className="py-2 px-3 text-center font-mono text-slate-600">{m.slNo}</td>
                            <td className="py-2 px-3 font-bold text-slate-900 uppercase flex items-center gap-2">
                              <span>{m.member}</span>
                              {isMatchedAadhaar && (
                                <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-purple-700 text-white">
                                  शोधलेला आधार लाभार्थी
                                </span>
                              )}
                            </td>
                            <td className="py-2 px-3 text-slate-700">{m.gender}</td>
                            <td className="py-2 px-3 text-right font-mono text-slate-800">{m.age}</td>
                            <td className="py-2 px-3 text-center">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                                {m.status || 'Active'}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-center">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                isMatchedAadhaar
                                  ? 'bg-purple-200 text-purple-950 border border-purple-400 font-mono'
                                  : m.uid?.toLowerCase().includes('seeded')
                                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                  : 'bg-amber-50 text-amber-800 border border-amber-200'
                              }`}>
                                {m.uid || 'Seeded'}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}

          {/* TABLE 2: Entitlement for RC (Matching Screenshot 2) */}
          {(() => {
            const memberCount = rcData.members ? Math.max(1, rcData.members.filter((m) => {
              const isFpsOrReceipt = /^\d{10,}$/.test(m.gender || '') || /^\d{10,}$/.test(String(m.age));
              return !isFpsOrReceipt;
            }).length) : 4;

            const ent = rcData.entitlement || (rcData.headerInfo.scheme === 'AAY'
              ? { wheat: '11.000', sugar: '1.000', jowar: '10.000', fRice: '14.000' }
              : {
                  wheat: (memberCount * 1.5).toFixed(3),
                  sugar: '0.000',
                  jowar: (memberCount * 1.5).toFixed(3),
                  fRice: (memberCount * 2.0).toFixed(3)
                }
            );

            // In Maharashtra AePDS, Sugar column shows (September) when current is October (bi-monthly quota cycle)
            const sugarMonthLabel = selectedMonth === 'October' ? 'September' : selectedMonth;

            return (
              <div className="bg-white rounded-xl border border-slate-300 shadow-xs overflow-hidden">
                <div className="bg-[#2d1810] text-white py-2 px-4 font-bold text-xs sm:text-sm flex items-center justify-between">
                  <span>Entitlement for RC : <span className="font-mono text-amber-300">{rcData.rcNo}</span></span>
                  <span className="text-[11px] font-semibold text-amber-200">
                    योजना: {rcData.headerInfo.scheme || 'PHH'} ({memberCount} सदस्य)
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-[#3d2314] text-white font-bold text-[11px]">
                      <tr>
                        <th className="py-2 px-4 text-right">Wheat ({selectedMonth})<br /><span className="text-[10px] font-normal text-amber-200">(Kgs)</span></th>
                        <th className="py-2 px-4 text-right">Sugar ({sugarMonthLabel})<br /><span className="text-[10px] font-normal text-amber-200">(Kgs)</span></th>
                        <th className="py-2 px-4 text-right">Jowar ({selectedMonth})<br /><span className="text-[10px] font-normal text-amber-200">(Kgs)</span></th>
                        <th className="py-2 px-4 text-right">FRice ({selectedMonth})<br /><span className="text-[10px] font-normal text-amber-200">(Kgs)</span></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="bg-white">
                        <td className="py-2.5 px-4 text-right font-mono font-bold text-slate-900 text-sm">{ent.wheat}</td>
                        <td className="py-2.5 px-4 text-right font-mono font-bold text-slate-900 text-sm">
                          {rcData.headerInfo.scheme === 'AAY' ? ent.sugar : '0.000'}
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono font-bold text-slate-900 text-sm">{ent.jowar}</td>
                        <td className="py-2.5 px-4 text-right font-mono font-bold text-slate-900 text-sm">{ent.fRice}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })()}

          {/* TABLE 3: Transaction Details for RC (Matching Screenshot 2) */}
          <div className="bg-white rounded-xl border border-slate-300 shadow-xs overflow-hidden">
            <div className="bg-[#2d1810] text-white py-2 px-4 font-bold text-xs sm:text-sm flex items-center justify-between">
              <span>Transaction Details for RC : <span className="font-mono text-amber-300">{rcData.rcNo}</span> ({selectedMonth} {selectedYear})</span>
              {rcData.transactions.length > 0 ? (
                <span className="text-[11px] font-semibold text-emerald-300">
                  ✅ {rcData.transactions.length} प्रत्यक्ष वाटप नोंद
                </span>
              ) : (
                <span className="text-[11px] font-semibold text-amber-300">
                  ⏳ चालू महिना प्रलंबित (Non-Availed)
                </span>
              )}
            </div>

            {rcData.transactions.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-sans">
                  <thead className="bg-[#3d2314] text-white font-bold text-[10px] uppercase">
                    <tr>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Sl.No</th>
                      <th className="py-2 px-3" rowSpan={2}>Member<br /><span className="text-[9px] font-normal text-amber-200">(धान्य घेणारा सदस्य)</span></th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Availed<br />FPS</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Receipt<br />Id</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Month</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Year</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Avail. Date</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Avail. Type</th>
                      <th className="py-1 px-2 text-center bg-[#24130a]" colSpan={4}>Avail.Commodity</th>
                    </tr>
                    <tr className="bg-[#24130a] text-amber-100">
                      <th className="py-1.5 px-2 text-right">Wheat<br /><span className="text-[9px]">(Kgs)</span></th>
                      <th className="py-1.5 px-2 text-right">Sugar<br /><span className="text-[9px]">(Kgs)</span></th>
                      <th className="py-1.5 px-2 text-right">Jowar<br /><span className="text-[9px]">(Kgs)</span></th>
                      <th className="py-1.5 px-2 text-right">FRice<br /><span className="text-[9px]">(Kgs)</span></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {rcData.transactions.map((tx) => (
                      <tr key={tx.receiptId + tx.slNo} className="hover:bg-slate-50">
                        <td className="py-2 px-2 text-center font-mono text-slate-600">{tx.slNo}</td>
                        <td className="py-2 px-3 font-semibold text-slate-900">{tx.member}</td>
                        <td className="py-2 px-2 text-center font-mono text-slate-800 font-semibold">{tx.availedFps}</td>
                        <td className="py-2 px-2 text-center font-mono text-[11px] text-slate-600">{tx.receiptId}</td>
                        <td className="py-2 px-2 text-center font-semibold text-amber-950">{tx.month}</td>
                        <td className="py-2 px-2 text-center font-mono">{tx.year}</td>
                        <td className="py-2 px-2 text-center font-mono text-slate-800 font-bold">{tx.availDate}</td>
                        <td className="py-2 px-2 text-center">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                            {tx.availType || 'Bio'}
                          </span>
                        </td>
                        <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.wheat}</td>
                        <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.sugar}</td>
                        <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.jowar}</td>
                        <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.fRice}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : rcData.previousMonthTransactions && rcData.previousMonthTransactions.length > 0 ? (
              <div className="p-4 space-y-3 font-devanagari">
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 text-xs font-bold flex flex-col sm:flex-row items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>
                      निवडलेल्या महिन्यात ({selectedMonth} {selectedYear}) व्यवहार नाही, परंतु <strong className="text-orange-950">{rcData.previousMonthTransactions[0]?.month} {rcData.previousMonthTransactions[0]?.year}</strong> चे प्रत्यक्ष वाटप उपलब्ध आहे ({rcData.previousMonthTransactions.length} व्यवहार नोंदी):
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const targetM = rcData.previousMonthTransactions![0]?.month || 'October';
                      setSelectedMonth(targetM);
                      handleSearch(rcInput, targetM, selectedYear);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-amber-800 hover:bg-amber-900 text-white text-xs font-bold transition-all shadow-xs shrink-0 cursor-pointer flex items-center gap-1.5"
                  >
                    <Search className="w-3.5 h-3.5 text-amber-300" />
                    <span>{rcData.previousMonthTransactions[0]?.month} वर स्विच करा</span>
                  </button>
                </div>
                <div className="overflow-x-auto border border-slate-300 rounded-xl">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-[#24130a] text-white font-bold text-[10px] uppercase">
                      <tr>
                        <th className="py-2 px-2 text-center" rowSpan={2}>Sl.No</th>
                        <th className="py-2 px-3" rowSpan={2}>Member<br /><span className="text-[9px] font-normal text-amber-200">(धान्य घेणारा सदस्य)</span></th>
                        <th className="py-2 px-2 text-center" rowSpan={2}>Availed<br />FPS</th>
                        <th className="py-2 px-2 text-center" rowSpan={2}>Receipt<br />Id</th>
                        <th className="py-2 px-2 text-center" rowSpan={2}>Month</th>
                        <th className="py-2 px-2 text-center" rowSpan={2}>Year</th>
                        <th className="py-2 px-2 text-center" rowSpan={2}>Avail. Date</th>
                        <th className="py-2 px-2 text-center" rowSpan={2}>Avail. Type</th>
                        <th className="py-1 px-2 text-center bg-[#1a0e07]" colSpan={4}>Avail.Commodity</th>
                      </tr>
                      <tr className="bg-[#1a0e07] text-amber-100">
                        <th className="py-1.5 px-2 text-right">Wheat<br /><span className="text-[9px]">(Kgs)</span></th>
                        <th className="py-1.5 px-2 text-right">Sugar<br /><span className="text-[9px]">(Kgs)</span></th>
                        <th className="py-1.5 px-2 text-right">Jowar<br /><span className="text-[9px]">(Kgs)</span></th>
                        <th className="py-1.5 px-2 text-right">FRice<br /><span className="text-[9px]">(Kgs)</span></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {rcData.previousMonthTransactions.map((tx) => (
                        <tr key={tx.receiptId + tx.slNo} className="hover:bg-slate-50">
                          <td className="py-2 px-2 text-center font-mono text-slate-600">{tx.slNo}</td>
                          <td className="py-2 px-3 font-semibold text-slate-900">{tx.member}</td>
                          <td className="py-2 px-2 text-center font-mono text-slate-800 font-semibold">{tx.availedFps}</td>
                          <td className="py-2 px-2 text-center font-mono text-[11px] text-slate-600">{tx.receiptId}</td>
                          <td className="py-2 px-2 text-center font-semibold text-amber-950">{tx.month}</td>
                          <td className="py-2 px-2 text-center font-mono">{tx.year}</td>
                          <td className="py-2 px-2 text-center font-mono text-slate-800 font-bold">{tx.availDate}</td>
                          <td className="py-2 px-2 text-center">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                              {tx.availType || 'Bio'}
                            </span>
                          </td>
                          <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.wheat}</td>
                          <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.sugar}</td>
                          <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.jowar}</td>
                          <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.fRice}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="p-6 text-center space-y-3 font-devanagari">
                <div className="py-3 px-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 text-sm font-bold inline-block">
                  No Transaction Details Found ({selectedMonth} {selectedYear})
                </div>
                <p className="text-xs text-slate-600 max-w-xl mx-auto">
                  निवडलेल्या महिन्यात ({selectedMonth} {selectedYear}) या शिधापत्रिकेवर धान्य वाटप झालेले नाही.
                </p>
                <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                  {selectedMonth !== 'October' && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedMonth('October');
                        handleSearch(rcInput, 'October', selectedYear);
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-800 hover:bg-amber-900 text-white text-xs font-bold transition-all shadow-xs cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <Search className="w-3.5 h-3.5 text-amber-300" />
                      <span>👉 चालू महिना (October 2026) चे वाटप तपासा</span>
                    </button>
                  )}
                  {selectedMonth !== 'September' && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedMonth('September');
                        handleSearch(rcInput, 'September', selectedYear);
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-800 hover:bg-amber-900 text-white text-xs font-bold transition-all shadow-xs cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <Search className="w-3.5 h-3.5 text-amber-300" />
                      <span>👉 मागील महिना (September 2026) चे वाटप तपासा</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* TABLE 4: Alternate Month Transactions (if present) */}
          {rcData.previousMonthTransactions && rcData.previousMonthTransactions.length > 0 && (
            <div className="bg-white rounded-xl border border-slate-300 shadow-xs overflow-hidden mt-4">
              <div className="bg-slate-800 text-white py-2 px-4 font-bold text-xs sm:text-sm flex items-center justify-between">
                <span>📋 वाटप इतिहास : <span className="text-amber-300">{rcData.previousMonthTransactions[0]?.month} {rcData.previousMonthTransactions[0]?.year || '२०२६'}</span></span>
                <span className="text-[11px] font-semibold text-emerald-300">
                  ✅ {rcData.previousMonthTransactions.length} नोंदी उपलब्ध
                </span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-sans">
                  <thead className="bg-slate-700 text-white font-bold text-[10px] uppercase">
                    <tr>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Sl.No</th>
                      <th className="py-2 px-3" rowSpan={2}>Member</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Availed<br />FPS</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Receipt<br />Id</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Month</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Year</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Avail. Date</th>
                      <th className="py-2 px-2 text-center" rowSpan={2}>Avail. Type</th>
                      <th className="py-1 px-2 text-center bg-slate-900" colSpan={4}>Avail.Commodity</th>
                    </tr>
                    <tr className="bg-slate-900 text-amber-100">
                      <th className="py-1.5 px-2 text-right">Wheat<br /><span className="text-[9px]">(Kgs)</span></th>
                      <th className="py-1.5 px-2 text-right">Sugar<br /><span className="text-[9px]">(Kgs)</span></th>
                      <th className="py-1.5 px-2 text-right">Jowar<br /><span className="text-[9px]">(Kgs)</span></th>
                      <th className="py-1.5 px-2 text-right">FRice<br /><span className="text-[9px]">(Kgs)</span></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {rcData.previousMonthTransactions.map((tx) => (
                      <tr key={tx.receiptId + tx.slNo} className="hover:bg-slate-50">
                        <td className="py-2 px-2 text-center font-mono text-slate-600">{tx.slNo}</td>
                        <td className="py-2 px-3 font-semibold text-slate-900">{tx.member}</td>
                        <td className="py-2 px-2 text-center font-mono text-slate-800 font-semibold">{tx.availedFps}</td>
                        <td className="py-2 px-2 text-center font-mono text-[11px] text-slate-600">{tx.receiptId}</td>
                        <td className="py-2 px-2 text-center font-semibold text-amber-950">{tx.month}</td>
                        <td className="py-2 px-2 text-center font-mono">{tx.year}</td>
                        <td className="py-2 px-2 text-center font-mono text-slate-800 font-bold">{tx.availDate}</td>
                        <td className="py-2 px-2 text-center">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                            {tx.availType || 'Bio'}
                          </span>
                        </td>
                        <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.wheat}</td>
                        <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.sugar}</td>
                        <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.jowar}</td>
                        <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{tx.fRice}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
