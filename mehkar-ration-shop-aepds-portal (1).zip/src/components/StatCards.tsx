import React from 'react';
import { Store, CheckCircle, ArrowLeftRight, MapPin } from 'lucide-react';
import { EposStats } from '../types/epos.js';

interface StatCardsProps {
  stats: EposStats | null;
  lang: 'mr' | 'hi' | 'en';
}

export const StatCards: React.FC<StatCardsProps> = ({ stats, lang }) => {
  const labels = {
    mr: {
      totalShops: 'एकूण रास्त भाव दुकाने (मेहकर)',
      activeShops: 'आज सक्रिय दुकाने',
      todayTrans: 'आज झालेले व्यवहार',
      locationTitle: 'मेहकर',
      locationSub: 'मेहकर तालुका (बुलढाणा)',
      activeRatio: 'दुकाने चालू'
    },
    hi: {
      totalShops: 'कुल उचित मूल्य दुकानें (मेहकर)',
      activeShops: 'आज सक्रिय दुकानें',
      todayTrans: 'आज के कुल लेन-देन',
      locationTitle: 'मेहकर',
      locationSub: 'मेहकर तालुका (बुलढाणा)',
      activeRatio: 'दुकानें खुली'
    },
    en: {
      totalShops: 'Total Fair Price Shops (Mehkar)',
      activeShops: 'Active Shops Today',
      todayTrans: 'Transactions Today',
      locationTitle: 'Mehkar',
      locationSub: 'Mehkar Taluka (Buldhana)',
      activeRatio: 'Shops Online'
    }
  };

  const t = labels[lang];
  const total = stats?.totalShops ?? 185;
  const active = stats?.activeShops ?? 86;
  const trans = stats?.todayTransactions ? stats.todayTransactions.toLocaleString('en-IN') : '2,767';

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Card 1: Total Shops */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs hover:shadow-sm transition-all duration-200 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-amber-50 border border-amber-200/70 flex items-center justify-center shrink-0 text-amber-700">
          <Store className="w-7 h-7" />
        </div>
        <div className="min-w-0">
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight tabular-nums">
            {total}
          </div>
          <div className="text-xs sm:text-sm font-medium text-slate-600 font-devanagari mt-0.5 truncate">
            {t.totalShops}
          </div>
        </div>
      </div>

      {/* Card 2: Active Shops Today */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs hover:shadow-sm transition-all duration-200 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200/70 flex items-center justify-center shrink-0 text-emerald-600">
          <CheckCircle className="w-7 h-7" />
        </div>
        <div className="min-w-0">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight tabular-nums">
              {active}
            </span>
            <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200/50">
              {Math.round((active / total) * 100)}%
            </span>
          </div>
          <div className="text-xs sm:text-sm font-medium text-slate-600 font-devanagari mt-0.5 truncate">
            {t.activeShops}
          </div>
        </div>
      </div>

      {/* Card 3: Today's Transactions */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs hover:shadow-sm transition-all duration-200 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-blue-200/70 flex items-center justify-center shrink-0 text-blue-600">
          <ArrowLeftRight className="w-7 h-7" />
        </div>
        <div className="min-w-0">
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight tabular-nums">
            {trans}
          </div>
          <div className="text-xs sm:text-sm font-medium text-slate-600 font-devanagari mt-0.5 truncate">
            {t.todayTrans}
          </div>
        </div>
      </div>

      {/* Card 4: Location Mehkar */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs hover:shadow-sm transition-all duration-200 flex items-center gap-4">
        <div className="w-14 h-14 rounded-2xl bg-amber-50/80 border border-amber-200/70 flex items-center justify-center shrink-0 text-amber-800">
          <MapPin className="w-7 h-7" />
        </div>
        <div className="min-w-0">
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-devanagari">
            {t.locationTitle}
          </div>
          <div className="text-xs sm:text-sm font-medium text-slate-600 font-devanagari mt-0.5 truncate">
            {t.locationSub}
          </div>
        </div>
      </div>
    </div>
  );
};
