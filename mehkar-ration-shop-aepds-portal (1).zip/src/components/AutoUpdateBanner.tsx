import React, { useEffect, useState, useRef } from 'react';
import { RefreshCw, Sparkles, CheckCircle2 } from 'lucide-react';

interface AutoUpdateBannerProps {
  compact?: boolean;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export const AutoUpdateBanner: React.FC<AutoUpdateBannerProps> = ({
  compact = false,
  onRefresh,
  isRefreshing = false
}) => {
  const [currentVersion, setCurrentVersion] = useState<string | null>(null);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [isChecking, setIsChecking] = useState<boolean>(false);
  const [updateDetected, setUpdateDetected] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const initialVersionRef = useRef<string | null>(null);

  // Function to perform version check and complete app data refresh
  const checkVersionAndRefresh = async (showManualFeedback: boolean = false) => {
    if (isUpdating) return;
    if (showManualFeedback) setIsChecking(true);

    try {
      // Trigger parent app data refresh if supplied
      if (showManualFeedback && onRefresh) {
        onRefresh();
      }

      // Add cache-busting timestamp to prevent intermediate proxy caching
      const res = await fetch(`/api/app-version?_t=${Date.now()}`, {
        headers: { 'Cache-Control': 'no-cache', Pragma: 'no-cache' }
      });
      if (res.ok) {
        const data = await res.json();
        const serverVer = data.version;

        if (!initialVersionRef.current) {
          initialVersionRef.current = serverVer;
          setCurrentVersion(serverVer);
        } else if (serverVer && serverVer !== initialVersionRef.current) {
          // New version detected from Google AI Studio!
          console.log('[AutoUpdate] New version detected:', serverVer, 'previous:', initialVersionRef.current);
          setUpdateDetected(true);
          setIsUpdating(true);
          setStatusMessage('Google AI Studio मधील नवीन बदल आढळले आहेत. मोबाईल ॲप स्वयंचलित अपडेट होत आहे...');

          // Clear Service Worker caches
          if ('caches' in window) {
            try {
              const keys = await caches.keys();
              await Promise.all(keys.map((k) => caches.delete(k)));
            } catch (_cErr) {}
          }

          // Unregister old service workers if needed
          if ('serviceWorker' in navigator) {
            try {
              const registrations = await navigator.serviceWorker.getRegistrations();
              for (const r of registrations) {
                await r.update();
              }
            } catch (_swErr) {}
          }

          // Reload page to apply changes seamlessly without uninstalling
          setTimeout(() => {
            window.location.reload();
          }, 1200);
          return;
        }

        if (showManualFeedback) {
          setStatusMessage('✅ ॲप व सर्व १४ दुकानांचा ePOS डेटा अद्ययावत केला!');
          setTimeout(() => setStatusMessage(null), 3500);
        }
      }
    } catch (_e) {
      if (showManualFeedback) {
        setStatusMessage('✅ थेट ePOS डेटा रीफ्रेश झाला!');
        setTimeout(() => setStatusMessage(null), 3000);
      }
    } finally {
      if (showManualFeedback) {
        setTimeout(() => setIsChecking(false), 800);
      }
    }
  };

  useEffect(() => {
    // Initial check
    checkVersionAndRefresh(false);

    // Periodic check every 5 seconds in background for instant updates from Google AI Studio
    const interval = setInterval(() => {
      checkVersionAndRefresh(false);
    }, 5000);

    // Check immediately when user switches back to the app on mobile or reconnects
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        checkVersionAndRefresh(false);
      }
    };
    const handleFocus = () => {
      checkVersionAndRefresh(false);
    };
    const handleOnline = () => {
      checkVersionAndRefresh(false);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocus);
    window.addEventListener('online', handleOnline);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('online', handleOnline);
    };
  }, []);

  return (
    <>
      {/* Top Banner when an update from Google AI Studio is applying */}
      {updateDetected && (
        <aside
          aria-label="ऑटो-अपडेट सूचना"
          className="fixed top-3 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-3 animate-in slide-in-from-top-4 duration-300"
        >
          <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white p-3.5 rounded-2xl shadow-2xl border-2 border-emerald-400/80 flex items-center gap-3">
            <RefreshCw className="w-5 h-5 text-emerald-300 animate-spin shrink-0" />
            <div className="text-xs">
              <span className="font-bold block text-emerald-200">
                🚀 Google AI Studio अपडेट सापडले!
              </span>
              <span className="text-[11px] text-slate-200 block mt-0.5">
                नवीन बदल आपोआप लोड होत आहेत (Install/Uninstall ची गरज नाही)...
              </span>
            </div>
          </div>
        </aside>
      )}

      {/* Manual Check Status Toast */}
      {statusMessage && !updateDetected && (
        <aside
          aria-label="अपडेट स्थिती"
          className="fixed bottom-16 sm:bottom-6 right-4 z-40 animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          <div className="bg-slate-900 text-white px-3.5 py-2 rounded-xl shadow-lg border border-slate-700 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{statusMessage}</span>
          </div>
        </aside>
      )}

      {/* Compact Quick Update Button for Navbar or Footer */}
      {!compact && (
        <button
          type="button"
          onClick={() => checkVersionAndRefresh(true)}
          disabled={isChecking || isUpdating || isRefreshing}
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-900 text-[11px] font-bold transition-all cursor-pointer shadow-2xs active:scale-97 disabled:opacity-70"
          title="Google AI Studio मधील नवीन बदल व ePOS डेटा त्वरित अपडेट करा"
        >
          {isChecking || isRefreshing ? (
            <RefreshCw className="w-3 h-3 text-emerald-700 animate-spin" />
          ) : (
            <Sparkles className="w-3 h-3 text-emerald-700" />
          )}
          <span>{isChecking || isRefreshing ? 'अद्ययावत होत आहे...' : '🟢 ऑटो-अपडेट सक्रिय'}</span>
        </button>
      )}
    </>
  );
};
