import React from 'react';
import { RefreshCw, ShieldCheck, Building2, Store, LogOut, User, CreditCard, MessageCircle } from 'lucide-react';
import { EposStats } from '../types/epos.js';
import { UserSession } from '../types/auth.js';
import { getSubscriptionStatus, SUPPORT_CONTACT } from '../services/authService.js';
import { MonthYearPicker } from './MonthYearPicker.js';
import { AutoUpdateBanner } from './AutoUpdateBanner.js';

interface NavbarProps {
  stats: EposStats | null;
  isRefreshing: boolean;
  onRefresh: () => void;
  lang: 'mr' | 'hi' | 'en';
  setLang: (lang: 'mr' | 'hi' | 'en') => void;
  currentMonth: string;
  onMonthChange: (month: string) => void;
  userSession?: UserSession | null;
  onLogout?: () => void;
  onOpenLogin?: () => void;
  onOpenPayment?: () => void;
  onToggleOwnerDashboard?: () => void;
  isOwnerDashboardOpen?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  stats,
  isRefreshing,
  onRefresh,
  lang,
  setLang,
  currentMonth,
  onMonthChange,
  userSession,
  onLogout,
  onOpenLogin,
  onOpenPayment,
  onToggleOwnerDashboard,
  isOwnerDashboardOpen
}) => {

  const titles = {
    mr: {
      title: 'सार्वजनिक वितरण प्रणाली (AePDS)',
      subtitle: 'अन्न, नागरी पुरवठा व ग्राहक संरक्षण विभाग · महाराष्ट्र शासन',
      refresh: 'थेट डेटा रीफ्रेश करा',
      refreshing: 'डेटा आणत आहे...',
      syncStatus: 'थेट ePOS सर्व्हरशी जोडलेले'
    },
    hi: {
      title: 'सार्वजनिक वितरण प्रणाली (AePDS)',
      subtitle: 'खाद्य, नागरिक आपूर्ति एवं उपभोक्ता संरक्षण विभाग · महाराष्ट्र शासन',
      refresh: 'लाइव डेटा रिफ्रेश करें',
      refreshing: 'डेटा लोड हो रहा है...',
      syncStatus: 'लाइव ePOS सर्वर से जुड़ा'
    },
    en: {
      title: 'Public Distribution System (AePDS)',
      subtitle: 'Food, Civil Supplies and Consumer Protection Department · Govt of Maharashtra',
      refresh: 'Refresh Live Data',
      refreshing: 'Syncing with ePOS...',
      syncStatus: 'Connected to ePOS Gateway'
    }
  };

  const t = titles[lang];

  return (
    <header className="bg-gradient-to-r from-[#ba4305] via-[#cf4d07] to-[#993402] text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          {/* Left Brand Area */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center p-2 shadow-inner shrink-0">
              <Building2 className="w-full h-full text-amber-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight font-devanagari">
                  {t.title}
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-white/15 text-amber-100">
                  <ShieldCheck className="w-3 h-3 text-emerald-300" />
                  MahaFood Govt
                </span>
              </div>
              <p className="text-sm text-amber-100/90 font-medium font-devanagari">
                {t.subtitle}
              </p>
            </div>
          </div>

          {/* Right Action, Month, User Session & Language Area */}
          <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
            {/* Government-style Month & Year Picker */}
            <MonthYearPicker
              currentMonth={currentMonth}
              onMonthChange={onMonthChange}
            />

            {/* Language Selector */}
            <div className="bg-black/20 rounded-lg p-0.5 flex items-center border border-white/10 text-xs font-medium">
              <button
                type="button"
                onClick={() => setLang('mr')}
                className={`px-2 py-1 rounded transition-colors ${
                  lang === 'mr' ? 'bg-white text-orange-950 font-semibold shadow-xs' : 'text-amber-100 hover:text-white'
                }`}
              >
                मराठी
              </button>
              <button
                type="button"
                onClick={() => setLang('hi')}
                className={`px-2 py-1 rounded transition-colors ${
                  lang === 'hi' ? 'bg-white text-orange-950 font-semibold shadow-xs' : 'text-amber-100 hover:text-white'
                }`}
              >
                हिंदी
              </button>
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-2 py-1 rounded transition-colors ${
                  lang === 'en' ? 'bg-white text-orange-950 font-semibold shadow-xs' : 'text-amber-100 hover:text-white'
                }`}
              >
                Eng
              </button>
            </div>

            {/* Auto-Update Badge & Live Status */}
            <AutoUpdateBanner onRefresh={onRefresh} isRefreshing={isRefreshing} />

            {/* Live Refresh Button */}
            <button
              type="button"
              onClick={onRefresh}
              disabled={isRefreshing}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all shadow-xs cursor-pointer whitespace-nowrap ${
                isRefreshing
                  ? 'bg-amber-900/60 text-amber-200 cursor-not-allowed'
                  : 'bg-black/25 hover:bg-black/35 text-white active:scale-97 border border-white/25 hover:border-white/40'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-300' : 'text-white'}`} />
              <span className="font-devanagari hidden sm:inline">
                {isRefreshing ? t.refreshing : t.refresh}
              </span>
            </button>

            {/* WhatsApp Help & Support Button */}
            <a
              href={SUPPORT_CONTACT.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black shadow-xs cursor-pointer active:scale-95 transition-all border border-emerald-400"
              title={`WhatsApp वर थेट संपर्क करा (${SUPPORT_CONTACT.phone})`}
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span className="font-devanagari hidden lg:inline">मदत: {SUPPORT_CONTACT.phone}</span>
              <span className="font-devanagari lg:hidden">मदत</span>
            </a>

            {/* USER SESSION / LOGOUT BADGE */}
            {userSession ? (
              <div className="flex items-center gap-2">
                {/* If Owner: Show Owner Control Panel Button */}
                {userSession.role === 'owner' ? (
                  <button
                    type="button"
                    onClick={onToggleOwnerDashboard}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow-md cursor-pointer transition-all active:scale-95"
                    title="मालक नियंत्रण पॅनेल उघडा / बंद करा"
                  >
                    <span>👑</span>
                    <span className="font-devanagari">
                      {isOwnerDashboardOpen ? 'दुकानदार ॲप' : 'मालक पॅनेल'}
                    </span>
                  </button>
                ) : (
                  /* If Dealer: 3-Day Free Trial / ₹100 Monthly Subscription Status Button */
                  (() => {
                    const subStatus = getSubscriptionStatus(userSession);
                    return (
                      <button
                        type="button"
                        onClick={onOpenPayment}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-black shadow-xs cursor-pointer transition-all active:scale-95 ${
                          subStatus.isPaidSubscribed
                            ? 'bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-400'
                            : subStatus.isFreeTrial
                            ? 'bg-amber-400 hover:bg-amber-300 text-orange-950 border border-amber-300'
                            : 'bg-rose-600 hover:bg-rose-500 text-white border border-rose-400 animate-pulse'
                        }`}
                        title="वर्गणी शुल्क माहिती व ऑनलाईन पेमेंट"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span className="font-devanagari">
                          {subStatus.isPaidSubscribed
                            ? `मासिक वर्गणी (${subStatus.paidDaysLeft}d)`
                            : subStatus.isFreeTrial
                            ? `३ दिवस मोफत (${subStatus.trialDaysLeft}d)`
                            : '₹१०० वर्गणी भरा'}
                        </span>
                      </button>
                    );
                  })()
                )}

                <div className="flex items-center gap-1.5 bg-black/30 border border-white/20 pl-2.5 pr-1.5 py-1 rounded-xl">
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className={`w-2 h-2 rounded-full ${userSession.role === 'owner' ? 'bg-amber-400' : 'bg-emerald-400'} animate-pulse`} />
                    {userSession.role === 'owner' ? (
                      <span className="text-sm">👑</span>
                    ) : (
                      <Store className="w-3.5 h-3.5 text-amber-300" />
                    )}
                    <div className="leading-tight text-left">
                      <span className="font-mono font-black text-amber-200 block text-[11px]">
                        {userSession.role === 'owner'
                          ? 'सुपर ॲडमिन'
                          : userSession.fpsId === 'ALL'
                          ? 'सर्व दुकाने'
                          : `दुकान: ${userSession.fpsId.slice(-4)}`}
                      </span>
                      <span className="text-[10px] text-white/90 truncate max-w-[110px] hidden sm:block">
                        {userSession.dealerName.split(' ')[0]}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={onLogout}
                    title="लॉगआउट करा / बाहेर पडा"
                    className="ml-1 p-1 rounded-lg bg-rose-700/80 hover:bg-rose-700 text-white text-[11px] font-bold cursor-pointer transition-colors flex items-center gap-1 shadow-xs"
                  >
                    <LogOut className="w-3 h-3" />
                    <span className="hidden sm:inline">बाहेर पडा</span>
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={onOpenLogin}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-orange-950 text-xs font-black transition-all shadow-xs cursor-pointer active:scale-97"
              >
                <User className="w-3.5 h-3.5" />
                <span>लॉगिन</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

