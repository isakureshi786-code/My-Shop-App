import React, { useState, useMemo, useEffect } from 'react';
import {
  Search,
  Printer,
  CheckCircle2,
  Clock,
  Truck,
  FileText,
  Building2,
  ArrowUpDown,
  Filter,
  Check,
  RotateCcw
} from 'lucide-react';
import { RoStatusEntry, getRoStatusEntries, updateRoEntryStatus } from '../data/roStatusData.js';
import { EposShop } from '../types/epos.js';
import { printFormattedReport } from '../utils/exportUtils.js';

interface RoStatusViewProps {
  currentShopId?: string;
  shops?: EposShop[];
  lang: 'mr' | 'hi' | 'en';
}

export const RoStatusView: React.FC<RoStatusViewProps> = ({
  currentShopId = '150024600320',
  shops = [],
  lang
}) => {
  const [entries, setEntries] = useState<RoStatusEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [perPage, setPerPage] = useState<number>(50);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [commodityFilter, setCommodityFilter] = useState<string>('ALL');
  const [schemeFilter, setSchemeFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // Load entries
  useEffect(() => {
    setEntries(getRoStatusEntries());
  }, []);

  // Format today's date matching screenshot: "09-10-2026"
  const formattedToday = useMemo(() => {
    const d = new Date();
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  }, []);

  // Filter entries strictly to the logged in dealer's shop:
  // "RO जो दुकान से लॉगिन करा उसका ही data दिख ना सब दुकान नहीं दिखना data गलत दिख रा डेमो नहीं दिखना"
  const filteredEntries = useMemo(() => {
    let list = entries;
    const shopToFilter = (currentShopId || '150024600320').trim();
    list = list.filter((e) => e.fpsId === shopToFilter);

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      list = list.filter(
        (e) =>
          e.commodity.toLowerCase().includes(q) ||
          e.scheme.toLowerCase().includes(q) ||
          e.status.toLowerCase().includes(q) ||
          e.truckChitNo.toLowerCase().includes(q) ||
          e.allocationOrderNo.toLowerCase().includes(q)
      );
    }
    if (commodityFilter !== 'ALL') {
      list = list.filter((e) => e.commodity === commodityFilter);
    }
    if (schemeFilter !== 'ALL') {
      list = list.filter((e) => e.scheme === schemeFilter);
    }
    if (statusFilter !== 'ALL') {
      list = list.filter((e) => e.status === statusFilter);
    }
    return list;
  }, [entries, currentShopId, searchTerm, commodityFilter, schemeFilter, statusFilter]);

  const totalFiltered = filteredEntries.length;
  const totalEntriesOverall = entries.length; // 112
  const totalPages = Math.max(1, Math.ceil(totalFiltered / perPage));
  const displayedEntries = filteredEntries.slice((currentPage - 1) * perPage, currentPage * perPage);

  // Toggle status between Pending & Received
  const handleToggleStatus = (entry: RoStatusEntry) => {
    const newStatus = entry.status === 'Pending' ? 'Received' : 'Pending';
    updateRoEntryStatus(entry.slNo, newStatus);
    setEntries(getRoStatusEntries());
    setActionMessage(`FPS ${entry.fpsId} - ${entry.commodity} (${entry.scheme}) स्थिती '${newStatus === 'Received' ? 'Received (पोहोचले)' : 'Pending (प्रलंबित)'}' म्हणून नोंदवली गेली.`);
    setTimeout(() => setActionMessage(null), 4000);
  };

  // Handle Print
  const handlePrint = () => {
    printFormattedReport({
      title: `Buldana / MEHKAR RO Status as on ${formattedToday}`,
      subtitle: `Food, Civil Supplies and Consumer Protection Department, Maharashtra (AePDS) · एकूण नोंदी: ${totalFiltered}`,
      sections: [
        {
          headers: [
            'Sl No',
            'FPS Id',
            'Commodity',
            'Scheme',
            'Dispatched Qty',
            'Status',
            'Truck Chit No',
            'Allocation Order No',
            'Dispatch Date'
          ],
          rows: filteredEntries.map((e) => [
            String(e.slNo),
            e.fpsId,
            e.commodity,
            e.scheme,
            e.dispatchedQty.toFixed(3),
            e.status,
            e.truckChitNo,
            e.allocationOrderNo,
            e.dispatchDate
          ])
        }
      ]
    });
  };

  return (
    <div className="space-y-4 font-sans animate-in fade-in pb-12">
      {/* Top Banner Toolbar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 font-devanagari">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#24130a] text-amber-300 flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
            🚚
          </div>
          <div>
            <h2 className="text-base font-black text-slate-900 tracking-tight font-sans">
              Buldana / MEHKAR RO Received Status
            </h2>
            <p className="text-xs text-slate-600 font-medium">
              गोदामातून दुकानात धान्य आवक (Release Order / Truck Chit) तपशील व पोहोच नोंद
            </p>
          </div>
        </div>

        {/* Quick Filter buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Active Shop Badge */}
          <div className="px-3 py-1.5 rounded-xl text-xs font-mono font-bold bg-amber-800 text-white shadow-2xs flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-amber-200" />
            <span>दुकान ID: {currentShopId}</span>
          </div>

          {/* Print Button */}
          <button
            type="button"
            onClick={handlePrint}
            className="px-3.5 py-1.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print (प्रिंट)</span>
          </button>
        </div>
      </div>

      {/* Action toast message */}
      {actionMessage && (
        <div className="bg-emerald-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-md flex items-center gap-2 animate-in fade-in font-devanagari">
          <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Main Government Table Container */}
      <div className="bg-white rounded-2xl border border-slate-300 shadow-sm overflow-hidden">
        {/* Top Controls: Per page and Search input matching Screenshot 2 */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-slate-700 font-medium">
            <span>Per page</span>
            <select
              value={perPage}
              onChange={(e) => {
                setPerPage(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="px-2 py-1 rounded-md border border-slate-300 bg-white font-mono font-bold text-slate-900 shadow-2xs cursor-pointer"
            >
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-slate-700 font-medium">Search</label>
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="150024600320 / Wheat / RO..."
                className="px-2.5 py-1 pr-7 rounded-md border border-slate-300 text-xs font-bold text-slate-900 bg-white focus:outline-hidden focus:ring-1 focus:ring-amber-500 w-48 sm:w-64 shadow-2xs font-mono"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Official Dark Header Title Matching Screenshot 2 */}
        <div className="bg-[#24130a] text-white text-center py-2.5 px-4 font-bold text-xs sm:text-sm tracking-wide font-sans">
          Buldana / MEHKAR RO Status as on {formattedToday}
        </div>

        {/* Table Viewport */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans border-collapse">
            <thead className="bg-[#24130a] text-white font-bold text-[11px] border-t border-amber-950">
              <tr>
                <th className="py-2.5 px-2.5 text-center border-r border-[#3d2314] w-12">
                  <div className="flex items-center justify-center gap-1">
                    <span>Sl No</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
                <th className="py-2.5 px-3 text-center border-r border-[#3d2314] min-w-[110px]">
                  <div className="flex items-center justify-center gap-1">
                    <span>FPS Id</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
                <th className="py-2.5 px-3 border-r border-[#3d2314] min-w-[95px]">
                  <div className="flex items-center justify-between gap-1">
                    <span>Commodity</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
                <th className="py-2.5 px-2.5 text-center border-r border-[#3d2314] w-16">
                  <div className="flex items-center justify-center gap-1">
                    <span>Scheme</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
                <th className="py-2.5 px-3 text-right border-r border-[#3d2314] min-w-[105px]">
                  <div className="flex items-center justify-end gap-1">
                    <span>Dispatched Qty</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
                <th className="py-2.5 px-3 text-center border-r border-[#3d2314] min-w-[95px]">
                  <div className="flex items-center justify-center gap-1">
                    <span>Status</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
                <th className="py-2.5 px-3 border-r border-[#3d2314] min-w-[210px]">
                  <div className="flex items-center justify-between gap-1">
                    <span>Truck Chit No</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
                <th className="py-2.5 px-3 border-r border-[#3d2314] min-w-[230px]">
                  <div className="flex items-center justify-between gap-1">
                    <span>Allocation Order No</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
                <th className="py-2.5 px-3 text-center min-w-[95px]">
                  <div className="flex items-center justify-center gap-1">
                    <span>Dispatch Date</span>
                    <ArrowUpDown className="w-2.5 h-2.5 opacity-60" />
                  </div>
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-200">
              {displayedEntries.map((e) => (
                <tr key={`${e.slNo}-${e.commodity}-${e.scheme}`} className="hover:bg-amber-50/40 text-slate-800">
                  <td className="py-2.5 px-2.5 text-center font-mono font-bold text-slate-900 border-r border-slate-200">
                    {e.slNo}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono font-bold text-slate-900 border-r border-slate-200">
                    {e.fpsId}
                  </td>
                  <td className="py-2.5 px-3 font-bold text-slate-900 border-r border-slate-200">
                    {e.commodity}
                  </td>
                  <td className="py-2.5 px-2.5 text-center font-bold border-r border-slate-200">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-black ${
                      e.scheme === 'AAY'
                        ? 'bg-amber-100 text-amber-900 border border-amber-300'
                        : 'bg-teal-100 text-teal-900 border border-teal-300'
                    }`}>
                      {e.scheme}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-black text-slate-900 text-[13px] border-r border-slate-200">
                    {e.dispatchedQty.toFixed(3)}
                  </td>
                  <td className="py-2.5 px-3 text-center border-r border-slate-200">
                    <button
                      type="button"
                      onClick={() => handleToggleStatus(e)}
                      title="स्थिती बदलण्यासाठी क्लिक करा (Click to toggle)"
                      className={`px-2.5 py-0.5 rounded text-[11px] font-bold cursor-pointer transition-all flex items-center justify-center gap-1 mx-auto ${
                        e.status === 'Received'
                          ? 'bg-emerald-100 text-emerald-900 border border-emerald-300 hover:bg-emerald-200'
                          : 'bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200'
                      }`}
                    >
                      {e.status === 'Received' ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-700" />
                          <span>Received</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-3 h-3 text-amber-700" />
                          <span>Pending</span>
                        </>
                      )}
                    </button>
                  </td>
                  <td className="py-2.5 px-3 font-mono text-[11px] font-bold text-slate-800 border-r border-slate-200 select-all">
                    {e.truckChitNo}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-[11px] font-bold text-slate-800 border-r border-slate-200 select-all">
                    {e.allocationOrderNo}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono font-bold text-slate-900 whitespace-nowrap">
                    {e.dispatchDate}
                  </td>
                </tr>
              ))}

              {displayedEntries.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500 font-devanagari">
                    शोधलेल्या निकषांनुसार कोणतीही RO आवक नोंद सापडली नाही.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Bottom Subtext & Pagination matching Screenshot 2 */}
        <div className="p-3 bg-white border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          {/* Subtext: "Showing 1 to 6 of 6 entries (filtered from 112 total entries)" */}
          <div className="text-rose-900 font-bold font-sans">
            Showing {totalFiltered > 0 ? (currentPage - 1) * perPage + 1 : 0} to{' '}
            {Math.min(currentPage * perPage, totalFiltered)} of {totalFiltered} entries{' '}
            {searchTerm && totalFiltered < totalEntriesOverall && (
              <span className="font-semibold text-slate-600">
                (filtered from {totalEntriesOverall} total entries)
              </span>
            )}
          </div>

          {/* Pagination Buttons */}
          <div className="flex items-center gap-1 font-bold">
            <button
              type="button"
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage(1)}
              className="px-2.5 py-1 rounded bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white cursor-pointer shadow-2xs font-sans"
            >
              First
            </button>
            <button
              type="button"
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="px-2.5 py-1 rounded bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white cursor-pointer shadow-2xs font-sans"
            >
              Previous
            </button>
            <span className="px-3 py-1 rounded bg-blue-900 text-white font-mono shadow-2xs">
              {currentPage}
            </span>
            <button
              type="button"
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              className="px-2.5 py-1 rounded bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white cursor-pointer shadow-2xs font-sans"
            >
              Next
            </button>
            <button
              type="button"
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage(totalPages)}
              className="px-2.5 py-1 rounded bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white cursor-pointer shadow-2xs font-sans"
            >
              Last
            </button>
          </div>
        </div>
      </div>

      {/* Official AePDS Disclaimer Footer Matching Screenshot 2 */}
      <footer className="bg-black text-amber-500 py-3 px-4 rounded-xl flex flex-wrap items-center justify-between gap-2 text-[11px] font-sans">
        <span className="font-semibold hover:underline cursor-pointer">Disclaimer</span>
        <span className="text-white font-medium text-center">
          Designed & Developed for <strong className="text-amber-400">Food, Civil Supplies and Consumer Protection Department</strong>, Maharashtra
        </span>
        <div className="flex items-center gap-2">
          <span>Copyright</span>
          <span className="px-2 py-0.5 rounded bg-blue-700 text-white font-bold font-mono text-[10px]">
            NIC
          </span>
        </div>
      </footer>
    </div>
  );
};
