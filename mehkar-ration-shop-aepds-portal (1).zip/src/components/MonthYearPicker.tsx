import React from 'react';
import { ChevronDown } from 'lucide-react';

interface MonthYearPickerProps {
  currentMonth: string; // e.g. '2026-09' or '2026-10'
  onMonthChange: (monthStr: string) => void;
  className?: string;
  variant?: 'navbar' | 'card';
}

const MONTHS = [
  { value: '01', labelEn: 'January', labelMr: 'जानेवारी' },
  { value: '02', labelEn: 'February', labelMr: 'फेब्रुवारी' },
  { value: '03', labelEn: 'March', labelMr: 'मार्च' },
  { value: '04', labelEn: 'April', labelMr: 'एप्रिल' },
  { value: '05', labelEn: 'May', labelMr: 'मे' },
  { value: '06', labelEn: 'June', labelMr: 'जून' },
  { value: '07', labelEn: 'July', labelMr: 'जुलै' },
  { value: '08', labelEn: 'August', labelMr: 'ऑगस्ट' },
  { value: '09', labelEn: 'September', labelMr: 'सप्टेंबर' },
  { value: '10', labelEn: 'October', labelMr: 'ऑक्टोबर' },
  { value: '11', labelEn: 'November', labelMr: 'नोव्हेंबर' },
  { value: '12', labelEn: 'December', labelMr: 'डिसेंबर' }
];

const YEARS = ['2026', '2025', '2024'];

export const MonthYearPicker: React.FC<MonthYearPickerProps> = ({
  currentMonth,
  onMonthChange,
  className = '',
  variant = 'card'
}) => {
  // Parse 'YYYY-MM'
  const parts = (currentMonth || '2026-10').split('-');
  const year = parts[0] || '2026';
  const month = parts[1] || '10';

  const handleMonthSelect = (newMonth: string) => {
    onMonthChange(`${year}-${newMonth}`);
  };

  const handleYearSelect = (newYear: string) => {
    onMonthChange(`${newYear}-${month}`);
  };

  // Styled exactly matching the user's uploaded screenshot:
  // "Month [ October v ]   Year [ 2026 v ]"
  return (
    <div
      className={`inline-flex items-center gap-2 sm:gap-3 bg-white px-3 py-1.5 rounded-lg border border-slate-300 shadow-sm text-slate-900 ${className}`}
    >
      {/* Month Selector */}
      <div className="flex items-center gap-1.5">
        <label className="text-xs sm:text-sm font-bold text-slate-900 select-none">महिना / Month</label>
        <div className="relative">
          <select
            value={month}
            onChange={(e) => handleMonthSelect(e.target.value)}
            className="appearance-none bg-slate-50 hover:bg-slate-100 border border-slate-300 text-slate-900 font-bold text-xs sm:text-sm rounded-md pl-2.5 pr-7 py-1 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer shadow-2xs transition-colors"
          >
            {MONTHS.map((m) => (
              <option key={m.value} value={m.value}>
                {m.labelEn} ({m.labelMr})
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      </div>

      {/* Year Selector */}
      <div className="flex items-center gap-1.5">
        <label className="text-xs sm:text-sm font-bold text-slate-900 select-none">वर्ष / Year</label>
        <div className="relative">
          <select
            value={year}
            onChange={(e) => handleYearSelect(e.target.value)}
            className="appearance-none bg-slate-50 hover:bg-slate-100 border border-slate-300 text-slate-900 font-bold text-xs sm:text-sm rounded-md pl-2.5 pr-7 py-1 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer shadow-2xs transition-colors"
          >
            {YEARS.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-1.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      </div>
    </div>
  );
};
