import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Building2,
  Lock,
  Store,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  RefreshCw,
  Eye,
  EyeOff,
  UserCheck,
  Mail,
  Crown,
  HelpCircle,
  X,
  MessageCircle,
  Phone
} from 'lucide-react';
import { UserSession } from '../types/auth.js';
import {
  loginDealer,
  loginOwner,
  registerDealerWithFpsAndGmail,
  sendPasswordResetOtp,
  verifyOtpAndResetPassword,
  lookupShopByFpsId,
  resetAllDealerAuthData,
  OWNER_CREDENTIALS,
  SUPPORT_CONTACT
} from '../services/authService.js';

interface LoginRegisterScreenProps {
  onLoginSuccess: (session: UserSession) => void;
  lang?: 'mr' | 'hi' | 'en';
}

export const LoginRegisterScreen: React.FC<LoginRegisterScreenProps> = ({
  onLoginSuccess,
  lang = 'mr'
}) => {
  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'owner'>('login');

  // Dealer Login Form State
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Password Reset with Gmail OTP View State
  const [isResetMode, setIsResetMode] = useState(false);
  const [resetStep, setResetStep] = useState<'request_otp' | 'verify_otp'>('request_otp');
  const [resetIdentifier, setResetIdentifier] = useState('');
  const [resetOtp, setResetOtp] = useState('');
  const [resetNewPassword, setResetNewPassword] = useState('');
  const [resetConfirmPassword, setResetConfirmPassword] = useState('');
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [otpSentToEmail, setOtpSentToEmail] = useState<string | null>(null);
  const [demoOtpPreview, setDemoOtpPreview] = useState<string | null>(null);
  const [otpResendSeconds, setOtpResendSeconds] = useState(0);
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);

  // Dealer Register Form State
  const [regFpsId, setRegFpsId] = useState('');
  const [regGmailId, setRegGmailId] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);
  const [regError, setRegError] = useState<string | null>(null);
  const [regSuccessMsg, setRegSuccessMsg] = useState<string | null>(null);
  const [isRegistering, setIsRegistering] = useState(false);
  const [detectedShop, setDetectedShop] = useState<{ dealerName: string; totalCards: number; address: string } | null>(null);

  // Owner Login Form State - Starts completely blank without pre-filled values
  const [ownerIdentifier, setOwnerIdentifier] = useState('');
  const [ownerPassword, setOwnerPassword] = useState('');
  const [showOwnerPassword, setShowOwnerPassword] = useState(false);
  const [ownerError, setOwnerError] = useState<string | null>(null);
  const [isLoggingInOwner, setIsLoggingInOwner] = useState(false);

  // Global Reset Banner
  const [resetNotice, setResetNotice] = useState<string | null>(null);

  // Countdown timer for OTP resend
  useEffect(() => {
    if (otpResendSeconds <= 0) return;
    const interval = setInterval(() => {
      setOtpResendSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [otpResendSeconds]);

  // Auto-detect shop from 12-digit FPS ID
  useEffect(() => {
    const clean = regFpsId.replace(/\D/g, '').trim();
    if (clean.length === 12) {
      const found = lookupShopByFpsId(clean);
      setDetectedShop(found);
    } else {
      setDetectedShop(null);
    }
  }, [regFpsId]);

  // Handle Dealer Login Submit
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);

    try {
      const res = loginDealer(loginIdentifier, loginPassword);
      if (res.success && res.session) {
        onLoginSuccess(res.session);
      } else {
        setLoginError(res.message);
      }
    } catch (_err) {
      setLoginError('लॉगिन करताना त्रुटी आली. कृपया पुन्हा प्रयत्न करा.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Handle Sending OTP to Gmail
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetSuccess(null);
    setIsSendingOtp(true);

    try {
      const res = sendPasswordResetOtp(resetIdentifier);
      if (res.success) {
        setOtpSentToEmail(res.email || resetIdentifier);
        setDemoOtpPreview(null);
        setResetStep('verify_otp');
        setOtpResendSeconds(60);
        setResetSuccess(res.message);

        // Dispatch real email via server endpoint
        try {
          await fetch('/api/send-email-otp', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: res.email,
              otp: res.otp,
              fpsId: res.fpsId,
              purpose: 'Password Reset'
            })
          });
        } catch (_mailErr) {
          console.warn('Mail endpoint trigger notice:', _mailErr);
        }
      } else {
        setResetError(res.message);
      }
    } catch (_err) {
      setResetError('OTP पाठवताना त्रुटी आली. कृपया पुन्हा प्रयत्न करा.');
    } finally {
      setIsSendingOtp(false);
    }
  };

  // Handle Verifying OTP and Resetting Password
  const handleVerifyOtpAndReset = (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetSuccess(null);
    setIsVerifyingOtp(true);

    try {
      const res = verifyOtpAndResetPassword(
        resetIdentifier,
        resetOtp,
        resetNewPassword,
        resetConfirmPassword
      );
      if (res.success) {
        setResetSuccess(res.message);
        setLoginIdentifier(resetIdentifier);
        setLoginPassword(resetNewPassword);
        setTimeout(() => {
          setIsResetMode(false);
          setResetStep('request_otp');
          setResetSuccess(null);
          setResetOtp('');
          setDemoOtpPreview(null);
        }, 2500);
      } else {
        setResetError(res.message);
      }
    } catch (_err) {
      setResetError('पासवर्ड बदलताना त्रुटी आली. कृपया पुन्हा प्रयत्न करा.');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  // Handle Dealer Registration Submit
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);
    setRegSuccessMsg(null);
    setIsRegistering(true);

    try {
      const res = registerDealerWithFpsAndGmail(
        regFpsId,
        regGmailId,
        regPassword,
        regConfirmPassword
      );

      if (res.success && res.session) {
        setRegSuccessMsg(res.message);
        setTimeout(() => {
          onLoginSuccess(res.session!);
        }, 1200);
      } else {
        setRegError(res.message);
      }
    } catch (_err) {
      setRegError('नोंदणी करताना त्रुटी आली. कृपया माहिती तपासून पुन्हा प्रयत्न करा.');
    } finally {
      setIsRegistering(false);
    }
  };

  // Handle Owner Login Submit
  const handleOwnerLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setOwnerError(null);
    setIsLoggingInOwner(true);

    try {
      const res = loginOwner(ownerIdentifier, ownerPassword);
      if (res.success && res.session) {
        onLoginSuccess(res.session);
      } else {
        setOwnerError(res.message);
      }
    } catch (_err) {
      setOwnerError('मालक लॉगिन करताना त्रुटी आली. कृपया पुन्हा प्रयत्न करा.');
    } finally {
      setIsLoggingInOwner(false);
    }
  };

  // Global Reset Action
  const handleResetAllData = () => {
    resetAllDealerAuthData();
    setLoginIdentifier('');
    setLoginPassword('');
    setLoginError(null);
    setRegFpsId('');
    setRegGmailId('');
    setRegPassword('');
    setRegConfirmPassword('');
    setRegError(null);
    setRegSuccessMsg(null);
    setDetectedShop(null);
    setOwnerError(null);
    setIsResetMode(false);
    setResetNotice('✅ सर्व जुने लॉगिन आणि नोंदणी तपशील पूर्णपणे रीसेट करण्यात आले आहेत!');
    setTimeout(() => setResetNotice(null), 6000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50/80 via-slate-50 to-orange-50 flex flex-col justify-center py-6 px-4 sm:px-6 lg:px-8 font-sans relative">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        {/* Government Insignia & Brand */}
        <div className="text-center">
          <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#993402] to-[#cf4d07] text-white flex items-center justify-center shadow-lg border-2 border-amber-300/40 mb-3">
            <Building2 className="w-9 h-9 text-amber-100" />
          </div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 mb-2 font-devanagari">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
            <span>अन्न, नागरी पुरवठा व ग्राहक संरक्षण विभाग · महाराष्ट्र शासन</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight font-devanagari">
            रास्त भाव दुकान ई-पॉस प्रणाली
          </h2>
          <p className="text-xs text-slate-600 mt-1 font-medium font-devanagari">
            दुकानदार लॉगिन आणि नोंदणी पोर्टल (AePDS MahaFood ePOS)
          </p>
        </div>

        {/* Global Reset Notice Banner */}
        {resetNotice && (
          <div className="mt-3 p-3 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-bold flex items-center justify-between gap-2 shadow-xs animate-in fade-in font-devanagari">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{resetNotice}</span>
            </div>
            <button
              type="button"
              onClick={() => setResetNotice(null)}
              className="text-emerald-700 hover:text-emerald-900 text-xs px-2 py-0.5 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* 3 Main Tabs: 1. Dealer Login, 2. Register, 3. Owner Login */}
        <div className="mt-6 bg-slate-200/80 p-1 rounded-2xl grid grid-cols-3 gap-1 text-xs font-bold font-devanagari shadow-inner">
          {/* Tab 1: Dealer Login */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('login');
              setIsResetMode(false);
              setLoginError(null);
            }}
            className={`py-2 px-1 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'login'
                ? 'bg-white text-slate-900 shadow-md font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Lock className="w-3.5 h-3.5 text-amber-700" />
            <span className="truncate">दुकानदार लॉगिन</span>
          </button>

          {/* Tab 2: Register */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('register');
              setRegError(null);
            }}
            className={`py-2 px-1 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'register'
                ? 'bg-white text-slate-900 shadow-md font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
            <span className="truncate">नवीन नोंदणी</span>
          </button>

          {/* Tab 3: Owner Login */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('owner');
              setOwnerError(null);
            }}
            className={`py-2 px-1 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'owner'
                ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-md font-black'
                : 'text-amber-900 hover:text-amber-950 font-bold'
            }`}
          >
            <Crown className="w-3.5 h-3.5 text-amber-300" />
            <span className="truncate">👑 मालक लॉगिन</span>
          </button>
        </div>

        {/* Dedicated WhatsApp Help & Support Card */}
        <div className="mt-3.5 bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 rounded-2xl p-3 border border-emerald-300 shadow-xs flex items-center justify-between gap-3 font-devanagari">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-emerald-950">मदत व सपोर्ट (Help & Support)</span>
                <span className="px-1.5 py-0.2 rounded text-[10px] font-black bg-emerald-200 text-emerald-900">२४x७</span>
              </div>
              <p className="text-[11px] text-emerald-800 font-semibold leading-tight mt-0.5">
                कोणतीही अडचण आल्यास संपर्क: <strong className="font-mono text-emerald-950">{SUPPORT_CONTACT.phone}</strong>
              </p>
            </div>
          </div>
          <a
            href={SUPPORT_CONTACT.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1 shrink-0 shadow-xs active:scale-95 transition-transform"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </a>
        </div>

        {/* Card Body */}
        <div className="mt-3.5 bg-white py-6 px-5 sm:px-7 rounded-3xl border border-slate-200 shadow-xl font-devanagari">
          {/* ============================================================== */}
          {/* TAB 1: DEALER LOGIN (Gmail ID / FPS ID + Password) */}
          {/* ============================================================== */}
          {activeTab === 'login' && !isResetMode && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {loginError && (
                <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-300 text-rose-950 text-xs font-semibold flex items-start gap-2.5 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{loginError}</span>
                </div>
              )}

              {/* Input: Gmail ID किंवा दुकान क्र. (FPS ID) */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Store className="w-3.5 h-3.5 text-amber-700" />
                    <span>Gmail id किंवा दुकान क्र. (FPS ID):</span>
                  </span>
                  <span className="text-[11px] font-normal text-slate-500 font-mono">150024600320</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    placeholder="Gmail आयडी किंवा १२-अंकी दुकान आयडी"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-sm text-slate-900 bg-slate-50/60 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    required
                  />
                  <Mail className="w-4 h-4 text-slate-400 absolute right-3.5 top-3 pointer-events-none" />
                </div>
              </div>

              {/* Input: Password */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-amber-700" />
                    <span>Password (पासवर्ड):</span>
                  </span>
                  <span className="text-[11px] text-slate-500">
                    डिफॉल्ट: 123456
                  </span>
                </label>
                <div className="relative">
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="आपला पासवर्ड टाका"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-bold text-slate-900 bg-slate-50/60 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Reset Password Link */}
              <div className="flex items-center justify-between text-xs pt-0.5">
                <span className="text-slate-500 text-[11px]">
                  ४-अंकी एम-पिन बंद केला आहे
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setIsResetMode(true);
                    setResetIdentifier(loginIdentifier);
                    setResetError(null);
                    setResetSuccess(null);
                  }}
                  className="text-amber-800 hover:text-amber-950 font-bold hover:underline cursor-pointer"
                >
                  पासवर्ड विसरलात? (Reset Password)
                </button>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#ba4305] to-[#993402] hover:from-[#cf4d07] hover:to-[#ba4305] text-white font-bold text-sm shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98 disabled:opacity-70"
              >
                {isLoggingIn ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-amber-200" />
                    <span>तपासणी करत आहे...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4.5 h-4.5 text-amber-300" />
                    <span>सुरक्षित लॉगिन करा (Login)</span>
                    <ArrowRight className="w-4 h-4 text-amber-200 ml-1" />
                  </>
                )}
              </button>
            </form>
          )}

          {/* ============================================================== */}
          {/* RESET PASSWORD IN-PLACE FORM WITH GMAIL OTP */}
          {/* ============================================================== */}
          {activeTab === 'login' && isResetMode && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5 font-devanagari">
                  <KeyRound className="w-4 h-4 text-amber-700" />
                  <span>
                    {resetStep === 'request_otp'
                      ? 'पासवर्ड रीसेट करा (Gmail वर OTP मागवा)'
                      : 'Gmail वर आलेला OTP पडताळा व नवीन पासवर्ड सेट करा'}
                  </span>
                </h3>
                <button
                  type="button"
                  onClick={() => {
                    setIsResetMode(false);
                    setResetStep('request_otp');
                    setResetError(null);
                    setResetSuccess(null);
                  }}
                  className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  लॉगिनवर परत जा
                </button>
              </div>

              {resetError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-900 text-xs font-semibold flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{resetError}</span>
                </div>
              )}

              {resetSuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-semibold flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{resetSuccess}</span>
                </div>
              )}

              {/* STEP 1: Enter Identifier & Request OTP */}
              {resetStep === 'request_otp' && (
                <form onSubmit={handleSendOtp} className="space-y-3.5">
                  <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-950 font-devanagari">
                    <span>सुरक्षिततेसाठी आपल्या अधिकृत नोंदणीकृत Gmail खात्यावर ६-अंकी OTP पाठवला जाईल.</span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      आपला नोंदणीकृत Gmail ID किंवा १२-अंकी दुकान क्र. (FPS ID):
                    </label>
                    <input
                      type="text"
                      value={resetIdentifier}
                      onChange={(e) => setResetIdentifier(e.target.value)}
                      placeholder="उदा. dealer@gmail.com किंवा 150024600320"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                      required
                    />
                  </div>

                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsResetMode(false)}
                      className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
                    >
                      रद्द करा
                    </button>
                    <button
                      type="submit"
                      disabled={isSendingOtp}
                      className="flex-2 py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-bold text-xs shadow-md cursor-pointer flex items-center justify-center gap-2"
                    >
                      {isSendingOtp ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-200" />
                          <span>Gmail वर OTP पाठवत आहे...</span>
                        </>
                      ) : (
                        <>
                          <Mail className="w-3.5 h-3.5 text-amber-200" />
                          <span>Gmail वर OTP पाठवा</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}

              {/* STEP 2: Verify OTP & Enter New Password */}
              {resetStep === 'verify_otp' && (
                <form onSubmit={handleVerifyOtpAndReset} className="space-y-3.5">
                  {/* Delivery Notification Box */}
                  <div className="p-3.5 rounded-2xl bg-teal-50 border border-teal-300 text-teal-950 text-xs space-y-1.5 font-devanagari">
                    <div className="flex items-center gap-1.5 font-bold">
                      <Mail className="w-4 h-4 text-teal-700 shrink-0" />
                      <span>{otpSentToEmail} या Gmail पत्त्यावर ६-अंकी OTP पाठवण्यात आला आहे!</span>
                    </div>
                    <p className="text-[11px] text-teal-800">
                      सुरक्षिततेसाठी OTP थेट आपल्या Gmail इनबॉक्स / स्पॅम फोल्डरवर पाठवला आहे. कृपया Gmail उघडून तेथील ६-अंकी OTP खाली प्रविष्ट करा.
                    </p>
                  </div>

                  {/* Input: 6-Digit OTP */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center justify-between">
                      <span>Gmail वर आलेला ६-अंकी OTP टाका:</span>
                      {otpResendSeconds > 0 ? (
                        <span className="text-[11px] text-slate-500 font-mono">पुन्हा पाठवा ({otpResendSeconds}s)</span>
                      ) : (
                        <button
                          type="button"
                          onClick={handleSendOtp}
                          className="text-[11px] text-amber-700 hover:text-amber-900 font-bold underline cursor-pointer"
                        >
                          पुन्हा OTP पाठवा
                        </button>
                      )}
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      value={resetOtp}
                      onChange={(e) => setResetOtp(e.target.value.replace(/\D/g, ''))}
                      placeholder="६-अंकी OTP टाका"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-base font-black text-center tracking-widest text-slate-900 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-teal-500 focus:outline-hidden font-mono"
                      required
                    />
                  </div>

                  {/* Input: New Password */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      नवीन पासवर्ड (New Password):
                    </label>
                    <input
                      type="password"
                      value={resetNewPassword}
                      onChange={(e) => setResetNewPassword(e.target.value)}
                      placeholder="किमान ४ अक्षरांचा नवीन पासवर्ड टाका"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                      required
                    />
                  </div>

                  {/* Input: Confirm New Password */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-1">
                      नवीन पासवर्ड पुष्टी (Confirm Password):
                    </label>
                    <input
                      type="password"
                      value={resetConfirmPassword}
                      onChange={(e) => setResetConfirmPassword(e.target.value)}
                      placeholder="तोच नवीन पासवर्ड पुन्हा टाका"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-900 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                      required
                    />
                  </div>

                  {/* Buttons */}
                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setResetStep('request_otp')}
                      className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
                    >
                      मागे जा
                    </button>
                    <button
                      type="submit"
                      disabled={isVerifyingOtp}
                      className="flex-2 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md cursor-pointer flex items-center justify-center gap-2"
                    >
                      {isVerifyingOtp ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-200" />
                          <span>पडताळत आहे...</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-200" />
                          <span>OTP पडताळा व पासवर्ड बदला</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* ============================================================== */}
          {/* TAB 2: REGISTER (FPS ID + Gmail ID + Password) */}
          {/* ============================================================== */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              {regError && (
                <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-300 text-rose-950 text-xs font-semibold flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{regError}</span>
                </div>
              )}

              {regSuccessMsg && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs font-semibold flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{regSuccessMsg}</span>
                </div>
              )}

              {/* Field 1: १२-अंकी दुकान आयडी (FPS ID) */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Store className="w-3.5 h-3.5 text-emerald-700" />
                    <span>१२-अंकी दुकान आयडी (FPS ID):</span>
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">उदा. 150024600320</span>
                </label>
                <input
                  type="text"
                  maxLength={12}
                  value={regFpsId}
                  onChange={(e) => setRegFpsId(e.target.value.replace(/\D/g, ''))}
                  placeholder="१२ अंकी दुकान आयडी टाका"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-sm font-bold text-slate-900 bg-slate-50/60 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  required
                />
              </div>

              {/* Detected Shop Preview */}
              {detectedShop && (
                <div className="p-3 rounded-2xl bg-amber-50 border border-amber-300 text-amber-950 text-xs animate-in fade-in">
                  <div className="font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>अधिकृत दुकान आढळले:</span>
                  </div>
                  <div className="font-bold mt-1 text-slate-900">
                    {detectedShop.dealerName}
                  </div>
                  <div className="text-[11px] text-slate-600">
                    एकूण कार्डे: {detectedShop.totalCards} · {detectedShop.address}
                  </div>
                </div>
              )}

              {/* Field 2: Gmail ID */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Gmail id (ई-मेल आयडी):</span>
                  </span>
                  <span className="text-[11px] text-slate-500 font-normal">उदा. shop123@gmail.com</span>
                </label>
                <input
                  type="email"
                  value={regGmailId}
                  onChange={(e) => setRegGmailId(e.target.value)}
                  placeholder="आपला अधिकृत Gmail आयडी टाका"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-sm font-bold text-slate-900 bg-slate-50/60 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  required
                />
              </div>

              {/* Field 3: Password */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Password (पासवर्ड):</span>
                  </span>
                  <span className="text-[11px] text-slate-500 font-normal">किमान ४ अक्षरे</span>
                </label>
                <div className="relative">
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="लॉगिनसाठी नवीन पासवर्ड सेट करा"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-bold text-slate-900 bg-slate-50/60 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword(!showRegPassword)}
                    className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Field 4: Confirm Password */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5">
                  पासवर्ड पुन्हा टाका (Confirm Password):
                </label>
                <input
                  type={showRegPassword ? 'text' : 'password'}
                  value={regConfirmPassword}
                  onChange={(e) => setRegConfirmPassword(e.target.value)}
                  placeholder="तोच पासवर्ड पुन्हा प्रविष्ट करा"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-bold text-slate-900 bg-slate-50/60 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  required
                />
              </div>

              {/* Free Trial Banner */}
              <div className="p-3 rounded-2xl bg-amber-50/90 border border-amber-200 text-[11px] text-amber-950 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-amber-900">
                  <span>🎁 नोंदणीनंतर ३ दिवस संपूर्ण ॲप मोफत सुरू होईल</span>
                </div>
                <p className="text-slate-600">
                  ३ दिवसांनंतर अखंड सेवेसाठी ₹१०० प्रति महिना वर्गणी लागेल. मोबाईल नंबर व एम-पिन ची आवश्यकता नाही.
                </p>
              </div>

              {/* Submit Register Button */}
              <button
                type="submit"
                disabled={isRegistering}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-700 to-teal-800 hover:from-emerald-800 hover:to-teal-900 text-white font-bold text-sm shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98 disabled:opacity-70"
              >
                {isRegistering ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-emerald-200" />
                    <span>नोंदणी करत आहे...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4.5 h-4.5 text-emerald-200" />
                    <span>नोंदणी पूर्ण करा आणि ३ दिवस मोफत ॲप वापरा</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* ============================================================== */}
          {/* TAB 3: OWNER LOGIN ("अलग से owner login ऑपशन्स") */}
          {/* ============================================================== */}
          {activeTab === 'owner' && (
            <form onSubmit={handleOwnerLoginSubmit} className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-300 text-amber-950 text-xs space-y-1">
                <div className="flex items-center gap-2 font-black text-amber-900">
                  <Crown className="w-4 h-4 text-amber-700" />
                  <span>मालक / ॲडमिन सुरक्षित लॉगिन (Owner Portal)</span>
                </div>
                <p className="text-[11px] text-slate-700">
                  इथून मालक सर्व १४ दुकानांचा डेटा पाहू व एडिट करू शकतात, ज्यांनी पेमेंट केले ते पाहू शकतात, आणि कोणाचेही आयडी ऍक्टिव्ह किंवा डेअक्टिव्ह करू शकतात.
                </p>
              </div>

              {ownerError && (
                <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-300 text-rose-950 text-xs font-semibold flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{ownerError}</span>
                </div>
              )}

              {/* Owner Email / Identifier */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                  <span>मालक Gmail ID किंवा युजरनेम:</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={ownerIdentifier}
                    onChange={(e) => setOwnerIdentifier(e.target.value)}
                    placeholder="आपला मालक Gmail ID किंवा युजरनेम टाका"
                    autoComplete="off"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-amber-300 font-mono text-sm font-bold text-slate-900 bg-amber-50/30 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    required
                  />
                  <Crown className="w-4 h-4 text-amber-700 absolute right-3.5 top-3 pointer-events-none" />
                </div>
              </div>

              {/* Owner Password */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                  <span>मालक पासवर्ड (Owner Password):</span>
                </label>
                <div className="relative">
                  <input
                    type={showOwnerPassword ? 'text' : 'password'}
                    value={ownerPassword}
                    onChange={(e) => setOwnerPassword(e.target.value)}
                    placeholder="आपला मालक पासवर्ड टाका"
                    autoComplete="new-password"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-amber-300 text-sm font-bold text-slate-900 bg-amber-50/30 focus:bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowOwnerPassword(!showOwnerPassword)}
                    className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showOwnerPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Submit Owner Login */}
              <button
                type="submit"
                disabled={isLoggingInOwner}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-700 via-amber-800 to-amber-900 hover:from-amber-800 hover:to-amber-950 text-white font-bold text-sm shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98 disabled:opacity-70"
              >
                {isLoggingInOwner ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-amber-200" />
                    <span>मालक पडताळणी करत आहे...</span>
                  </>
                ) : (
                  <>
                    <Crown className="w-4 h-4 text-amber-300" />
                    <span>👑 मालक पोर्टलमध्ये प्रवेश करा (Owner Login)</span>
                    <ArrowRight className="w-4 h-4 text-amber-200 ml-1" />
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Floating WhatsApp Help Button */}
      <aside aria-label="WhatsApp मदत आणि सपोर्ट" className="fixed bottom-5 right-5 z-40">
        <a
          href={SUPPORT_CONTACT.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white px-3.5 py-2.5 rounded-full shadow-2xl border-2 border-white/60 font-black text-xs cursor-pointer hover:scale-105 active:scale-95 transition-all group font-devanagari"
          title="WhatsApp वर मदत मिळवा"
        >
          <MessageCircle className="w-5 h-5 text-emerald-100 group-hover:animate-bounce" />
          <div className="leading-tight text-left">
            <span className="block text-[11px] font-black">मदत: {SUPPORT_CONTACT.phone}</span>
            <span className="block text-[9px] text-emerald-200 font-bold">WhatsApp संपर्क</span>
          </div>
        </a>
      </aside>
    </div>
  );
};
