import React, { useState } from 'react';
import {
  X,
  CreditCard,
  QrCode,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  ShieldCheck,
  Clock,
  Sparkles,
  ExternalLink,
  MessageCircle
} from 'lucide-react';
import { UserSession } from '../types/auth.js';
import {
  getPaymentRecipient,
  recordSubscriptionPayment,
  getSubscriptionStatus,
  SUPPORT_CONTACT
} from '../services/authService.js';

interface SubscriptionPaymentModalProps {
  session: UserSession;
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: (updatedSession: UserSession) => void;
}

export const SubscriptionPaymentModal: React.FC<SubscriptionPaymentModalProps> = ({
  session,
  isOpen,
  onClose,
  onPaymentSuccess
}) => {
  const [utrNumber, setUtrNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);

  if (!isOpen) return null;

  const recipient = getPaymentRecipient();
  const activeUpiId = recipient.upiId;
  const payeeName = recipient.payeeName;
  const monthlyFee = recipient.monthlyFee || 100;
  const activePhone = recipient.phone || recipient.whatsapp || '7709229567';

  const status = getSubscriptionStatus(session);
  // User requested exact payment app note/message when scanning QR: "AePDS FPS id 150024600320 Monthly Fee"
  const fpsIdForNote = session?.fpsId || '150024600320';
  const paymentNote = `AePDS FPS id ${fpsIdForNote} Monthly Fee`;
  const upiPayUrl = `upi://pay?pa=${encodeURIComponent(activeUpiId)}&pn=${encodeURIComponent(payeeName)}&am=${monthlyFee}&cu=INR&tn=${encodeURIComponent(paymentNote)}`;

  // QR Code with official payment note to ensure instant recognition in GPay/PhonePe/Paytm
  const qrCodeUrl = `https://quickchart.io/qr?text=${encodeURIComponent(upiPayUrl)}&size=240&margin=1`;

  const handleCopyUpi = () => {
    navigator.clipboard?.writeText(activeUpiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 3000);
  };

  const handleCopyPhone = () => {
    navigator.clipboard?.writeText(activePhone);
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 3000);
  };

  const handleVerifyPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    setIsSubmitting(true);

    try {
      const res = recordSubscriptionPayment(session.fpsId, utrNumber, monthlyFee);
      if (res.success && res.session) {
        setSuccessMessage(res.message);
        setTimeout(() => {
          onPaymentSuccess(res.session!);
          onClose();
        }, 3000);
      } else {
        setErrorMessage(res.message);
      }
    } catch (_e) {
      setErrorMessage('पेमेंट पडताळणी करताना त्रुटी आली. कृपया पुन्हा प्रयत्न करा.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 font-sans animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#ba4305] via-[#cf4d07] to-[#993402] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/15 backdrop-blur-sm border border-white/25 flex items-center justify-center p-2.5 shrink-0 shadow-inner">
              <CreditCard className="w-full h-full text-amber-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black font-devanagari">
                  ई-पॉस ॲप मासिक वर्गणी शुल्क
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-orange-950">
                  ₹१०० / महिना
                </span>
              </div>
              <p className="text-xs text-amber-100 font-devanagari">
                दुकान क्र. {session.fpsId} · {session.dealerName}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-black/20 hover:bg-black/35 text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 space-y-4 overflow-y-auto">
          {/* Status Alert Banner */}
          <div className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 ${
            status.isFreeTrial
              ? 'bg-amber-50 border-amber-300 text-amber-950'
              : status.isPaidSubscribed
              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
              : 'bg-rose-50 border-rose-300 text-rose-950'
          }`}>
            <Clock className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="font-devanagari">
              <span className="font-black block text-sm">
                {status.isFreeTrial
                  ? `🎁 ३ दिवस मोफत चाचणी सक्रिय (${status.trialHoursLeft > 24 ? `${Math.floor(status.trialHoursLeft / 24)} दिवस ${status.trialHoursLeft % 24} तास` : `${status.trialHoursLeft} तास`} शिल्लक)`
                  : status.isPaidSubscribed
                  ? `✅ मासिक वर्गणी सक्रिय (${status.paidDaysLeft} दिवस शिल्लक)`
                  : '⚠️ आपली ३ दिवसांची मोफत चाचणी समाप्त झाली आहे!'}
              </span>
              <p className="text-[11px] text-slate-700 mt-0.5">
                ॲपची सर्व वैशिष्ट्ये (साठा, वाटप, पावती व कार्डे) अखंड सुरू ठेवण्यासाठी ₹१०० प्रति महिना शुल्क ऑनलाईन जमा करा.
              </p>
            </div>
          </div>

          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-semibold flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 text-xs font-semibold flex items-start gap-2.5 animate-in fade-in">
              <Clock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block text-slate-900 text-xs">
                  ⏳ पेमेंट पडताळणी नोंदवली गेली (Verification in Progress)
                </span>
                <span className="text-[11px] text-slate-700 block mt-0.5">{successMessage}</span>
              </div>
            </div>
          )}

          {/* Payment Details Card (UPI / QR) */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3.5">
            <div className="flex items-center justify-between text-xs font-bold text-slate-800 border-b border-slate-200 pb-2">
              <span className="flex items-center gap-1.5">
                <QrCode className="w-4 h-4 text-amber-700" />
                <span>थेट बँक खात्यात ऑनलाईन पेमेंट (Direct UPI Pay):</span>
              </span>
              <span className="text-amber-800 font-black text-sm">₹ १००.००</span>
            </div>

            {/* UPI ID & Mobile Number Details with Quick Copy Buttons */}
            <div className="p-3.5 rounded-2xl bg-white border border-slate-300 space-y-3 shadow-2xs font-devanagari">
              {/* Row 1: Payee Name & UPI ID */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-100">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">खातेदार नाव (Payee Name):</span>
                  <span className="text-xs font-black text-slate-900">{payeeName}</span>
                  <div className="text-[11px] font-mono font-bold text-amber-900 mt-0.5">
                    UPI ID: <span className="text-slate-950 font-mono font-black">{activeUpiId}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleCopyUpi}
                  className="px-3 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-950 text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shrink-0 self-start sm:self-center shadow-2xs"
                  title="UPI ID कॉपी करा"
                >
                  {copiedUpi ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUpi ? 'UPI ID कॉपी झाले!' : '१. UPI ID कॉपी करा'}</span>
                </button>
              </div>

              {/* Row 2: Mobile Number for Direct GPay / PhonePe */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">मोबाईल नंबरने थेट पेमेंट (GPay / PhonePe Mobile No):</span>
                  <span className="font-mono font-black text-slate-950 text-sm tracking-wider">{activePhone}</span>
                  <span className="text-[10px] text-slate-500 block font-medium">('To Mobile Number' पर्याय निवडून पाठवा)</span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyPhone}
                  className="px-3 py-1.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-950 text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 shrink-0 self-start sm:self-center shadow-2xs"
                  title="मोबाईल नंबर कॉपी करा"
                >
                  {copiedPhone ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedPhone ? 'नंबर कॉपी झाला!' : '२. मोबाईल नंबर कॉपी करा'}</span>
                </button>
              </div>
            </div>

            {/* Bank Security Alert / Decline Solution Box */}
            <div className="p-3.5 rounded-2xl bg-amber-50 border-2 border-amber-300 text-xs font-devanagari space-y-2 shadow-xs">
              <div className="flex items-center gap-2 font-black text-amber-950">
                <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                <span>'Your payment is declined for security reasons' एरर येतोय?</span>
              </div>
              <p className="text-[11px] text-slate-800 leading-relaxed font-medium">
                बँक व NPCI च्या नवीन नियमांमुळे ऑनलाईन ॲप लिंक क्लिक केल्यास <strong className="text-rose-700 font-bold">'Your payment is declined for security reasons'</strong> असा मेसेज येऊ शकतो. यासाठी खालील ३ पैकी कोणताही एक पर्याय वापरा — पेमेंट त्वरित होईल:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-[11px] font-bold">
                <div className="p-2 rounded-xl bg-white border border-amber-300/80 text-amber-950 flex flex-col items-center text-center">
                  <span className="text-amber-800 font-black">पर्याय १</span>
                  <span>खालील QR कोड थेट स्कॅन करा</span>
                </div>
                <div className="p-2 rounded-xl bg-white border border-amber-300/80 text-amber-950 flex flex-col items-center text-center">
                  <span className="text-amber-800 font-black">पर्याय २</span>
                  <span>UPI ID ({activeUpiId}) कॉपी करा</span>
                </div>
                <div className="p-2 rounded-xl bg-white border border-amber-300/80 text-amber-950 flex flex-col items-center text-center">
                  <span className="text-amber-800 font-black">पर्याय ३</span>
                  <span>मोबाईल नंबर ({activePhone}) कॉपी करा</span>
                </div>
              </div>
            </div>

            {/* QR Code and Mobile Pay Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
              {/* QR Code with Exact Requested Note */}
              <div className="bg-white p-3.5 rounded-2xl border-2 border-amber-300 text-center shadow-xs space-y-2">
                <div className="text-xs font-black text-slate-900 flex items-center justify-center gap-1.5">
                  <QrCode className="w-4 h-4 text-amber-700" />
                  <span>📷 QR कोड स्कॅन करा (Scan QR)</span>
                </div>
                <div className="w-40 h-40 mx-auto bg-white p-1.5 rounded-xl border border-slate-200 shadow-inner flex items-center justify-center">
                  <img
                    src={qrCodeUrl}
                    alt="UPI Payment QR Code"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="bg-amber-50/90 p-2 rounded-xl border border-amber-200 text-left space-y-0.5">
                  <span className="text-[10px] font-bold text-amber-900 block">
                    Payment app मे ये मैसेज आएगा:
                  </span>
                  <div className="font-mono text-[11px] font-black text-slate-950 bg-white px-2 py-1 rounded-lg border border-amber-300 break-all select-all">
                    {paymentNote}
                  </div>
                </div>
                <div className="text-[10px] font-bold text-slate-600">
                  GPay / PhonePe / Paytm ने स्कॅन करून ₹{monthlyFee} भरा
                </div>
              </div>

              {/* Direct UPI Apps Links */}
              <div className="space-y-2.5">
                <span className="text-[11px] font-bold text-slate-700 block">
                  किंवा मोबाईलवरून थेट UPI ॲप उघडा:
                </span>
                <a
                  href={upiPayUrl}
                  className="w-full py-2.5 px-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold transition-all flex items-center justify-between shadow-xs"
                >
                  <span>🟣 PhonePe / GPay / Paytm (सर्व ॲप्स)</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <a
                  href={`phonepe://pay?pa=${encodeURIComponent(activeUpiId)}&pn=${encodeURIComponent(payeeName)}&am=${monthlyFee}&cu=INR&tn=${encodeURIComponent(paymentNote)}`}
                  className="w-full py-2.5 px-3 rounded-xl bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-bold transition-all flex items-center justify-between shadow-xs"
                >
                  <span>🟢 PhonePe थेट उघडा</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <a
                  href={`gpay://upi/pay?pa=${encodeURIComponent(activeUpiId)}&pn=${encodeURIComponent(payeeName)}&am=${monthlyFee}&cu=INR&tn=${encodeURIComponent(paymentNote)}`}
                  className="w-full py-2.5 px-3 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-all flex items-center justify-between shadow-xs"
                >
                  <span>🔵 Google Pay थेट उघडा</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

          {/* WhatsApp Support Box */}
          <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-300 flex items-center justify-between gap-2.5 font-devanagari">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <MessageCircle className="w-4 h-4" />
              </div>
              <div className="text-left">
                <span className="text-xs font-black text-emerald-950 block">पेमेंट पडताळणी किंवा मदत</span>
                <span className="text-[11px] text-emerald-800">WhatsApp: <strong className="font-mono">{SUPPORT_CONTACT.phone}</strong></span>
              </div>
            </div>
            <a
              href={SUPPORT_CONTACT.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shrink-0 flex items-center gap-1 shadow-2xs"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
          </div>

          {/* Form: Enter UTR / Transaction ID */}
          <form onSubmit={handleVerifyPayment} className="space-y-3 pt-1">
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1 flex items-center justify-between">
                <span>पेमेंट केल्यानंतर १२-अंकी UTR किंवा ट्रान्झॅक्शन आयडी टाका:</span>
                <span className="text-[10px] text-amber-800 font-semibold">अचूक १२ अंक</span>
              </label>
              <input
                type="text"
                maxLength={12}
                value={utrNumber}
                onChange={(e) => setUtrNumber(e.target.value.replace(/\D/g, ''))}
                placeholder="उदा. 428172938102 (१२-अंकी UTR नंबर)"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-sm font-bold text-slate-900 bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                required
              />
              <p className="text-[11px] text-slate-500 mt-1">
                ⚠️ बँकेत ₹१०० जमा झाल्याची पडताळणी झाल्यावर ३० दिवसांचे मासिक ॲक्सेस निश्चित होईल. बनावट किंवा चुकीचे UTR स्वीकारले जाणार नाहीत.
              </p>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || utrNumber.length !== 12}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-700 to-teal-800 hover:from-emerald-800 hover:to-teal-900 text-white font-bold text-sm shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50"
            >
              <ShieldCheck className="w-4.5 h-4.5 text-emerald-200" />
              <span>पेमेंट UTR नोंदवा व पडताळणीसाठी पाठवा (₹१००)</span>
            </button>
          </form>
        </div>

        {/* Footer */}
        <div className="bg-slate-100 p-3 text-center border-t border-slate-200 text-[11px] text-slate-600 font-devanagari">
          सुरक्षित पेमेंट थेट बँक खात्यात जमा होते · ३० दिवस अमर्यादित वापर
        </div>
      </div>
    </div>
  );
};
