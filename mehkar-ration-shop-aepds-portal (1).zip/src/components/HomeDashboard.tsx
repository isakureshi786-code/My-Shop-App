import React from 'react';
import {
  Store,
  FileSpreadsheet,
  Clock,
  Boxes,
  Layers,
  FileSearch,
  CalendarDays,
  CreditCard,
  Bell,
  Menu,
  ShieldCheck,
  ChevronRight,
  Fingerprint,
  MessageCircle,
  Phone,
  RefreshCw
} from 'lucide-react';
import { TabType } from './TabBar.js';
import { MonthYearPicker } from './MonthYearPicker.js';
import { formatMonthLabel } from '../data/datewiseTransactions.js';
import { SUPPORT_CONTACT } from '../services/authService.js';

interface HomeDashboardProps {
  onNavigate: (tab: TabType, extra?: any) => void;
  currentMonth: string;
  onMonthChange: (month: string) => void;
  lang: 'mr' | 'hi' | 'en';
  totalShops: number;
  totalCards: number;
  totalPending: number;
  monthAvailed: number;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onNavigate,
  currentMonth,
  onMonthChange,
  lang,
  totalShops,
  totalCards,
  totalPending,
  monthAvailed,
  onRefresh,
  isRefreshing = false
}) => {
  // Grid cards arranged matching vertical 2-column mobile cards ("खडे ऑपशन्स")
  const options = [
    {
      id: 'shops',
      title: 'दुकान सूची व शोध',
      subtitle: 'FPS in my Jurisdiction · रास्त भाव दुकाने',
      badge: `${totalShops} दुकाने`,
      icon: Store,
      iconColor: 'text-sky-700',
      bgColor: 'from-sky-50 to-amber-50/40',
      borderColor: 'border-sky-300',
      action: () => onNavigate('shops')
    },
    {
      id: 'aay-phh',
      title: 'योजनानिहाय कार्ड (AAY व PHH)',
      subtitle: 'योजनानिहाय धान्य वाटप व लाभार्थी नोंदी',
      badge: 'AAY व PHH',
      icon: Layers,
      iconColor: 'text-amber-800',
      bgColor: 'from-amber-50 to-orange-50/40',
      borderColor: 'border-amber-300',
      action: () => onNavigate('aay-phh')
    },
    {
      id: 'pending',
      title: 'AAY/PHH प्रलंबित कार्ड (Pending Cards)',
      subtitle: 'बाकी कार्ड · ज्यांनी धान्य घेतलेले नाही',
      badge: `${totalPending} बाकी कार्ड`,
      icon: Clock,
      iconColor: 'text-rose-700',
      bgColor: 'from-rose-50 to-amber-50/40',
      borderColor: 'border-rose-300',
      action: () => onNavigate('pending')
    },
    {
      id: 'fps-stock-register',
      title: 'FPS Stock Details (साठा तपशील)',
      subtitle: 'अधिकृत स्टॉक नोंदवही (Stock Register)',
      badge: 'ePOS रजिस्टर',
      icon: Boxes,
      iconColor: 'text-amber-700',
      bgColor: 'from-amber-50 to-yellow-50/40',
      borderColor: 'border-amber-300',
      action: () => onNavigate('fps-stock', { stockTab: 'register' })
    },
    {
      id: 'fps-stock-scheme',
      title: 'योजनानिहाय साठा तपशील',
      subtitle: 'AAY व PHH गहु, तांदूळ, साखर, मक्का साठा',
      badge: 'साठा तपशील',
      icon: FileSpreadsheet,
      iconColor: 'text-emerald-700',
      bgColor: 'from-emerald-50 to-amber-50/40',
      borderColor: 'border-emerald-300',
      action: () => onNavigate('fps-stock', { stockTab: 'scheme' })
    },
    {
      id: 'rc-detail',
      title: 'RC Detail (शिधापत्रिका तपशील)',
      subtitle: '१२-अंकी SRC शोध व कुटुंब लाभार्थी तपशील',
      badge: 'ePOS AePDS',
      icon: FileSearch,
      iconColor: 'text-indigo-700',
      bgColor: 'from-indigo-50 to-amber-50/40',
      borderColor: 'border-indigo-300',
      action: () => onNavigate('rc-detail', { searchMode: 'rc' })
    }
  ];

  return (
    <div className="space-y-4 font-devanagari max-w-4xl mx-auto">
      {/* Top Welcome Header styled exactly like user screenshot */}
      <div className="bg-white rounded-2xl p-3.5 sm:p-4 border border-slate-200/90 shadow-sm flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700 shrink-0">
            <Menu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-xs sm:text-sm font-black text-amber-900 tracking-tight flex items-center gap-1">
                <span>⚠️ WELCOME</span>
                <span className="text-slate-800">MEHKAR AePDS PORTAL</span>
              </span>
              <span className="px-1.5 py-0.2 rounded text-[10px] font-mono font-extrabold bg-amber-100 text-amber-900 border border-amber-300">
                CODE: 1500246
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-semibold mt-0.5">
              बुलढाणा जिल्हा · मेहकर शहर स्वस्त धान्य दुकान (सार्वजनिक वितरण प्रणाली)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-800 relative">
            <Bell className="w-4 h-4" />
            <span className="w-2 h-2 rounded-full bg-emerald-500 absolute top-1.5 right-1.5 ring-2 ring-white animate-pulse"></span>
          </div>
        </div>
      </div>

      {/* Active Month & Live Status Bar */}
      <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-amber-950 text-white rounded-2xl p-3.5 sm:p-4 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3 border border-amber-800/40">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-xs sm:text-sm font-bold text-amber-200">
              चालू महिना: <strong className="text-white underline underline-offset-4">{formatMonthLabel(currentMonth)}</strong>
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-600/80 text-white">
              LIVE
            </span>
          </div>
          <p className="text-[11px] text-slate-300 mt-1">
            खालीलपैकी कोणत्याही पर्यायावर क्लिक करून थेट अधिकृत अहवाल व नोंदी उघडा:
          </p>
        </div>

        {onRefresh && (
          <button
            type="button"
            onClick={onRefresh}
            disabled={isRefreshing}
            className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95 disabled:opacity-50 self-start sm:self-auto"
            title="थेट ePOS महाफूड डेटा रिफ्रेश करा"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>{isRefreshing ? 'डेटा आणत आहे...' : '🔄 डेटा रिफ्रेश'}</span>
          </button>
        )}
      </div>

      {/* Main 2-Column Vertical Grid matching user's photo ("खडे ऑपशन्स") */}
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
        {options.map((opt) => {
          const Icon = opt.icon;
          return (
            <div
              key={opt.id}
              onClick={opt.action}
              className="group bg-white rounded-2xl p-4 sm:p-5 border-2 border-slate-200/90 hover:border-amber-500 shadow-xs hover:shadow-lg transition-all duration-200 flex flex-col items-center justify-between text-center gap-3 cursor-pointer active:scale-96 min-h-[170px] sm:min-h-[185px] relative overflow-hidden"
            >
              {/* Badge top right if any */}
              {opt.badge && (
                <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded-md text-[9px] sm:text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200 group-hover:bg-amber-100 group-hover:text-amber-900 group-hover:border-amber-300 transition-colors">
                  {opt.badge}
                </div>
              )}

              {/* Circular Emblem Icon Container matching user photo */}
              <div
                className={`w-16 h-16 sm:w-18 sm:h-18 rounded-full border-2 ${opt.borderColor} bg-gradient-to-b ${opt.bgColor} flex items-center justify-center p-3.5 shadow-inner shrink-0 group-hover:scale-105 transition-transform`}
              >
                <Icon className={`w-full h-full ${opt.iconColor} stroke-[1.8]`} />
              </div>

              {/* Title & Subtitle */}
              <div className="space-y-1 w-full">
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 leading-tight group-hover:text-amber-900 transition-colors">
                  {opt.title}
                </h3>
                <p className="text-[10px] sm:text-[11px] text-slate-500 font-semibold tracking-tight leading-tight">
                  {opt.subtitle}
                </p>
              </div>

              {/* Arrow Indicator */}
              <div className="w-full flex items-center justify-center gap-1 text-[10px] font-bold text-amber-800 opacity-80 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all">
                <span>उघडा</span>
                <ChevronRight className="w-3 h-3" />
              </div>
            </div>
          );
        })}
      </div>

      {/* WhatsApp Help & Support Card */}
      <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 rounded-2xl p-3.5 sm:p-4 border border-emerald-300 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 font-devanagari">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <MessageCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-sm font-black text-emerald-950">
                अधिकृत मदत व सपोर्ट (ePOS Help & WhatsApp Support)
              </span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-emerald-200 text-emerald-900">
                LIVE
              </span>
            </div>
            <p className="text-[11px] text-emerald-800 font-semibold mt-0.5">
              साठा, पावती, पेमेंट किंवा इतर कोणत्याही अडचणीसाठी थेट संपर्क करा: <strong className="font-mono text-emerald-950">{SUPPORT_CONTACT.phone}</strong>
            </p>
          </div>
        </div>

        <a
          href={SUPPORT_CONTACT.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full sm:w-auto px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center justify-center gap-1.5 shrink-0 shadow-md active:scale-95 transition-all cursor-pointer"
        >
          <MessageCircle className="w-4 h-4" />
          <span>WhatsApp थेट संपर्क</span>
        </a>
      </div>
    </div>
  );
};
