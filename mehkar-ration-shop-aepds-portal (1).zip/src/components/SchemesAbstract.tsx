import React, { useState, useEffect } from 'react';
import { BarChart3, Layers, CheckCircle2, ShieldCheck, Wheat, PackageCheck } from 'lucide-react';
import { EposSchemeData } from '../types/epos.js';

interface SchemesAbstractProps {
  lang: 'mr' | 'hi' | 'en';
}

export const SchemesAbstract: React.FC<SchemesAbstractProps> = ({ lang }) => {
  const [schemes, setSchemes] = useState<EposSchemeData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/epos/schemes')
      .then((res) => res.json())
      .then((data) => {
        setSchemes(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load schemes:', err);
        setLoading(false);
      });
  }, []);

  const t = {
    mr: {
      title: 'योजनानिहाय विक्री व धान्य वाटप गोषवारा',
      subtitle: 'मेहकर तालुका (बुलढाणा) सार्वजनिक वितरण प्रणाली मासिक वाटप प्रगती',
      allotment: 'मंजूर कोटा (Allotment)',
      distributed: 'झालेले वाटप (Lifted/Sold)',
      balance: 'शिल्लक साठा (Balance)',
      beneficiaries: 'एकूण लाभार्थी कुटुंबे',
      commodities: 'धान्य व दर तपशील'
    },
    hi: {
      title: 'योजनावार बिक्री व खाद्यान्न वितरण सारांश',
      subtitle: 'मेहकर तहसील (बुलढाणा) सार्वजनिक वितरण प्रणाली मासिक वितरण प्रगति',
      allotment: 'स्वीकृत कोटा (Allotment)',
      distributed: 'किया गया वितरण (Lifted/Sold)',
      balance: 'शेष स्टॉक (Balance)',
      beneficiaries: 'कुल लाभार्थी परिवार',
      commodities: 'अनाज व दर विवरण'
    },
    en: {
      title: 'Scheme-wise Distribution Abstract',
      subtitle: 'Mehkar Taluka (Buldhana) PDS monthly allocation & distribution progress',
      allotment: 'Allotment Quota',
      distributed: 'Distributed / Lifted',
      balance: 'Remaining Balance',
      beneficiaries: 'Total Beneficiary Families',
      commodities: 'Commodities & Rates'
    }
  }[lang];

  if (loading) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 shadow-xs">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-amber-600 border-t-transparent mb-3"></div>
        <p className="text-sm font-medium text-slate-600 font-devanagari">
          योजनानिहाय माहिती लोड होत आहे...
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4 font-devanagari">
      {/* Overview Banner */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-amber-700" />
              {t.title}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.subtitle}</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200/60 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              सप्टेंबर २०२६ मासिक प्रगती
            </span>
          </div>
        </div>
      </div>

      {/* Scheme Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {schemes.map((scheme) => (
          <div
            key={scheme.schemeCode}
            className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between"
          >
            <div>
              {/* Scheme Header */}
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <span className="text-[10px] font-bold font-mono uppercase px-2 py-0.5 rounded bg-amber-100 text-amber-900">
                    {scheme.schemeCode}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 mt-1">
                    {lang === 'en' ? scheme.schemeNameEn : scheme.schemeNameMr}
                  </h3>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xl font-extrabold text-amber-700 tabular-nums">
                    {scheme.percentage.toFixed(1)}%
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">वाटप पूर्ण</div>
                </div>
              </div>

              <p className="text-xs text-slate-600 mt-1 mb-4 leading-relaxed">
                {scheme.description}
              </p>

              {/* Progress Bar */}
              <div className="space-y-1 mb-4">
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-600 to-emerald-600 rounded-full"
                    style={{ width: `${Math.min(100, scheme.percentage)}%` }}
                  ></div>
                </div>
              </div>

              {/* Stats Row */}
              <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-100 text-center mb-4">
                <div>
                  <div className="text-[10px] text-slate-500">{t.allotment}</div>
                  <div className="text-sm font-bold text-slate-900 tabular-nums mt-0.5">
                    {scheme.allotmentMt} <span className="text-[10px] font-normal text-slate-500">मे.टन</span>
                  </div>
                </div>
                <div className="border-x border-slate-200">
                  <div className="text-[10px] text-slate-500">{t.distributed}</div>
                  <div className="text-sm font-bold text-emerald-700 tabular-nums mt-0.5">
                    {scheme.distributedMt} <span className="text-[10px] font-normal text-slate-500">मे.टन</span>
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500">{t.balance}</div>
                  <div className="text-sm font-bold text-amber-900 tabular-nums mt-0.5">
                    {scheme.balanceMt} <span className="text-[10px] font-normal text-slate-500">मे.टन</span>
                  </div>
                </div>
              </div>

              {/* Commodities Table */}
              <div>
                <div className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
                  <Wheat className="w-3.5 h-3.5 text-amber-700" />
                  {t.commodities}:
                </div>
                <div className="space-y-1.5">
                  {scheme.commodities.map((c, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between text-xs py-1.5 px-2.5 rounded-lg bg-slate-50/70 border border-slate-100"
                    >
                      <span className="font-semibold text-slate-800">{c.nameMr}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200/60">
                          {c.ratePerKg}
                        </span>
                        <span className="text-[11px] text-slate-500 tabular-nums">
                          {c.distributed}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Card Footer */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span className="flex items-center gap-1">
                <PackageCheck className="w-3.5 h-3.5 text-slate-400" />
                {t.beneficiaries}:
              </span>
              <strong className="text-slate-800 tabular-nums">
                {scheme.totalBeneficiaries.toLocaleString('en-IN')} कुटुंबे
              </strong>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
