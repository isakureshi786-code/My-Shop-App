import React, { useState } from 'react';
import { WifiOff, RefreshCw, AlertTriangle, ShieldAlert } from 'lucide-react';

interface OfflineBlockerProps {
  onRetry: () => Promise<boolean>;
}

export const OfflineBlocker: React.FC<OfflineBlockerProps> = ({ onRetry }) => {
  const [checking, setChecking] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleCheck = async () => {
    setChecking(true);
    setErrorMsg(null);
    try {
      const isOnline = await onRetry();
      if (!isOnline) {
        setErrorMsg('इंटरनेट कनेक्शन अद्याप सुरू झालेले नाही. कृपया मोबाइल डेटा किंवा वाय-फाय चालू करा.');
      }
    } catch (_e) {
      setErrorMsg('इंटरनेट कनेक्शन सापडले नाही. कृपया पुन्हा प्रयत्न करा.');
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-slate-900/95 backdrop-blur-md flex items-center justify-center p-4 font-devanagari animate-in fade-in duration-300">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border-2 border-rose-300 text-center space-y-5">
        <div className="w-18 h-18 bg-rose-100 rounded-3xl flex items-center justify-center mx-auto text-rose-600 border border-rose-200 shadow-sm animate-pulse">
          <WifiOff className="w-9 h-9" />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold font-mono">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            <span>इंटरनेट आवश्यक · Internet Required</span>
          </div>

          <h2 className="text-xl font-black text-slate-900">
            इंटरनेट कनेक्शन बंद आहे!
          </h2>

          <p className="text-xs text-slate-600 leading-relaxed">
            महाफूड ePOS लाइव्ह सर्व्हर डेटा, थेट धान्य वाटप व्यवहार आणि शिधापत्रिका पडताळणीसाठी इंटरनेट (Mobile Data किंवा Wi-Fi) चालू असणे अनिवार्य आहे.
          </p>
        </div>

        <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-left flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <p className="text-[11px] text-amber-900 font-medium leading-relaxed">
            सुरक्षिततेसाठी हे ॲप ऑफलाइन चालत नाही. कृपया आपल्या मोबाइलमधील डेटा अथवा वाय-फाय सुरू करा आणि खालील बटणावर क्लिक करा.
          </p>
        </div>

        {errorMsg && (
          <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold animate-in fade-in">
            {errorMsg}
          </div>
        )}

        <button
          type="button"
          onClick={handleCheck}
          disabled={checking}
          className="w-full py-3.5 px-4 rounded-2xl font-black text-sm bg-gradient-to-r from-amber-700 to-amber-900 hover:from-amber-800 hover:to-amber-950 text-white shadow-lg shadow-amber-900/20 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-98 disabled:opacity-70"
        >
          <RefreshCw className={`w-4 h-4 text-amber-200 ${checking ? 'animate-spin' : ''}`} />
          <span>{checking ? 'कनेक्शन तपासत आहे...' : 'पुन्हा प्रयत्न करा (Check Connection)'}</span>
        </button>
      </div>
    </div>
  );
};
