import React, { useState } from 'react';
import { Search, ShieldAlert, CheckCircle, Wheat, ShoppingBag, MapPin, Store } from 'lucide-react';
import { EposShop } from '../types/epos.js';

interface RationCardCheckProps {
  shops: EposShop[];
  onSelectShop: (shop: EposShop) => void;
  lang: 'mr' | 'hi' | 'en';
}

export const RationCardCheck: React.FC<RationCardCheckProps> = ({
  shops,
  onSelectShop,
  lang
}) => {
  const [rcNumber, setRcNumber] = useState('');
  const [cardType, setCardType] = useState<'PHH' | 'AAY' | 'APL'>('PHH');
  const [membersCount, setMembersCount] = useState<number>(4);
  const [hasCalculated, setHasCalculated] = useState(false);

  const handleCheck = (e: React.FormEvent) => {
    e.preventDefault();
    setHasCalculated(true);
  };

  // Entitlement Calculations
  const wheatKg = cardType === 'AAY' ? 14 : cardType === 'PHH' ? membersCount * 3 : membersCount * 2;
  const riceKg = cardType === 'AAY' ? 21 : cardType === 'PHH' ? membersCount * 2 : membersCount * 3;
  const sugarKg = cardType === 'AAY' ? 1 : 0;
  const kitEligible = true;

  const nearestShops = shops.slice(0, 4);

  return (
    <div className="space-y-4 font-devanagari">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Search className="w-5 h-5 text-amber-700" />
          शिधापत्रिका (RC) पात्रता व धान्य कोटा तपासणी
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          तुमच्या १२ अंकी शिधापत्रिका क्रमांकावरून अथवा कार्ड प्रकारानुसार मासिक हक्काचे धान्य तपासा
        </p>

        {/* Input Form */}
        <form onSubmit={handleCheck} className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-1">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              शिधापत्रिका क्रमांक (१२ अंक)
            </label>
            <input
              type="text"
              value={rcNumber}
              onChange={(e) => setRcNumber(e.target.value)}
              placeholder="उदा. 272014396664"
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm font-mono focus:outline-hidden focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              कार्ड वर्गवारी (योजना)
            </label>
            <select
              value={cardType}
              onChange={(e) => setCardType(e.target.value as any)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-amber-500 bg-white"
            >
              <option value="PHH">प्राधान्य कुटुंब (PHH - केशरी/पिवळे)</option>
              <option value="AAY">अंत्योदय अन्न योजना (AAY - पिवळे)</option>
              <option value="APL">शेतकरी एपीएल (नॉन-एनएफएसए केशरी)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              कुटुंबातील एकूण व्यक्ती
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="15"
                value={membersCount}
                onChange={(e) => setMembersCount(parseInt(e.target.value, 10) || 1)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-sm tabular-nums focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold shrink-0 transition-colors cursor-pointer"
              >
                कोटा तपासा
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Calculated Entitlement Results */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <Wheat className="w-4 h-4 text-amber-700" />
            चालू महिन्याचा हक्काचा धान्य कोटा (सप्टेंबर २०२६)
          </h3>
          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
            PMGKAY अंतर्गत मोफत
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-amber-50/70 p-4 rounded-xl border border-amber-200/60 text-center">
            <div className="text-xs text-amber-900 font-semibold">हक्काचा गहू (Wheat)</div>
            <div className="text-2xl font-extrabold text-amber-950 mt-1 tabular-nums">
              {wheatKg} <span className="text-xs font-normal">Kg</span>
            </div>
            <div className="text-[10px] text-emerald-700 font-bold mt-1">दर: ₹० (मोफत)</div>
          </div>

          <div className="bg-emerald-50/70 p-4 rounded-xl border border-emerald-200/60 text-center">
            <div className="text-xs text-emerald-900 font-semibold">हक्काचा तांदूळ (Rice)</div>
            <div className="text-2xl font-extrabold text-emerald-950 mt-1 tabular-nums">
              {riceKg} <span className="text-xs font-normal">Kg</span>
            </div>
            <div className="text-[10px] text-emerald-700 font-bold mt-1">दर: ₹० (मोफत)</div>
          </div>

          <div className="bg-blue-50/70 p-4 rounded-xl border border-blue-200/60 text-center">
            <div className="text-xs text-blue-900 font-semibold">हक्काची साखर (Sugar)</div>
            <div className="text-2xl font-extrabold text-blue-950 mt-1 tabular-nums">
              {sugarKg} <span className="text-xs font-normal">Kg</span>
            </div>
            <div className="text-[10px] text-slate-600 font-semibold mt-1">
              {sugarKg > 0 ? 'दर: ₹२० / किलो' : 'केवळ AAY साठी'}
            </div>
          </div>

          <div className="bg-purple-50/70 p-4 rounded-xl border border-purple-200/60 text-center">
            <div className="text-xs text-purple-900 font-semibold">आनंदाचा शिधा किट</div>
            <div className="text-2xl font-extrabold text-purple-950 mt-1">
              १ <span className="text-xs font-normal">किट</span>
            </div>
            <div className="text-[10px] text-purple-700 font-bold mt-1">रवा, चणा, साखर, तेल</div>
          </div>
        </div>

        <div className="mt-4 p-3 bg-amber-50/50 rounded-xl border border-amber-200/40 text-xs text-slate-700 flex items-start gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <strong>नागरिकांसाठी महत्त्वाची सूचना:</strong> राष्ट्रीय अन्न सुरक्षा कायदा (NFSA) व PMGKAY अंतर्गत पात्र शिधापत्रिकाधारकांना केंद्र व राज्य शासनाकडून धान्य मोफत देण्यात येते. दुकानदाराने पावती देणे बंधनकारक आहे.
          </div>
        </div>
      </div>

      {/* Suggested Shops in Mehkar */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <h3 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
          <Store className="w-4 h-4 text-amber-700" />
          मेहकर शहरातील प्रमुख रेशन दुकाने (ONORC पोर्टेबिलिटी अंतर्गत कोणत्याही दुकानातून धान्य घेता येते)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {nearestShops.map((shop) => (
            <div
              key={shop.fpsId}
              onClick={() => onSelectShop(shop)}
              className="p-3.5 rounded-xl border border-slate-200 hover:border-amber-300 hover:bg-amber-50/30 transition-all cursor-pointer flex items-center justify-between"
            >
              <div>
                <div className="text-xs font-bold text-slate-900">{shop.dealerName}</div>
                <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3 h-3 text-amber-600" />
                  {shop.area}
                </div>
                <div className="text-[10px] font-mono text-slate-400 mt-1">
                  FPS: {shop.fpsId} · {shop.dealerMobile}
                </div>
              </div>

              <div className="text-right">
                {shop.isActive ? (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    चालू (Online)
                  </span>
                ) : (
                  <span className="text-[10px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                    बंद
                  </span>
                )}
                <div className="text-[10px] text-amber-800 font-semibold mt-1">
                  तपशील पहा →
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
