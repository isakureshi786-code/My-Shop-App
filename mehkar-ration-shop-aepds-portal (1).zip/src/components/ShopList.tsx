import React, { useState, useMemo } from 'react';
import {
  Search,
  ArrowUpRight,
  LayoutGrid,
  Table as TableIcon,
  Store,
  FileSpreadsheet,
  Printer
} from 'lucide-react';
import { EposShop } from '../types/epos.js';
import { exportToCsv, printFormattedReport } from '../utils/exportUtils.js';
import { BUNDLED_SHOPS } from '../services/eposClientData.js';
import { MonthYearPicker } from './MonthYearPicker.js';
import { formatMonthLabel } from '../data/datewiseTransactions.js';
import officialDayWiseData from '../data/officialDayWiseTrans.json';
import officialShopCounts from '../data/officialShopCounts.json';
import octoberTxs from '../data/shopTransactionsOct.json';

interface ShopListProps {
  shops: EposShop[];
  loading: boolean;
  onSelectShop: (shop: EposShop) => void;
  lang: 'mr' | 'hi' | 'en';
  currentMonth?: string;
  onMonthChange?: (month: string) => void;
}

export const ShopList: React.FC<ShopListProps> = ({
  shops,
  loading,
  onSelectShop,
  lang,
  currentMonth = '2026-10',
  onMonthChange
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Fallback to bundled shops if offline or empty
  const effectiveShops = useMemo(() => {
    return shops && shops.length > 0 ? shops : BUNDLED_SHOPS;
  }, [shops]);

  // Compute each shop's authentic numbers for current month
  const shopsWithMonthData = useMemo(() => {
    return effectiveShops.map((shop) => {
      const shopOfficial = (officialDayWiseData as any)[currentMonth]?.[shop.fpsId];
      const octList = (octoberTxs as any)[shop.fpsId] || [];
      const counts = (officialShopCounts as any)[shop.fpsId];

      const monthAvailed = currentMonth === '2026-10'
        ? (octList.length > 0 ? octList.length : (shopOfficial?.total?.availedCards ?? counts?.monthAvailed ?? 0))
        : (shopOfficial?.total?.availedCards ?? (shop.monthAvailed || 0));

      const totalCards = counts?.totalCards || shop.totalCards || 0;
      const pendingCards = Math.max(0, totalCards - monthAvailed);
      const availPct =
        totalCards > 0 ? ((monthAvailed / totalCards) * 100).toFixed(1) : '0';

      return {
        ...shop,
        totalCards,
        monthAvailed,
        pendingCards,
        availPct: parseFloat(availPct)
      };
    });
  }, [effectiveShops, currentMonth]);

  const filteredShops = useMemo(() => {
    if (!searchTerm.trim()) return shopsWithMonthData;
    const term = searchTerm.toLowerCase().trim();
    return shopsWithMonthData.filter((shop) => {
      return (
        shop.fpsId.toLowerCase().includes(term) ||
        shop.dealerName.toLowerCase().includes(term)
      );
    });
  }, [shopsWithMonthData, searchTerm]);

  const totalCardsSum = useMemo(
    () => shopsWithMonthData.reduce((sum, s) => sum + (s.totalCards || 0), 0),
    [shopsWithMonthData]
  );
  const totalMonthAvailedSum = useMemo(
    () => shopsWithMonthData.reduce((sum, s) => sum + (s.monthAvailed || 0), 0),
    [shopsWithMonthData]
  );

  const handleExportExcel = () => {
    const headers = [
      'FPS ID',
      'दुकानदाराचे नाव',
      'एकूण कार्डे',
      'मासिक वाटप',
      'मासिक टक्केवारी'
    ];

    const rows = filteredShops.map((s) => [
      s.fpsId,
      s.dealerName,
      s.totalCards,
      s.monthAvailed,
      `${s.availPct}%`
    ]);

    rows.push([
      'एकूण बेरीज',
      '',
      totalCardsSum,
      totalMonthAvailedSum,
      totalCardsSum > 0 ? `${((totalMonthAvailedSum / totalCardsSum) * 100).toFixed(1)}%` : '0%'
    ]);

    exportToCsv('मेहकर_शहर_स्वस्त_धान्य_दुकान_यादी', headers, rows);
  };

  const handlePrintPdf = () => {
    printFormattedReport({
      title: 'मेहकर शहर स्वस्त धान्य दुकान यादी',
      subtitle: 'सार्वजनिक वितरण प्रणाली (AePDS) · अन्न व नागरी पुरवठा विभाग (epos.mahafood.gov.in)',
      sections: [
        {
          headers: [
            'FPS ID',
            'दुकानदाराचे नाव',
            'एकूण कार्डे',
            'मासिक वाटप',
            'टक्केवारी'
          ],
          rows: filteredShops.map((s) => [
            s.fpsId,
            s.dealerName,
            s.totalCards,
            s.monthAvailed,
            `${s.availPct}%`
          ]),
          footerRow: [
            'एकूण बेरीज',
            '',
            totalCardsSum,
            totalMonthAvailedSum,
            totalCardsSum > 0 ? `${((totalMonthAvailedSum / totalCardsSum) * 100).toFixed(1)}%` : '0%'
          ]
        }
      ]
    });
  };

  const t = {
    mr: {
      searchPlaceholder: 'दुकान कोड (FPS ID) किंवा दुकानदाराचे नाव शोधा...',
      title: 'मेहकर शहर स्वस्त धान्य दुकान',
      subtitle: 'थेट ePOS महाफूड डेटा (epos.mahafood.gov.in)',
      cards: 'एकूण कार्डे',
      monthTrans: 'मासिक वाटप',
      viewDetails: 'तपशील व व्यवहार नोंद',
      excel: 'Excel निर्यात',
      pdf: 'PDF / प्रिंट'
    },
    hi: {
      searchPlaceholder: 'दुकान कोड (FPS ID) या डीलर का नाम खोजें...',
      title: 'मेहकर शहर स्वस्त धान्य दुकान',
      subtitle: 'लाइव ePOS महाफूड डेटा (epos.mahafood.gov.in)',
      cards: 'कुल कार्ड',
      monthTrans: 'मासिक वितरण',
      viewDetails: 'विवरण व लेन-देन',
      excel: 'Excel डाउनलोड',
      pdf: 'PDF / प्रिंट'
    },
    en: {
      searchPlaceholder: 'Search FPS ID or Dealer Name...',
      title: 'Mehkar City 14 Fair Price Shops',
      subtitle: 'Live ePOS MahaFood Data',
      cards: 'Total Cards',
      monthTrans: 'Month Dispensed',
      viewDetails: 'View Details & Transactions',
      excel: 'Export Excel',
      pdf: 'PDF / Print'
    }
  }[lang];

  return (
    <div className="space-y-4 font-devanagari">
      {/* Title & Search Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-xs space-y-3">
        {/* Active Month Status Banner */}
        <div className="flex flex-wrap items-center justify-between gap-2 bg-gradient-to-r from-amber-50 via-orange-50 to-amber-50 border border-amber-200/80 px-3.5 py-2 rounded-xl text-xs font-bold">
          <div className="flex items-center gap-2 text-amber-950">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>चालू महिना: <strong className="text-orange-950">{formatMonthLabel(currentMonth)}</strong></span>
          </div>
          <span className="text-[11px] text-slate-600 font-medium">
            (होम स्क्रीनवर चालू महिन्यानुसार १४ दुकानांचे थेट वाटप व प्रलंबित कार्डे दिसत आहेत)
          </span>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Store className="w-5 h-5 text-amber-700" />
              {t.title}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.subtitle}</p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Government-style Month & Year Picker */}
            {onMonthChange && (
              <MonthYearPicker
                currentMonth={currentMonth}
                onMonthChange={onMonthChange}
              />
            )}

            {/* Quick Metrics Badge (No active status, no today availed) */}
            <div className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-slate-800 font-bold">
                एकूण दुकाने: <strong className="tabular-nums text-amber-900">{effectiveShops.length}</strong>
              </span>
              <span className="text-slate-300">|</span>
              <span className="text-slate-800 font-bold">
                एकूण कार्डे: <strong className="tabular-nums text-slate-950">{totalCardsSum}</strong>
              </span>
              <span className="text-slate-300">|</span>
              <span className="text-emerald-800 font-bold">
                मासिक वाटप: <strong className="tabular-nums text-emerald-700">{totalMonthAvailedSum}</strong>
              </span>
            </div>

            {/* Excel & PDF Action Buttons */}
            <button
              type="button"
              onClick={handleExportExcel}
              className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Excel मध्ये डाउनलोड करा"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t.excel}</span>
            </button>

            <button
              type="button"
              onClick={handlePrintPdf}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
              title="PDF / प्रिंट"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>{t.pdf}</span>
            </button>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200/60">
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                  viewMode === 'grid'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Grid"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-lg text-xs transition-colors cursor-pointer ${
                  viewMode === 'table'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Table"
              >
                <TableIcon className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-amber-500/40 focus:border-amber-600 transition-all font-devanagari"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded cursor-pointer"
            >
              साफ करा
            </button>
          )}
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 shadow-xs">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-amber-600 border-t-transparent mb-3"></div>
          <p className="text-sm font-medium text-slate-600">
            ePOS महाफूडवरून १४ दुकानांचा थेट डेटा लोड होत आहे...
          </p>
        </div>
      )}

      {/* Grid View (No status badge, no mobile, no today's availed) */}
      {!loading && viewMode === 'grid' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredShops.map((shop) => (
            <div
              key={shop.fpsId}
              onClick={() => onSelectShop(shop)}
              className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 shadow-xs hover:shadow-md hover:border-amber-400 transition-all duration-200 flex flex-col justify-between cursor-pointer group"
            >
              <div>
                {/* Top Badge Row */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-mono font-bold text-amber-900 bg-amber-50 px-2.5 py-1 rounded border border-amber-200/70">
                    FPS: {shop.fpsId}
                  </span>
                  <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                    मेहकर शहर
                  </span>
                </div>

                {/* Dealer Name */}
                <h3 className="text-base font-bold text-slate-900 group-hover:text-amber-800 transition-colors line-clamp-1">
                  {shop.dealerName}
                </h3>

                {/* Metrics */}
                <div className="mt-3 grid grid-cols-3 gap-2 bg-slate-50/80 rounded-xl p-2.5 border border-slate-100 text-center">
                  <div>
                    <div className="text-[10px] text-slate-500 font-semibold">{t.cards}</div>
                    <div className="text-sm font-bold text-slate-800 tabular-nums">
                      {shop.totalCards}
                    </div>
                  </div>
                  <div className="border-x border-slate-200/60">
                    <div className="text-[10px] text-emerald-800 font-semibold">{t.monthTrans}</div>
                    <div className="text-sm font-extrabold text-emerald-700 tabular-nums">
                      {shop.monthAvailed}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 font-semibold">टक्केवारी</div>
                    <div className="text-sm font-bold text-slate-800 tabular-nums">
                      {shop.availPct}%
                    </div>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-2.5">
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="h-full bg-amber-600 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, shop.availPct)}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-amber-800 group-hover:text-amber-900">
                <span>{t.viewDetails}</span>
                <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Table View (Clean, strictly no mobile, no status, no today's availed) */}
      {!loading && viewMode === 'table' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-devanagari">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 uppercase text-[11px] font-bold">
                <tr>
                  <th className="py-3 px-3.5">FPS ID</th>
                  <th className="py-3 px-3.5">दुकानदाराचे नाव</th>
                  <th className="py-3 px-3.5 text-right">एकूण कार्डे</th>
                  <th className="py-3 px-3.5 text-right text-emerald-900 bg-emerald-50/50">मासिक वाटप कार्डे</th>
                  <th className="py-3 px-3.5 text-right">मासिक टक्केवारी</th>
                  <th className="py-3 px-3.5 text-center">तपशील</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredShops.map((shop) => (
                  <tr
                    key={shop.fpsId}
                    onClick={() => onSelectShop(shop)}
                    className="hover:bg-amber-50/30 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-3.5 font-mono font-bold text-amber-900">
                      {shop.fpsId}
                    </td>
                    <td className="py-3 px-3.5 font-bold text-slate-900">
                      {shop.dealerName}
                    </td>
                    <td className="py-3 px-3.5 text-right font-bold text-slate-800 tabular-nums">
                      {shop.totalCards}
                    </td>
                    <td className="py-3 px-3.5 text-right font-bold text-emerald-700 tabular-nums bg-emerald-50/30">
                      {shop.monthAvailed}
                    </td>
                    <td className="py-3 px-3.5 text-right font-bold text-slate-800 tabular-nums">
                      <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200">
                        {shop.availPct}%
                      </span>
                    </td>
                    <td className="py-3 px-3.5 text-center">
                      <button
                        type="button"
                        className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-amber-100/70 text-amber-900 hover:bg-amber-200/80 transition-colors inline-flex items-center gap-1 cursor-pointer"
                      >
                        <span>उघडा</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-amber-100/90 border-t-2 border-amber-300 font-extrabold text-xs">
                <tr>
                  <td className="py-3 px-3.5 text-slate-950 font-black">एकूण टोटल</td>
                  <td className="py-3 px-3.5 text-slate-950">१४ अधिकृत रास्त भाव दुकाने</td>
                  <td className="py-3 px-3.5 text-right tabular-nums text-slate-950 font-black">
                    {totalCardsSum}
                  </td>
                  <td className="py-3 px-3.5 text-right tabular-nums text-emerald-950 font-black bg-emerald-200/50">
                    {totalMonthAvailedSum}
                  </td>
                  <td className="py-3 px-3.5 text-right tabular-nums text-slate-950 font-black">
                    {totalCardsSum > 0 ? `${((totalMonthAvailedSum / totalCardsSum) * 100).toFixed(1)}%` : '0%'}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
