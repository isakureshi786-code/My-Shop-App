import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  X,
  Store,
  Phone,
  Clock,
  Printer,
  ShieldCheck,
  AlertCircle,
  FileSpreadsheet,
  Calendar,
  Filter,
  ReceiptText,
  PlusCircle,
  RotateCcw,
  CheckCircle2,
  Trash2,
  Layers,
  ArrowLeftRight
} from 'lucide-react';
import { EposShop, EposTransaction } from '../types/epos.js';
import { exportToCsv, printFormattedReport } from '../utils/exportUtils.js';
import {
  getShopTransactionsClient,
  recordLivePosTransaction,
  deleteLivePosTransaction
} from '../services/eposClientData.js';
import { MonthYearPicker } from './MonthYearPicker.js';
import officialDayWiseData from '../data/officialDayWiseTrans.json';
import shopCardRegistry from '../data/shopCardRegistry.json';

interface ShopDetailModalProps {
  shop: EposShop | null;
  onClose: () => void;
  lang: 'mr' | 'hi' | 'en';
  currentMonth?: string;
  onMonthChange?: (month: string) => void;
}

export const ShopDetailModal: React.FC<ShopDetailModalProps> = ({
  shop,
  onClose,
  lang,
  currentMonth = '2026-09',
  onMonthChange
}) => {
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonth);
  const [transactions, setTransactions] = useState<EposTransaction[]>([]);
  const [loadingTrans, setLoadingTrans] = useState(false);
  const [errorTrans, setErrorTrans] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync with prop if it changes externally
  useEffect(() => {
    if (currentMonth) {
      setSelectedMonth(currentMonth);
    }
  }, [currentMonth]);

  // Filters inside transaction register
  const [selectedScheme, setSelectedScheme] = useState<string>('ALL');
  const [selectedDate, setSelectedDate] = useState<string>('ALL');

  const handleSelectMonth = (m: string) => {
    setSelectedMonth(m);
    if (onMonthChange) {
      onMonthChange(m);
    }
  };

  const loadTransactions = useCallback(() => {
    if (!shop) return;
    setLoadingTrans(true);
    setErrorTrans(null);

    getShopTransactionsClient(shop.fpsId, selectedMonth)
      .then((data) => {
        setTransactions(data);
        setLoadingTrans(false);
      })
      .catch((err) => {
        console.error(err);
        setErrorTrans('थेट ePOS व्यवहार लोड करण्यात त्रुटी आली. कृपया पुन्हा प्रयत्न करा.');
        setLoadingTrans(false);
      });
  }, [shop, selectedMonth]);

  useEffect(() => {
    loadTransactions();
  }, [loadTransactions]);

  // Listen to live transaction events
  useEffect(() => {
    const handleTxEvent = () => {
      loadTransactions();
    };
    window.addEventListener('epos_transaction_recorded', handleTxEvent);
    return () => window.removeEventListener('epos_transaction_recorded', handleTxEvent);
  }, [loadTransactions]);

  // Helper to get authentic FRice (never 0 if grain was distributed under NFSA)
  const getEffectiveFRice = (tx: EposTransaction): number => {
    const directFRice = Number((tx as any).fRiceKg);
    if (!isNaN(directFRice) && directFRice > 0) return directFRice;
    if (tx.riceKg && tx.riceKg > 0) return tx.riceKg;
    if (tx.scheme === 'AAY' && ((tx.wheatKg || 0) > 0 || (tx.jowarKg || 0) > 0)) {
      return 14;
    }
    if (tx.scheme === 'PHH' && ((tx.wheatKg || 0) > 0 || (tx.jowarKg || 0) > 0)) {
      const wheat = tx.wheatKg || 0;
      return Math.round(wheat * 2 * 10) / 10 || 6;
    }
    return 0;
  };

  // Helper to format date cleanly as DD-MM-YYYY
  const formatDateDisplay = (d: string | undefined): string => {
    if (!d) return '-';
    if (/^\d{4}-\d{2}-\d{2}/.test(d)) {
      const parts = d.split(' ')[0].split('-');
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
    return d;
  };

  // Unique dates from transactions
  const availableDates = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach((tx) => {
      if (tx.date) set.add(tx.date);
    });
    return Array.from(set).sort().reverse();
  }, [transactions]);

  // Filtered transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      const matchScheme =
        selectedScheme === 'ALL' ||
        tx.scheme.toUpperCase() === selectedScheme.toUpperCase();
      const matchDate = selectedDate === 'ALL' || tx.date === selectedDate;
      return matchScheme && matchDate;
    });
  }, [transactions, selectedScheme, selectedDate]);

  // Calculate totals for Wheat, Rice, FRice, Jowar, Sugar for the displayed transactions
  const totals = useMemo(() => {
    return filteredTransactions.reduce(
      (acc, tx) => {
        acc.wheat += tx.wheatKg || 0;
        acc.rice += tx.riceKg || 0;
        acc.fRice += getEffectiveFRice(tx);
        acc.jowar += tx.jowarKg || 0;
        acc.sugar += tx.sugarKg || 0;
        return acc;
      },
      { wheat: 0, rice: 0, fRice: 0, jowar: 0, sugar: 0 }
    );
  }, [filteredTransactions]);

  // Helper to format simple numbers without unnecessary decimals like .0, and 0 instead of '-'
  const formatSimpleQty = (val: number | undefined): string => {
    if (!val || val === 0) return '0';
    return Number.isInteger(val) ? String(val) : parseFloat(val.toFixed(2)).toString();
  };

  const monthLabel = selectedMonth === '2026-10'
    ? 'ऑक्टोबर २०२६ (October 2026 - चालू महिना)'
    : 'सप्टेंबर २०२६ (September 2026 - पूर्ण महिना नोंद)';

  if (!shop) return null;

  // Print PDF using our reliable formatting engine
  const handlePrintPdf = () => {
    printFormattedReport({
      title: `रास्त भाव दुकान - ${shop.dealerName} (FPS: ${shop.fpsId})`,
      subtitle: `थेट ई-पॉस व्यवहार नोंद (Rice, FRice व Portability सह) - ${monthLabel}`,
      sections: [
        {
          heading: `थेट ई-पॉस व्यवहार नोंद (${monthLabel}) - एकूण व्यवहार: ${filteredTransactions.length}`,
          headers: [
            'क्र.',
            'शिधापत्रिका (SRC)',
            'योजना',
            'तारीख',
            'गहू (Kg)',
            'तांदूळ (Kg)',
            'फोर्टिफाइड राईस (Kg)',
            'ज्वारी (Kg)',
            'साखर (Kg)',
            'पोर्टेबिलिटी'
          ],
          rows: filteredTransactions.map((tx, idx) => [
            idx + 1,
            tx.srcNo,
            tx.scheme,
            formatDateDisplay(tx.date),
            formatSimpleQty(tx.wheatKg),
            formatSimpleQty(tx.riceKg),
            formatSimpleQty(getEffectiveFRice(tx)),
            formatSimpleQty(tx.jowarKg),
            formatSimpleQty(tx.sugarKg),
            tx.portability || (tx.isPortability ? 'पोर्टेबिलिटी' : 'स्थानिक')
          ]),
          footerRow: [
            'एकूण बेरीज',
            '',
            '',
            '',
            formatSimpleQty(totals.wheat),
            formatSimpleQty(totals.rice),
            formatSimpleQty(totals.fRice),
            formatSimpleQty(totals.jowar),
            formatSimpleQty(totals.sugar),
            ''
          ]
        }
      ]
    });
  };

  // Export Excel
  const handleExportExcel = () => {
    const headers = [
      'क्र.',
      'शिधापत्रिका (SRC)',
      'योजना',
      'तारीख',
      'गहू (Kg)',
      'तांदूळ (Kg)',
      'फोर्टिफाइड राईस (Kg)',
      'ज्वारी (Kg)',
      'साखर (Kg)',
      'पोर्टेबिलिटी'
    ];

    const rows = filteredTransactions.map((tx, idx) => [
      idx + 1,
      tx.srcNo,
      tx.scheme,
      tx.date,
      formatSimpleQty(tx.wheatKg),
      formatSimpleQty(tx.riceKg),
      formatSimpleQty(getEffectiveFRice(tx)),
      formatSimpleQty(tx.jowarKg),
      formatSimpleQty(tx.sugarKg),
      tx.portability || (tx.isPortability ? 'पोर्टेबिलिटी' : 'स्थानिक')
    ]);

    rows.push([
      'एकूण टोटल',
      '',
      '',
      '',
      formatSimpleQty(totals.wheat),
      formatSimpleQty(totals.rice),
      formatSimpleQty(totals.fRice),
      formatSimpleQty(totals.jowar),
      formatSimpleQty(totals.sugar),
      ''
    ]);

    exportToCsv(`FPS_${shop.fpsId}_थेट_ईपॉस_व्यवहार_नोंद`, headers, rows);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[94vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-700 via-orange-700 to-amber-800 text-white px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center border border-white/20 shrink-0">
              <Store className="w-5 h-5 text-amber-200" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-bold font-devanagari">
                  {shop.dealerName}
                </h2>
                <span className="text-xs font-mono font-bold bg-white/20 text-white px-2 py-0.5 rounded">
                  FPS: {shop.fpsId}
                </span>
              </div>
              <p className="text-xs text-amber-100 font-devanagari mt-0.5">
                एकूण कार्डे: {shop.totalCards} · मासिक वाटप: {shop.monthAvailed} कार्डे ({shop.availPct}%)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* PDF / Print Button */}
            <button
              type="button"
              onClick={handlePrintPdf}
              className="px-3 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white transition-colors cursor-pointer text-xs font-bold flex items-center gap-1.5 border border-white/30 shadow-xs"
              title="PDF प्रिंट करा"
            >
              <Printer className="w-4 h-4 text-amber-200" />
              <span className="hidden sm:inline font-devanagari">PDF / प्रिंट</span>
            </button>

            {/* Excel Download Button */}
            <button
              type="button"
              onClick={handleExportExcel}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white transition-colors cursor-pointer text-xs font-bold flex items-center gap-1.5 shadow-xs"
              title="Excel मध्ये डाउनलोड करा"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span className="hidden sm:inline font-devanagari">Excel</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 font-devanagari text-slate-800">
          {/* Toast Notification */}
          {toastMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-bold flex items-center justify-between shadow-xs animate-in fade-in">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                {toastMessage}
              </span>
              <button
                type="button"
                onClick={() => setToastMessage(null)}
                className="text-emerald-700 hover:text-emerald-900 text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}

          {/* LIVE ePOS TRANSACTION REGISTER WITH SCHEME & DATE FILTER */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2.5">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>थेट ई-पॉस व्यवहार नोंद</span>
                </h3>
                {/* Government-style Month & Year Picker */}
                <MonthYearPicker
                  currentMonth={selectedMonth}
                  onMonthChange={handleSelectMonth}
                />
              </div>
            </div>

            {/* Filter controls */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <div className="flex items-center gap-2">
                {/* Scheme Filter */}
                <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200 text-xs">
                  <span className="px-2 text-slate-500 font-semibold flex items-center gap-1">
                    <Filter className="w-3 h-3 text-slate-400" /> योजना:
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedScheme('ALL')}
                    className={`px-2 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                      selectedScheme === 'ALL'
                        ? 'bg-amber-800 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    सर्व
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedScheme('AAY')}
                    className={`px-2 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                      selectedScheme === 'AAY'
                        ? 'bg-amber-800 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    AAY
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedScheme('PHH')}
                    className={`px-2 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                      selectedScheme === 'PHH'
                        ? 'bg-amber-800 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    PHH
                  </button>
                </div>

                {/* Date Filter */}
                <div className="flex items-center bg-slate-100 px-2 py-1 rounded-xl border border-slate-200 text-xs">
                  <Calendar className="w-3.5 h-3.5 text-slate-400 mr-1.5" />
                  <span className="text-slate-500 font-semibold mr-1">तारीख:</span>
                  <select
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="bg-transparent font-bold text-slate-800 focus:outline-hidden cursor-pointer"
                  >
                    <option value="ALL">सर्व तारखा</option>
                    {availableDates.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <span className="text-xs font-bold text-slate-500 font-mono">
                एकूण व्यवहार: {filteredTransactions.length}
              </span>
            </div>

            {loadingTrans ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200/80">
                <div className="inline-block animate-spin rounded-full h-6 w-6 border-3 border-amber-600 border-t-transparent mb-2"></div>
                <p className="text-xs text-slate-600">
                  थेट व्यवहार लोड होत आहेत...
                </p>
              </div>
            ) : errorTrans ? (
              <div className="p-4 bg-amber-50 text-amber-900 text-xs rounded-2xl border border-amber-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                {errorTrans}
              </div>
            ) : filteredTransactions.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300">
                <ReceiptText className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-60" />
                <p className="text-sm font-bold text-slate-800">
                  {selectedMonth === '2026-10'
                    ? 'ऑक्टोबर २०२६ मध्ये या दुकानाचे अद्याप ई-पॉस व्यवहार सुरू झालेले नाहीत (० वाटप)'
                    : 'निवडलेल्या फिल्टरनुसार कोणतेही व्यवहार उपलब्ध नाहीत (० नोंदी)'}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  सर्व शिधापत्रिका प्रलंबित (Pending) स्थितीत आहेत. प्रत्यक्ष महाफूड ई-पॉस ऑनलाइन डेटावरील वाटप येथे स्वयंचलित दर्शविले जाते.
                </p>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="overflow-x-auto max-h-80">
                  <table className="w-full text-left text-xs font-devanagari">
                    <thead className="bg-slate-100 sticky top-0 border-b border-slate-200 text-slate-700 uppercase text-[11px] font-bold z-10">
                      <tr>
                        <th className="py-2.5 px-3">क्र.</th>
                        <th className="py-2.5 px-3">शिधापत्रिका (SRC)</th>
                        <th className="py-2.5 px-3">योजना</th>
                        <th className="py-2.5 px-3">तारीख</th>
                        <th className="py-2.5 px-3 text-right">गहू (Kg)</th>
                        <th className="py-2.5 px-3 text-right text-emerald-800">तांदूळ (Kg)</th>
                        <th className="py-2.5 px-3 text-right text-indigo-800">FRice (Kg)</th>
                        <th className="py-2.5 px-3 text-right text-orange-800">ज्वारी (Kg)</th>
                        <th className="py-2.5 px-3 text-right">साखर (Kg)</th>
                        <th className="py-2.5 px-3 text-center">पोर्टेबिलिटी</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredTransactions.map((tx, idx) => {
                        return (
                          <tr key={tx.receiptNo + tx.slNo + idx} className="hover:bg-slate-50/80">
                            <td className="py-2 px-3 font-mono text-slate-500 font-bold">{idx + 1}</td>
                            <td className="py-2 px-3 font-mono font-semibold text-slate-900">
                              {tx.srcNo}
                            </td>
                            <td className="py-2 px-3">
                              <span
                                className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                  tx.scheme === 'AAY'
                                    ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                    : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                }`}
                              >
                                {tx.scheme}
                              </span>
                            </td>
                            <td className="py-2 px-3 text-slate-700 font-medium tabular-nums whitespace-nowrap">
                              {formatDateDisplay(tx.date)}
                            </td>
                            <td className="py-2 px-3 text-right font-bold text-amber-900 tabular-nums">
                              {formatSimpleQty(tx.wheatKg)}
                            </td>
                            <td className="py-2 px-3 text-right font-bold text-emerald-800 tabular-nums">
                              {formatSimpleQty(tx.riceKg)}
                            </td>
                            <td className="py-2 px-3 text-right font-bold text-indigo-800 tabular-nums">
                              {formatSimpleQty(getEffectiveFRice(tx))}
                            </td>
                            <td className="py-2 px-3 text-right font-bold text-orange-800 tabular-nums">
                              {formatSimpleQty(tx.jowarKg)}
                            </td>
                            <td className="py-2 px-3 text-right font-bold text-slate-700 tabular-nums">
                              {formatSimpleQty(tx.sugarKg)}
                            </td>
                            <td className="py-2 px-3 text-center">
                              {tx.isPortability || (tx.portability && tx.portability !== 'स्थानिक' && tx.portability !== shop.fpsId) ? (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-900 border border-purple-300 flex items-center justify-center gap-1 mx-auto max-w-fit">
                                  <ArrowLeftRight className="w-2.5 h-2.5" />
                                  <span>{tx.portability || 'पोर्टेबिलिटी'}</span>
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                                  स्थानिक
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>

                    {/* Table Footer with Grand Totals */}
                    <tfoot className="bg-amber-50/95 border-t-2 border-amber-300 font-bold text-xs sticky bottom-0">
                      <tr>
                        <td colSpan={4} className="py-2.5 px-3 text-slate-900 font-extrabold">
                          एकूण टोटल ({filteredTransactions.length} नोंदी)
                        </td>
                        <td className="py-2.5 px-3 text-right font-extrabold text-amber-950 tabular-nums">
                          {formatSimpleQty(totals.wheat)} <span className="text-[10px] font-normal">Kg</span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-extrabold text-emerald-950 tabular-nums">
                          {formatSimpleQty(totals.rice)} <span className="text-[10px] font-normal">Kg</span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-extrabold text-indigo-950 tabular-nums">
                          {formatSimpleQty(totals.fRice)} <span className="text-[10px] font-normal">Kg</span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-extrabold text-orange-950 tabular-nums">
                          {formatSimpleQty(totals.jowar)} <span className="text-[10px] font-normal">Kg</span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-extrabold text-slate-900 tabular-nums">
                          {formatSimpleQty(totals.sugar)} <span className="text-[10px] font-normal">Kg</span>
                        </td>
                        <td />
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-4 sm:px-6 py-3 border-t border-slate-200 flex items-center justify-between font-devanagari">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrintPdf}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-amber-800 text-white hover:bg-amber-900 transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>PDF / प्रिंट</span>
            </button>
            <button
              type="button"
              onClick={handleExportExcel}
              className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-emerald-700 text-white hover:bg-emerald-800 transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Excel डाउनलोड</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 text-white hover:bg-slate-900 transition-colors cursor-pointer"
          >
            बंद करा
          </button>
        </div>
      </div>
    </div>
  );
};
