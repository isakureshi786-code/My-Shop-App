export interface EposShop {
  fpsId: string;
  dealerName: string;
  dealerMobile: string;
  totalCards: number;
  aayCards?: number;
  phhCards?: number;
  aayAvailed?: number;
  phhAvailed?: number;
  aayPending?: number;
  phhPending?: number;
  totalPending?: number;
  pendingCardsList?: {
    srNo: number;
    srcNo: string;
    cardHolderName?: string;
    scheme: 'AAY' | 'PHH';
    units?: number;
    entitlement?: string;
  }[];
  stockRegister?: FpsStockItem[];
  stockRegisterByMonth?: Record<
    string,
    {
      stockRegister: FpsStockItem[];
      schemeStock: FpsSchemeStock[];
    }
  >;
  isActive: boolean;
  firstLogin: string;
  lastLogin: string;
  todayAvailed: number;
  monthAvailed: number;
  availPct: number;
  area: string;
  areaType: string;
  taluka: string;
  district: string;
  state: string;
  posId: string;
  shopNumber: string;
  stock: {
    wheatKg: number;
    riceKg: number;
    sugarKg: number;
    chanaKg: number;
    oilPkts: number;
    aayWheatStockKg?: number;
    aayRiceStockKg?: number;
    aaySugarStockKg?: number;
    phhWheatStockKg?: number;
    phhRiceStockKg?: number;
    phhJowarStockKg?: number;
    jowarKg?: number;
  };
}

export interface FpsStockItem {
  slNo: number;
  commodity: string;
  units: string;
  alloted: number;
  ob: number;
  receivedRegular: number;
  extra: number;
  moved: number;
  issued: number;
  cb: number;
}

export interface FpsSchemeStock {
  commodity: string;
  units: string;
  aayOb: number;
  phhOb: number;
  aayReceived: number;
  aayIssued: number;
  aayBalance: number;
  phhReceived: number;
  phhIssued: number;
  phhBalance: number;
  totalReceived: number;
  totalIssued: number;
  totalBalance: number;
}

export interface EposStats {
  totalShops: number;
  activeShops: number;
  inactiveShops: number;
  todayTransactions: number;
  monthTransactions: number;
  totalCards: number;
  lastSync: string;
  lastSyncIso: string;
  serverStatus: 'ONLINE' | 'STANDBY' | 'SYNCING';
  gatewayUrl: string;
  district: string;
  taluka: string;
}

export interface EposTransaction {
  slNo: number;
  srcNo: string;
  scheme: string;
  availType: string;
  receiptNo: string;
  date: string;
  wheatKg: number;
  riceKg: number;
  sugarKg: number;
  jowarKg: number;
  amount: number;
  portability: string;
  authTime: string;
  fRiceKg?: number;
  totalRiceKg?: number;
  cardHolderName?: string;
  isPortability?: boolean;
  portabilityType?: string;
  portabilityFpsId?: string;
  fpsId?: string;
  month?: string;
}

export interface EposSchemeData {
  schemeCode: string;
  schemeNameMr: string;
  schemeNameEn: string;
  description: string;
  totalBeneficiaries: number;
  allotmentMt: number;
  distributedMt: number;
  balanceMt: number;
  percentage: number;
  commodities: {
    nameMr: string;
    ratePerKg: string;
    quota: string;
    distributed: string;
  }[];
}

export interface EposDateSale {
  date: string;
  day: number;
  transactions: number;
  activeShops: number;
  wheatDistributedKg: number;
  riceDistributedKg: number;
  sugarDistributedKg: number;
  peakHour: string;
}

export interface RcMemberItem {
  slNo: string | number;
  member: string;
  gender: string;
  age: number;
  status: string;
  uid: string;
  aadhaarNumber?: string;
}

export interface RcEntitlement {
  wheat: string;
  sugar: string;
  jowar: string;
  fRice: string;
}

export interface RcTransactionItem {
  slNo: string | number;
  member: string;
  availedFps: string;
  receiptId: string;
  month: string;
  year: string;
  availDate: string;
  availType: string;
  wheat: string;
  sugar: string;
  jowar: string;
  fRice: string;
}

export interface RcDetailsResult {
  success: boolean;
  rcNo: string;
  searchedAadhaar?: string;
  month?: string;
  year?: string;
  headerInfo: {
    district: string;
    taluk: string;
    fpsId: string;
    scheme: string;
  };
  members: RcMemberItem[];
  entitlement: RcEntitlement | null;
  transactions: RcTransactionItem[];
  previousMonthTransactions?: RcTransactionItem[];
  source?: 'epos_live' | 'local_database';
  error?: string;
}
