export interface PaymentRecord {
  id?: string;
  utr: string;
  amount: number;
  date: string;
  status: 'SUCCESS' | 'PENDING' | 'REJECTED';
  method: 'UPI' | 'QR' | 'CASH';
  fpsId: string;
  dealerName?: string;
  gmailId?: string;
  mobileNumber?: string;
  planDurationMonths: number;
  approvedAt?: string;
  rejectedReason?: string;
}

export interface DealerAccount {
  fpsId: string;
  gmailId: string;
  password?: string;
  dealerName: string;
  shopAddress?: string;
  totalCards?: number;
  aayCards?: number;
  phhCards?: number;
  isRegistered?: boolean;
  registeredAt: string;
  trialEndsAt: string; // 3 days free trial
  isSubscribed: boolean;
  subscriptionEndsAt?: string;
  lastPaymentRef?: string;
  payments?: PaymentRecord[];
  lastLoginAt?: string;
  isActive: boolean; // ID active (true) or deactive (false)
  statusNote?: string;
  // legacy compatibility
  mobileNumber?: string;
  mpin?: string;
}

export interface PaymentRecipientConfig {
  upiId: string;
  payeeName: string;
  email: string;
  monthlyFee: number;
  currency: string;
  note: string;
  phone?: string;
  whatsapp?: string;
}

export interface UserSession {
  fpsId: string;
  gmailId: string;
  dealerName: string;
  shopAddress?: string;
  totalCards?: number;
  loginTime: string;
  role: 'dealer' | 'owner' | 'inspector';
  registeredAt: string;
  trialEndsAt: string;
  isSubscribed: boolean;
  subscriptionEndsAt?: string;
  isActive: boolean;
  mobileNumber?: string;
}

export interface RegisterFormData {
  fpsId: string;
  gmailId: string;
  password: string;
  confirmPassword: string;
}

