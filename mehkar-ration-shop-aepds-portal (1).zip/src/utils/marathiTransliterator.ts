/**
 * High-precision English to Marathi (Devanagari) name transliterator
 * Designed specifically for Maharashtra AePDS Ration Cards & Beneficiary records.
 */

const DICTIONARY: Record<string, string> = {
  // Surnames
  'PATIL': 'पाटील',
  'DESHMUKH': 'देशमुख',
  'SHINDE': 'शिंदे',
  'JADHAV': 'जाधव',
  'KADAM': 'कदम',
  'PAWAR': 'पवार',
  'CHAVAN': 'चव्हाण',
  'GAIKWAD': 'गायकवाड',
  'WANKHEDE': 'वानखेडे',
  'KURESHI': 'कुरेशी',
  'QURESHI': 'कुरेशी',
  'KURESI': 'कुरेशी',
  'RATHOD': 'राठोड',
  'INGLE': 'इंगळे',
  'INGALE': 'इंगळे',
  'GIRHE': 'गिरहे',
  'MORE': 'मोरे',
  'BHOSALE': 'भोसले',
  'BHOSLE': 'भोसले',
  'KALE': 'काळे',
  'TAYADE': 'तायडे',
  'BAGADE': 'बागडे',
  'KHAN': 'खान',
  'SHAIKH': 'शेख',
  'SHEIKH': 'शेख',
  'SK': 'शेख',
  'SASTE': 'सस्ते',
  'SONAWANE': 'सोनवणे',
  'THORAT': 'थोरात',
  'SALUNKE': 'साळुंके',
  'DEVDE': 'देवडे',
  'SAWANT': 'सावंत',
  'KAMBLE': 'कांबळे',
  'DHOBALE': 'धोबळे',
  'KHADSE': 'खडसे',
  'KHERODKAR': 'खेरोडकर',
  'LANDAGE': 'लांडगे',
  'RASAKAR': 'रसकर',
  'KULVANT': 'कुलवंत',
  'BARGAT': 'बारगट',
  'GANDHILE': 'गांधीले',
  'BANCHARE': 'बंचारे',
  'NARVADE': 'नरवाडे',
  'WATORE': 'वाठोरे',
  'VATORE': 'वाठोरे',
  'JAHAGIRDAR': 'जहागीरदार',
  'KHATIK': 'खाटिक',
  'MANIYAR': 'मनियार',
  'TAWLE': 'तावळे',
  'GOTE': 'गोटे',
  'SAPKAL': 'सपकाळ',
  'KHARAT': 'खरात',
  'MHASKE': 'म्हस्के',
  'BORSE': 'बोरसे',
  'DHAGE': 'ढगे',
  'GAVHANE': 'गव्हाणे',
  'WAGH': 'वाघ',
  'MUNDE': 'मुंडे',
  'SHAH': 'शाह',
  'SAYYAD': 'सय्यद',

  // Male First/Middle Names
  'RAMESH': 'रमेश',
  'GAJANAN': 'गजानन',
  'KAILAS': 'कैलास',
  'KAILASH': 'कैलास',
  'PRAKASH': 'प्रकाश',
  'SURESH': 'सुरेश',
  'SANJAY': 'संजय',
  'SACHIN': 'सचिन',
  'VIKAS': 'विकास',
  'NITIN': 'नितिन',
  'RAHUL': 'राहुल',
  'AMOL': 'अमोल',
  'GANESH': 'गणेश',
  'DILIP': 'दिलीप',
  'SUNIL': 'सुनील',
  'VINOD': 'विनोद',
  'MOHSIN': 'मोहसीन',
  'ISA': 'ईसा',
  'MATIN': 'मतीन',
  'AYAZ': 'अयाज',
  'ABDUL': 'अब्दुल',
  'PRABHAKAR': 'प्रभाकर',
  'MANOJ': 'मनोज',
  'ASHOK': 'अशोक',
  'SUDHIR': 'सुधीर',
  'TUKARAM': 'तुकाराम',
  'SAKHARAM': 'सखाराम',
  'LAXMAN': 'लक्ष्मण',
  'LAKSHMAN': 'लक्ष्मण',
  'MAROTI': 'मारोती',
  'NAMDEO': 'नामदेव',
  'NAMADEV': 'नामदेव',
  'RAMRAO': 'रामराव',
  'BHIMRAO': 'भीमराव',
  'VITHOBA': 'विठोबा',
  'WAMAN': 'वामन',
  'HARIBHAU': 'हरिभाऊ',
  'RAJESH': 'राजेश',
  'SANDIP': 'संदीप',
  'SANDEEP': 'संदीप',
  'NARAYAN': 'नारायण',
  'BABURAV': 'बाबुराव',
  'BABURAO': 'बाबुराव',
  'JANKIRAM': 'जानकीराम',
  'KUNDLIK': 'कुंडलिक',
  'UDDHAV': 'उद्धव',
  'BHAGWAN': 'भगवान',
  'ATMARAM': 'आत्माराम',
  'JAGAN': 'जगन',
  'TEJARAO': 'तेजराव',
  'BHUJANGRAO': 'भुजंगराव',
  'MAHADU': 'महादू',
  'AHILAJI': 'अहिलाजी',
  'VIJAY': 'विजय',
  'HABIB': 'हबीब',
  'AHMAD': 'अहमद',
  'AHMED': 'अहमद',
  'RIYAZ': 'रियाज',
  'RAFIK': 'रफीक',
  'RAFIQUE': 'रफीक',
  'NASIB': 'नसीब',
  'ARSHAN': 'अर्शान',
  'KADAR': 'कादर',
  'RAHIM': 'रहीम',
  'HASNAIN': 'हसनैन',
  'SIBTAIN': 'सिबतेन',
  'SALIM': 'सलीम',
  'HAMID': 'हमीद',
  'SABDAR': 'सबदार',
  'HARUN': 'हारून',
  'ILYAS': 'इलियास',
  'IMTIYAZ': 'इम्तियाज',
  'RAHAT': 'राहत',
  'ASALIM': 'सलीम',
  'GULAM': 'गुलाम',
  'TASLIM': 'तस्लीम',
  'SANDU': 'संडू',
  'MANESH': 'मानेष',
  'MAHESH': 'महेश',
  'DNYANESHWAR': 'ज्ञानेश्वर',
  'PANDURANG': 'पांडुरंग',
  'VISHNU': 'विष्णू',
  'SHIVAJI': 'शिवाजी',
  'ANIL': 'अनिल',
  'DATTATRAY': 'दत्तात्रय',
  'SANTOSH': 'संतोष',
  'BABAN': 'बबन',
  'DEVIDAS': 'देवीदास',
  'KASHINATH': 'काशिनाथ',
  'PRADIP': 'प्रदीप',
  'PRADEEP': 'प्रदीप',
  'SHARAD': 'शरद',

  // Female Names
  'SUNITA': 'सुनिता',
  'ANITA': 'अनिता',
  'MANGALA': 'मंगला',
  'GEETA': 'गीता',
  'GITA': 'गीता',
  'REKHA': 'रेखा',
  'SHOBHA': 'शोभा',
  'KAVITA': 'कविता',
  'VANDANA': 'वंदना',
  'SAVITA': 'सविता',
  'USHA': 'उषा',
  'SUMAN': 'सुमन',
  'LAXMI': 'लक्ष्मी',
  'LAKSHMI': 'लक्ष्मी',
  'CHANDRAKALA': 'चंद्रकला',
  'PARVEEN': 'परवीन',
  'PARWIN': 'परवीन',
  'NAGAMA': 'नगमा',
  'SINDHU': 'सिंधू',
  'AARTI': 'आरती',
  'POOJA': 'पूजा',
  'KIRAN': 'किरण',
  'PRIYA': 'प्रिया',
  'SNEHA': 'स्नेहा',
  'MONIKA': 'मोनिका',
  'KAMALBAI': 'कमलबाई',
  'SHANTABAI': 'शांताबाई',
  'PARVATIBAI': 'पार्वतीबाई',
  'SUSHILA': 'सुशीला',
  'RADHA': 'राधा',
  'PURVA': 'पूर्वा',
  'SHASIKALA': 'शशिकला',
  'SHASHIKALA': 'शशिकला',
  'BHARTI': 'भारती',
  'FARHAT': 'फरहत',
  'JAHAN': 'जहाँ',
  'FATEMA': 'फातेमा',
  'BI': 'बी',
  'BEE': 'बी',
  'RAZIYABI': 'रजियाबी',
  'RAZIYA': 'रजिया',
  'UZMA': 'उज्मा',
  'JAINU': 'जैनू',
  'MALAN': 'मालन',
  'NASIM': 'नसीम',
  'NORJAHA': 'नूरजहाँ',
  'RESHMA': 'रेशमा',
  'ZIYA': 'झिया',
  'MUNNI': 'मुन्नी',
  'SHAMIM': 'शमीम',
  'RAFIKABI': 'रफीकाबी',
  'SAPURABI': 'सपूराबी',
  'AYESHA': 'आयेशा',
  'FIRDOS': 'फिरदोस'
};

/**
 * Phonetic transliterator fallback for any English word into Marathi
 */
function transliterateWord(word: string): string {
  const upper = word.toUpperCase().trim();
  if (!upper) return '';

  if (DICTIONARY[upper]) {
    return DICTIONARY[upper];
  }

  // If already contains Devanagari characters, return as is
  if (/[\u0900-\u097F]/.test(word)) {
    return word;
  }

  // Simple phonetic transliteration
  let s = upper;
  s = s.replace(/KH/g, 'ख')
       .replace(/GH/g, 'घ')
       .replace(/CHH/g, 'छ')
       .replace(/CH/g, 'च')
       .replace(/JH/g, 'झ')
       .replace(/TH/g, 'थ')
       .replace(/DH/g, 'ध')
       .replace(/PH/g, 'फ')
       .replace(/BH/g, 'भ')
       .replace(/SH/g, 'श')
       .replace(/SHH/g, 'ष')
       .replace(/K/g, 'क')
       .replace(/G/g, 'ग')
       .replace(/J/g, 'ज')
       .replace(/T/g, 'ट')
       .replace(/D/g, 'द')
       .replace(/N/g, 'न')
       .replace(/P/g, 'प')
       .replace(/B/g, 'ब')
       .replace(/M/g, 'म')
       .replace(/Y/g, 'य')
       .replace(/R/g, 'र')
       .replace(/L/g, 'ल')
       .replace(/V/g, 'व')
       .replace(/W/g, 'व')
       .replace(/S/g, 'स')
       .replace(/H/g, 'ह')
       .replace(/A/g, 'ा')
       .replace(/AA/g, 'ा')
       .replace(/I/g, 'ी')
       .replace(/EE/g, 'ी')
       .replace(/U/g, 'ू')
       .replace(/OO/g, 'ू')
       .replace(/E/g, 'े')
       .replace(/AI/g, 'ै')
       .replace(/O/g, 'ो')
       .replace(/AU/g, 'ौ');

  return s;
}

/**
 * Transliterates any full name (English or mixed English/Marathi) to 100% Marathi Devanagari.
 * Guarantees that only the Family Head name is returned in unified Marathi.
 */
export function toMarathiHeadName(name: string): string {
  if (!name || !name.trim()) {
    return 'कुटुंब प्रमुख';
  }

  const raw = name.trim();

  // If pure Marathi Devanagari already with no Latin letters
  if (/^[\u0900-\u097F\s.,'-]+$/.test(raw)) {
    return raw;
  }

  // If mixed (some Marathi, some English like "विजय NAMADEV GANDHILE" or "इंगळे महादू AHILAJI")
  const tokens = raw.split(/\s+/);
  const convertedTokens = tokens.map((token) => {
    // If token is already Marathi Devanagari
    if (/^[\u0900-\u097F]+$/.test(token)) {
      return token;
    }
    // Clean punctuation
    const cleanWord = token.replace(/[^a-zA-Z]/g, '');
    if (!cleanWord) return token;
    return transliterateWord(cleanWord);
  });

  return convertedTokens.join(' ').trim();
}
