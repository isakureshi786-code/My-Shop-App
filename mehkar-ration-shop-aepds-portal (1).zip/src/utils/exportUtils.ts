import { jsPDF } from 'jspdf';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

/**
 * Utility functions for Excel (CSV with UTF-8 BOM) and Direct PDF File Download / Printing
 */

export function exportToCsv(filename: string, headers: string[], rows: (string | number)[][]) {
  const csvContent = [
    headers.map((h) => `"${String(h).replace(/"/g, '""')}"`).join(','),
    ...rows.map((row) =>
      row
        .map((cell) => {
          const str = cell !== undefined && cell !== null ? String(cell) : '';
          return `"${str.replace(/"/g, '""')}"`;
        })
        .join(',')
    )
  ].join('\r\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export interface PrintReportOptions {
  title: string;
  subtitle?: string;
  sections?: {
    heading?: string;
    headers: string[];
    rows: (string | number)[][];
    footerRow?: (string | number)[];
  }[];
}

/**
 * Native Canvas-based Direct PDF generator.
 * Uses browser's native 2D Canvas context for 100% reliable Devanagari text rendering
 * and jsPDF to save the actual .pdf binary file.
 */
async function generateDirectCanvasPdf(
  title: string,
  subtitle: string | undefined,
  sections: PrintReportOptions['sections'],
  filename: string,
  customRowHeight: number = 46
) {
  const canvasWidth = 1400;
  const pageHeight = 1980; // A4 aspect ratio at 1400 width
  const marginX = 40;
  const marginTop = 50;
  const tableWidth = canvasWidth - marginX * 2;

  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  let isFirstPage = true;

  const createPageCanvas = () => {
    const c = document.createElement('canvas');
    c.width = canvasWidth;
    c.height = pageHeight;
    const ctx = c.getContext('2d')!;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvasWidth, pageHeight);
    return { canvas: c, ctx };
  };

  let { canvas: currentPageCanvas, ctx } = createPageCanvas();
  let currentY = marginTop;

  // Draw Title & Subtitle in BOLD
  ctx.fillStyle = '#000000';
  ctx.font = 'bold 36px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Mukta", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(title, canvasWidth / 2, currentY);
  currentY += 44;

  if (subtitle) {
    ctx.font = 'bold 24px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Mukta", sans-serif';
    ctx.fillText(subtitle, canvasWidth / 2, currentY);
    currentY += 40;
  }

  currentY += 12;

  const savePage = () => {
    const imgData = currentPageCanvas.toDataURL('image/jpeg', 0.96);
    if (!isFirstPage) {
      pdf.addPage();
    }
    pdf.addImage(imgData, 'JPEG', 5, 5, 200, 287);
    isFirstPage = false;
    const newPage = createPageCanvas();
    currentPageCanvas = newPage.canvas;
    ctx = newPage.ctx;
    currentY = marginTop;
  };

  if (!sections || sections.length === 0) {
    savePage();
    pdf.save(filename);
    return;
  }

  for (const sec of sections) {
    if (sec.heading) {
      if (currentY + 44 > pageHeight - 60) {
        savePage();
      }
      ctx.textAlign = 'left';
      ctx.font = 'bold 26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Mukta", sans-serif';
      ctx.fillStyle = '#000000';
      ctx.fillText(sec.heading, marginX, currentY + 26);
      currentY += 42;
    }

    const colCount = sec.headers.length;
    // Calculate column widths
    const colWidths: number[] = [];
    if (colCount === 10) {
      // 10 columns: 'क्र.', 'दिनांक', 'वाटप कार्डे', 'गहू', 'तांदूळ', 'साखर', 'ज्वारी', 'F Rice', 'एकूण तांदूळ', 'एकूण धान्य'
      const specific = [65, 175, 125, 125, 125, 110, 125, 125, 145, 160];
      const sum = specific.reduce((a, b) => a + b, 0);
      specific.forEach((w) => colWidths.push((w / sum) * tableWidth));
    } else if (colCount === 9) {
      const specific = [70, 240, 120, 130, 130, 130, 130, 110, 120];
      const sum = specific.reduce((a, b) => a + b, 0);
      specific.forEach((w) => colWidths.push((w / sum) * tableWidth));
    } else if (colCount === 8) {
      const specific = [80, 280, 120, 180, 160, 160, 170, 170];
      const sum = specific.reduce((a, b) => a + b, 0);
      specific.forEach((w) => colWidths.push((w / sum) * tableWidth));
    } else if (colCount === 5) {
      // 5 columns: 'क्र.', 'शिधापत्रिका क्र. (SRC)', 'कार्डधारकाचे नाव', 'योजना', 'सदस्य'
      const specific = [60, 250, 480, 100, 110];
      const sum = specific.reduce((a, b) => a + b, 0);
      specific.forEach((w) => colWidths.push((w / sum) * tableWidth));
    } else if (colCount === 7) {
      const specific = [70, 240, 120, 120, 120, 120, 110];
      const sum = specific.reduce((a, b) => a + b, 0);
      specific.forEach((w) => colWidths.push((w / sum) * tableWidth));
    } else {
      const equalWidth = tableWidth / colCount;
      for (let i = 0; i < colCount; i++) colWidths.push(equalWidth);
    }

    const rowHeight = customRowHeight || 52;

    // Draw Table Header in BOLD
    const drawHeader = () => {
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(marginX, currentY, tableWidth, rowHeight);
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(marginX, currentY, tableWidth, rowHeight);

      let colX = marginX;
      for (let i = 0; i < colCount; i++) {
        const w = colWidths[i];
        ctx.strokeRect(colX, currentY, w, rowHeight);
        ctx.font = 'bold 23px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Mukta", sans-serif';
        ctx.fillStyle = '#000000';
        const isNumCol = colCount === 5 ? (i === 4 || i === 0 || i === 3) : (i >= 2 || i === 0);
        ctx.textAlign = isNumCol ? 'center' : 'left';
        const textX = isNumCol ? colX + w / 2 : colX + 12;
        let headerText = sec.headers[i];
        const maxW = w - 10;
        while (ctx.measureText(headerText).width > maxW && headerText.length > 2) {
          headerText = headerText.slice(0, -1);
        }
        ctx.fillText(headerText, textX, currentY + Math.round(rowHeight / 2) + 8);
        colX += w;
      }
      currentY += rowHeight;
    };

    drawHeader();

    // Draw Rows in BOLD with clean column clipping
    for (let rIdx = 0; rIdx < sec.rows.length; rIdx++) {
      if (currentY + rowHeight > pageHeight - 60) {
        savePage();
        drawHeader();
      }

      const row = sec.rows[rIdx];
      ctx.fillStyle = rIdx % 2 === 0 ? '#ffffff' : '#f8fafc';
      ctx.fillRect(marginX, currentY, tableWidth, rowHeight);
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(marginX, currentY, tableWidth, rowHeight);

      let colX = marginX;
      for (let cIdx = 0; cIdx < colCount; cIdx++) {
        const w = colWidths[cIdx];
        ctx.strokeRect(colX, currentY, w, rowHeight);
        ctx.font = 'bold 22px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Mukta", sans-serif';
        ctx.fillStyle = '#000000';
        const isCenterCol = colCount === 5 ? (cIdx === 0 || cIdx === 3 || cIdx === 4) : (cIdx === 0);
        const isRightCol = colCount !== 5 && cIdx >= 2;
        ctx.textAlign = isCenterCol ? 'center' : isRightCol ? 'right' : 'left';
        const textX = isCenterCol ? colX + w / 2 : isRightCol ? colX + w - 10 : colX + 10;

        let cellVal = String(row[cIdx] ?? '');
        const maxTextW = w - 12;
        if (ctx.measureText(cellVal).width > maxTextW) {
          while (ctx.measureText(cellVal + '..').width > maxTextW && cellVal.length > 2) {
            cellVal = cellVal.slice(0, -1);
          }
          cellVal += '..';
        }

        ctx.fillText(cellVal, textX, currentY + Math.round(rowHeight / 2) + 8);
        colX += w;
      }
      currentY += rowHeight;
    }

    // Draw Footer Row in BOLD
    if (sec.footerRow) {
      if (currentY + rowHeight > pageHeight - 60) {
        savePage();
        drawHeader();
      }

      ctx.fillStyle = '#fef08a'; // bright yellow
      ctx.fillRect(marginX, currentY, tableWidth, rowHeight);
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(marginX, currentY, tableWidth, rowHeight);

      let colX = marginX;
      for (let cIdx = 0; cIdx < colCount; cIdx++) {
        const w = colWidths[cIdx];
        ctx.strokeRect(colX, currentY, w, rowHeight);
        ctx.font = 'bold 20px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Mukta", sans-serif';
        ctx.fillStyle = '#000000';
        const isNumCol = cIdx >= 4;
        ctx.textAlign = isNumCol ? 'right' : cIdx === 0 ? 'center' : 'left';
        const textX = isNumCol ? colX + w - 12 : cIdx === 0 ? colX + w / 2 : colX + 12;
        const cellVal = String(sec.footerRow[cIdx] ?? '');
        ctx.fillText(cellVal, textX, currentY + Math.round(rowHeight / 2) + 7);
        colX += w;
      }
      currentY += rowHeight;
    }
  }

  savePage();

  try {
    const pdfBlob = pdf.output('blob');
    const blobUrl = URL.createObjectURL(pdfBlob);
    const dataUri = pdf.output('datauristring');
    const cleanFilename = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;

    // 1. If running inside Capacitor APK on Android
    try {
      if (Capacitor.isNativePlatform()) {
        const base64Data = dataUri.split(',')[1];
        const writeRes = await Filesystem.writeFile({
          path: cleanFilename,
          data: base64Data,
          directory: Directory.Documents,
          recursive: true
        });
        await Share.share({
          title: cleanFilename,
          text: `${title} - PDF अहवाल`,
          url: writeRes.uri,
          dialogTitle: 'PDF जतन करा / सेव्ह करा'
        });
        return { success: true, blobUrl, blob: pdfBlob, dataUri, downloadUrl: writeRes.uri };
      }
    } catch (capErr) {
      console.warn('Capacitor native share error:', capErr);
    }

    // 2. Upload to server to get real HTTP GET download URL
    let serverDownloadUrl = '';
    try {
      const resp = await fetch('/api/store-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: cleanFilename, pdfBase64: dataUri })
      });
      if (resp.ok) {
        const json = await resp.json();
        serverDownloadUrl = json.downloadUrl;
      }
    } catch (_sErr) {
      // server fetch error
    }

    const effectiveUrl = serverDownloadUrl || blobUrl;

    // 3. Trigger download via hidden iframe without navigating or breaking main window/iframe
    try {
      let dlFrame = document.getElementById('pdf-download-hidden-iframe') as HTMLIFrameElement;
      if (!dlFrame) {
        dlFrame = document.createElement('iframe');
        dlFrame.id = 'pdf-download-hidden-iframe';
        dlFrame.name = 'pdf-download-hidden-iframe';
        dlFrame.style.display = 'none';
        dlFrame.style.width = '0px';
        dlFrame.style.height = '0px';
        dlFrame.style.border = 'none';
        document.body.appendChild(dlFrame);
      }

      if (serverDownloadUrl) {
        dlFrame.src = serverDownloadUrl;
      } else {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/api/download-pdf';
        form.target = 'pdf-download-hidden-iframe';
        form.style.display = 'none';

        const fInput = document.createElement('input');
        fInput.type = 'hidden';
        fInput.name = 'filename';
        fInput.value = cleanFilename;
        form.appendChild(fInput);

        const dInput = document.createElement('input');
        dInput.type = 'hidden';
        dInput.name = 'pdfBase64';
        dInput.value = dataUri;
        form.appendChild(dInput);

        document.body.appendChild(form);
        form.submit();
        setTimeout(() => form.remove(), 2000);
      }
    } catch (_formErr) {
      // form error
    }

    // 4. Also trigger direct anchor download with blob URL as dual-guarantee
    try {
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = cleanFilename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) {
          link.remove();
        }
      }, 2000);
    } catch (_aErr) {
      // anchor error
    }

    return { success: true, blobUrl, blob: pdfBlob, dataUri, downloadUrl: effectiveUrl };
  } catch (_e) {
    try {
      pdf.save(filename);
    } catch (_saveErr) {
      console.warn('PDF save error, fallback to print:', _saveErr);
    }
    return { success: true };
  }
}

/**
 * Universal print and direct PDF download function.
 * Displays ONLY the clean, bold table report with no extra header fluff.
 */
export function printFormattedReport(options: PrintReportOptions) {
  const { title, subtitle, sections = [] } = options;

  // Remove any previous print container
  const existingContainer = document.getElementById('print-modal-container');
  if (existingContainer) {
    existingContainer.remove();
  }

  // Ensure print style sheet exists
  const printStyleId = 'epos-global-print-styles';
  if (!document.getElementById(printStyleId)) {
    const styleEl = document.createElement('style');
    styleEl.id = printStyleId;
    styleEl.innerHTML = `
      @media print {
        body > *:not(#print-modal-container) {
          display: none !important;
        }
        #print-modal-container {
          position: static !important;
          background: white !important;
          padding: 0 !important;
          margin: 0 !important;
          box-shadow: none !important;
          display: block !important;
          width: 100% !important;
          height: auto !important;
          overflow: visible !important;
        }
        .no-print-toolbar {
          display: none !important;
        }
        @page {
          size: A4 portrait;
          margin: 8mm 8mm 8mm 8mm;
        }
      }
    `;
    document.head.appendChild(styleEl);
  }

  const container = document.createElement('div');
  container.id = 'print-modal-container';
  container.className =
    'fixed inset-0 z-[99999] bg-slate-900/85 backdrop-blur-xs flex flex-col p-2 sm:p-6 overflow-y-auto font-sans';

  const cleanFilename = `${title.replace(/[\s\/:*?"<>|]+/g, '_')}_अहवाल.pdf`;

  // CLEAN, BOLD HTML: All metadata grid completely removed as instructed ("ये सब डिलिट करे")
  const reportContentHtml = `
    <!-- Top Floating Toolbar (Hidden during print) -->
    <div class="no-print-toolbar max-w-4xl w-full mx-auto mb-3 bg-slate-900 text-white rounded-2xl p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3 shadow-2xl border border-slate-700">
      <div class="flex items-center gap-2">
        <span class="text-xs sm:text-sm font-extrabold text-amber-300">📄 अहवाल PDF व प्रिंट</span>
      </div>

      <!-- Adjust Row Height & Font Size Controls -->
      <div class="flex flex-wrap items-center gap-2">
        <div class="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
          <span class="text-[11px] font-bold text-slate-300">फॉन्ट (Font Size):</span>
          <button id="btn-font-normal" type="button" class="px-2.5 py-1 rounded-lg font-bold text-[10px] bg-slate-700 hover:bg-slate-600 text-white transition-all cursor-pointer">
            मध्यम
          </button>
          <button id="btn-font-large" type="button" class="px-2.5 py-1 rounded-lg font-bold text-[10px] bg-amber-600 text-white transition-all cursor-pointer shadow-xs">
            मोठा (Bold)
          </button>
        </div>

        <div class="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
          <span class="text-[11px] font-bold text-slate-300">रो ची उंची:</span>
          <button id="btn-height-compact" type="button" class="px-2.5 py-1 rounded-lg font-bold text-[10px] bg-slate-700 hover:bg-slate-600 text-white transition-all cursor-pointer">
            कमी
          </button>
          <button id="btn-height-normal" type="button" class="px-2.5 py-1 rounded-lg font-bold text-[10px] bg-amber-600 text-white transition-all cursor-pointer shadow-xs">
            मध्यम
          </button>
          <button id="btn-height-large" type="button" class="px-2.5 py-1 rounded-lg font-bold text-[10px] bg-slate-700 hover:bg-slate-600 text-white transition-all cursor-pointer">
            मोठी
          </button>
        </div>
      </div>

      <div class="flex items-center gap-2">
        <!-- Direct Real PDF File Download Button -->
        <button id="btn-download-pdf-direct" type="button" class="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs shadow-md transition-all cursor-pointer flex items-center gap-1.5 active:scale-95">
          <span>📥 थेट PDF डाउनलोड (.pdf)</span>
        </button>
        <!-- Close Button -->
        <button id="btn-close-print" type="button" class="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors cursor-pointer">
          <span>❌ बंद करा</span>
        </button>
      </div>
    </div>

    <!-- Paper Sheet (What actually prints and saves to PDF) -->
    <div class="print-paper bg-white rounded-2xl max-w-4xl w-full mx-auto p-4 sm:p-8 shadow-2xl text-black space-y-3 font-devanagari">
      <!-- Clean Bold Header -->
      <div class="text-center pb-2 border-b-2 border-black">
        <h1 class="text-lg sm:text-xl font-black text-black tracking-tight">${title}</h1>
        ${subtitle ? `<p class="text-xs sm:text-sm font-bold text-black mt-1">${subtitle}</p>` : ''}
      </div>

      <!-- Sections: All table text strictly BOLD with solid black borders -->
      ${sections
        .map(
          (sec) => `
        <div class="space-y-1.5 mt-2">
          ${sec.heading ? `<h2 class="text-xs sm:text-sm font-black text-black uppercase tracking-wide border-l-4 border-black pl-2">${sec.heading}</h2>` : ''}
          <div class="overflow-x-auto">
            <table class="w-full text-left text-sm border-collapse border-2 border-black font-bold">
              <thead>
                <tr class="bg-slate-200 text-black text-xs sm:text-sm font-black border-2 border-black">
                  ${sec.headers.map((h) => `<th class="border-2 border-black p-2 font-black text-black">${h}</th>`).join('')}
                </tr>
              </thead>
              <tbody class="divide-y divide-black text-black font-bold">
                ${sec.rows
                  .map(
                    (row) => `<tr class="hover:bg-slate-50">
                    ${row
                      .map((c, i) => {
                        const isNum = typeof c === 'number' || (!isNaN(Number(c)) && String(c).trim() !== '');
                        const alignClass = i >= 2 && isNum ? 'text-right font-mono' : i === 0 ? 'text-center font-mono' : '';
                        return `<td class="border border-black p-2 font-bold text-black text-xs sm:text-sm ${alignClass}">${c}</td>`;
                      })
                      .join('')}
                  </tr>`
                  )
                  .join('')}
              </tbody>
              ${
                sec.footerRow
                  ? `<tfoot>
                <tr class="bg-amber-200/90 font-black text-black text-xs sm:text-sm border-2 border-black">
                  ${sec.footerRow
                    .map((c, i) => {
                      const alignClass = i >= 2 ? 'text-right font-mono' : '';
                      return `<td class="border-2 border-black p-2 font-black text-black ${alignClass}">${c}</td>`;
                    })
                    .join('')}
                </tr>
              </tfoot>`
                  : ''
              }
            </table>
          </div>
        </div>`
        )
        .join('')}

      </div>
    </div>
  `;

  container.innerHTML = reportContentHtml;
  document.body.appendChild(container);

  // Row Height Adjustment State & Event Listeners
  let selectedRowHeight = 48;
  const btnCompact = document.getElementById('btn-height-compact');
  const btnNormal = document.getElementById('btn-height-normal');
  const btnLarge = document.getElementById('btn-height-large');
  const btnFontNormal = document.getElementById('btn-font-normal');
  const btnFontLarge = document.getElementById('btn-font-large');
  const tableCells = container.querySelectorAll('td, th');

  const setRowHeightMode = (mode: 'compact' | 'normal' | 'large') => {
    btnCompact?.classList.remove('bg-amber-600');
    btnNormal?.classList.remove('bg-amber-600');
    btnLarge?.classList.remove('bg-amber-600');
    btnCompact?.classList.add('bg-slate-700');
    btnNormal?.classList.add('bg-slate-700');
    btnLarge?.classList.add('bg-slate-700');

    if (mode === 'compact') {
      selectedRowHeight = 36;
      btnCompact?.classList.add('bg-amber-600');
      btnCompact?.classList.remove('bg-slate-700');
      tableCells.forEach((c) => {
        (c as HTMLElement).style.padding = '4px 6px';
        (c as HTMLElement).style.fontSize = '12px';
      });
    } else if (mode === 'large') {
      selectedRowHeight = 56;
      btnLarge?.classList.add('bg-amber-600');
      btnLarge?.classList.remove('bg-slate-700');
      tableCells.forEach((c) => {
        (c as HTMLElement).style.padding = '10px 10px';
        (c as HTMLElement).style.fontSize = '15px';
      });
    } else {
      selectedRowHeight = 48;
      btnNormal?.classList.add('bg-amber-600');
      btnNormal?.classList.remove('bg-slate-700');
      tableCells.forEach((c) => {
        (c as HTMLElement).style.padding = '7px 8px';
        (c as HTMLElement).style.fontSize = '13.5px';
      });
    }
  };

  const setFontSizeMode = (mode: 'normal' | 'large') => {
    btnFontNormal?.classList.remove('bg-amber-600');
    btnFontLarge?.classList.remove('bg-amber-600');
    btnFontNormal?.classList.add('bg-slate-700');
    btnFontLarge?.classList.add('bg-slate-700');

    if (mode === 'large') {
      btnFontLarge?.classList.add('bg-amber-600');
      btnFontLarge?.classList.remove('bg-slate-700');
      tableCells.forEach((c) => {
        (c as HTMLElement).style.fontSize = '15.5px';
        (c as HTMLElement).style.fontWeight = '800';
      });
    } else {
      btnFontNormal?.classList.add('bg-amber-600');
      btnFontNormal?.classList.remove('bg-slate-700');
      tableCells.forEach((c) => {
        (c as HTMLElement).style.fontSize = '13.5px';
      });
    }
  };

  btnCompact?.addEventListener('click', () => setRowHeightMode('compact'));
  btnNormal?.addEventListener('click', () => setRowHeightMode('normal'));
  btnLarge?.addEventListener('click', () => setRowHeightMode('large'));
  btnFontNormal?.addEventListener('click', () => setFontSizeMode('normal'));
  btnFontLarge?.addEventListener('click', () => setFontSizeMode('large'));

  // Hook up Direct Native Canvas PDF Download (Only on explicit click, no auto background download)
  const btnDownloadPdf = document.getElementById('btn-download-pdf-direct');
  const btnClose = document.getElementById('btn-close-print');

  btnDownloadPdf?.addEventListener('click', async () => {
    if (btnDownloadPdf) {
      btnDownloadPdf.textContent = '⏳ PDF तयार होत आहे... कृपया थांबा';
      (btnDownloadPdf as HTMLButtonElement).disabled = true;
    }
    try {
      await generateDirectCanvasPdf(title, subtitle, sections, cleanFilename, selectedRowHeight);
      if (btnDownloadPdf) {
        btnDownloadPdf.textContent = '✅ PDF डाऊनलोड पूर्ण झाली!';
      }
    } catch (err) {
      console.error('Direct canvas PDF error:', err);
    } finally {
      setTimeout(() => {
        if (btnDownloadPdf) {
          btnDownloadPdf.textContent = '📥 थेट PDF डाउनलोड (.pdf)';
          (btnDownloadPdf as HTMLButtonElement).disabled = false;
        }
      }, 4000);
    }
  });

  btnClose?.addEventListener('click', () => {
    container.remove();
  });
}
