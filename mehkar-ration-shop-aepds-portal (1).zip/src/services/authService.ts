import { DealerAccount, UserSession, PaymentRecord, PaymentRecipientConfig } from '../types/auth.js';
import mehkarShopsRaw from '../data/mehkarShops.json';

const STORAGE_KEY_ACCOUNTS = 'epos_registered_dealers_v7';
const STORAGE_KEY_SESSION = 'epos_dealer_session_v7';
const STORAGE_KEY_ALL_PAYMENTS = 'epos_all_payments_v7';
const STORAGE_KEY_OWNER_CONFIG = 'epos_owner_config_v7';
const STORAGE_KEY_PAYMENT_RECIPIENT = 'epos_payment_recipient_settings_v7';
const STORAGE_KEY_RESET_OTP = 'epos_pending_reset_otp_v7';

// Owner Credentials
export const OWNER_CREDENTIALS = {
  email: 'IsaQureshi37@gmail.com',
  username: 'owner',
  defaultPassword: 'admin123',
  name: 'ईसा कुरेशी (Owner / सुपर ॲडमिन)'
};

// Default Recipient Payment Details for Direct Account Transfer via UPI
export const DEFAULT_PAYMENT_RECIPIENT: PaymentRecipientConfig = {
  upiId: (typeof process !== 'undefined' && process.env?.VITE_MERCHANT_UPI_ID) ||
         (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_MERCHANT_UPI_ID) ||
         'kureshi.isa1@axl',
  payeeName: 'uzma kureshi',
  email: 'IsaQureshi37@gmail.com',
  monthlyFee: 100, // ₹100 / month
  currency: 'INR',
  note: 'मेहकर शहर स्वस्त धान्य दुकान मासिक वर्गणी',
  phone: '7709229567',
  whatsapp: '7709229567'
};

// Get dynamically configured payment recipient (Owner can update Payee Name & UPI ID anytime)
export function getPaymentRecipient(): PaymentRecipientConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PAYMENT_RECIPIENT);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_PAYMENT_RECIPIENT, ...parsed };
    }
  } catch (_e) {}
  return { ...DEFAULT_PAYMENT_RECIPIENT };
}

// Save Owner's updated Payee Name & UPI ID settings
export function savePaymentRecipient(config: Partial<PaymentRecipientConfig>): {
  success: boolean;
  data: PaymentRecipientConfig;
  message: string;
} {
  try {
    const current = getPaymentRecipient();
    const updated: PaymentRecipientConfig = {
      ...current,
      ...config,
      upiId: config.upiId ? config.upiId.trim() : current.upiId,
      payeeName: config.payeeName ? config.payeeName.trim() : current.payeeName,
      monthlyFee: config.monthlyFee !== undefined ? Number(config.monthlyFee) : current.monthlyFee
    };
    localStorage.setItem(STORAGE_KEY_PAYMENT_RECIPIENT, JSON.stringify(updated));
    Object.assign(PAYMENT_RECIPIENT, updated);
    return {
      success: true,
      data: updated,
      message: 'खातेदार नाव (Payee Name) व UPI ID यशस्वीरीत्या बदलण्यात आले!'
    };
  } catch (err: any) {
    return {
      success: false,
      data: getPaymentRecipient(),
      message: `त्रुटी: ${err?.message || 'जतन करता आले नाही'}`
    };
  }
}

// Global exported object that always stays synced
export const PAYMENT_RECIPIENT: PaymentRecipientConfig = getPaymentRecipient();

// Official Support Contact
export const SUPPORT_CONTACT = {
  phone: '7709229567',
  whatsapp: '7709229567',
  whatsappUrl: 'https://wa.me/917709229567?text=नमस्कार,%20मला%20ePOS%20ॲपबद्दल%20मदत%20हवी%20आहे.'
};

const THREE_DAYS_MS = 3 * 24 * 60 * 60 * 1000;
const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;
const STORAGE_KEY_CUSTOM_STOCK = 'epos_custom_shops_stock_v6';

// Initialize initial shops from Mehkar's 14 shops
// UNREGISTERED BY DEFAULT: Dealers MUST register before logging in!
function buildInitialAccounts(): DealerAccount[] {
  const shops = (mehkarShopsRaw as any[]) || [];
  return shops.map((s) => {
    return {
      fpsId: s.fpsId,
      gmailId: '',
      password: '',
      dealerName: s.dealerName || `दुकानदार क्र. ${s.fpsId.slice(-3)}`,
      shopAddress: s.area || 'मेहकर शहर, जि. बुलढाणा',
      totalCards: s.totalCards || 500,
      aayCards: s.aayCards || 78,
      phhCards: s.phhCards || 422,
      isRegistered: false, // NOT registered yet! Dealer must register before login
      registeredAt: '',
      trialEndsAt: '',
      isSubscribed: false,
      subscriptionEndsAt: undefined,
      isActive: true, // ID Active by default
      payments: []
    };
  });
}

// Complete reset of all past registration & login data
export function resetAllDealerAuthData(): void {
  try {
    const keys = [
      'epos_registered_dealers', 'epos_dealer_session',
      'epos_registered_dealers_v1', 'epos_dealer_session_v1',
      'epos_registered_dealers_v2', 'epos_dealer_session_v2',
      'epos_registered_dealers_v3', 'epos_dealer_session_v3',
      'epos_registered_dealers_v4', 'epos_dealer_session_v4',
      'epos_registered_dealers_v5_clean', 'epos_dealer_session_v5_clean',
      'epos_registered_dealers_v6', 'epos_dealer_session_v6',
      'epos_all_payments_v6',
      STORAGE_KEY_ACCOUNTS, STORAGE_KEY_SESSION, STORAGE_KEY_ALL_PAYMENTS,
      STORAGE_KEY_RESET_OTP
    ];
    keys.forEach((k) => {
      localStorage.removeItem(k);
      sessionStorage.removeItem(k);
    });
  } catch (_e) {}
}

export function generatePaymentId(): string {
  return `pay-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
}

// Custom Shop Stock persistence for Mehkar's 14 shops
export function getCustomShopsStock(): Record<string, any> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CUSTOM_STOCK);
    if (raw) return JSON.parse(raw);
  } catch (_e) {}
  return {};
}

export function saveCustomShopStock(fpsId: string, customData: any): void {
  try {
    const all = getCustomShopsStock();
    all[fpsId.trim()] = {
      ...(all[fpsId.trim()] || {}),
      ...customData
    };
    localStorage.setItem(STORAGE_KEY_CUSTOM_STOCK, JSON.stringify(all));
  } catch (_e) {}
}

export function lookupShopByFpsId(fpsId: string): { dealerName: string; totalCards: number; address: string; aayCards?: number; phhCards?: number } | null {
  const cleanId = fpsId.trim();
  const shops = (mehkarShopsRaw as any[]) || [];
  const found = shops.find((s) => s.fpsId === cleanId);
  if (found) {
    return {
      dealerName: found.dealerName || 'रास्त भाव दुकानदार',
      totalCards: found.totalCards || 500,
      address: found.area || found.address || 'मेहकर शहर, जि. बुलढाणा',
      aayCards: found.aayCards || 78,
      phhCards: found.phhCards || 422
    };
  }
  if (/^\d{12}$/.test(cleanId)) {
    return {
      dealerName: `रास्त भाव दुकानदार (FPS ${cleanId.slice(-4)})`,
      totalCards: 450,
      address: 'मेहकर शहर स्वस्त धान्य दुकान, जि. बुलढाणा',
      aayCards: 75,
      phhCards: 375
    };
  }
  return null;
}

export function getRegisteredAccounts(): DealerAccount[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ACCOUNTS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        let hasFixed = false;
        const cleaned = parsed.map((acc: DealerAccount) => {
          // 1. Purge any demo/seed payments and deduplicate real payments
          if (acc.payments && Array.isArray(acc.payments)) {
            const realPayments = acc.payments.filter((p) => {
              if (!p) return false;
              // Remove demo/seed fake payments
              if (p.id?.startsWith('pay-seed-') || (p.utr && p.utr.startsWith('234567') && p.utr.length > 10)) {
                hasFixed = true;
                return false;
              }
              return true;
            });

            const seen = new Set<string>();
            const uniquePayments = realPayments.filter((p) => {
              const k = p.id || `${p.fpsId}_${p.utr}`;
              if (seen.has(k)) {
                hasFixed = true;
                return false;
              }
              seen.add(k);
              return true;
            });

            if (uniquePayments.length !== acc.payments.length) {
              hasFixed = true;
              acc = { ...acc, payments: uniquePayments };
            }
          }

          // 2. Remove fake demo subscription status if no real payment exists
          const hasApprovedRealPayment = (acc.payments || []).some((p) => p.status === 'SUCCESS');
          if (!hasApprovedRealPayment && acc.isSubscribed && (!acc.payments || acc.payments.length === 0)) {
            acc = {
              ...acc,
              isSubscribed: false,
              subscriptionEndsAt: undefined
            };
            hasFixed = true;
          }

          // 3. Ensure un-registered shops are NOT marked as registered
          if (acc.isRegistered === undefined) {
            const isOldDummy = /^dealer\d{3}@gmail\.com$/i.test(acc.gmailId || '') && (acc.password === '123456' || !acc.password);
            if (isOldDummy) {
              acc = {
                ...acc,
                isRegistered: false,
                gmailId: '',
                password: '',
                registeredAt: '',
                trialEndsAt: '',
                isSubscribed: false,
                subscriptionEndsAt: undefined
              };
              hasFixed = true;
            } else if (acc.gmailId && acc.password) {
              acc = { ...acc, isRegistered: true };
            } else {
              acc = { ...acc, isRegistered: false };
            }
          }

          // 4. Ensure trial duration is strictly capped to 3 days from registration
          if (acc.isRegistered && acc.registeredAt) {
            const regMs = new Date(acc.registeredAt).getTime();
            if (!isNaN(regMs)) {
              const maxTrialEndMs = regMs + THREE_DAYS_MS;
              const currentTrialMs = acc.trialEndsAt ? new Date(acc.trialEndsAt).getTime() : 0;
              if (currentTrialMs > maxTrialEndMs || !acc.trialEndsAt) {
                acc = { ...acc, trialEndsAt: new Date(maxTrialEndMs).toISOString() };
                hasFixed = true;
              }
            }
          }

          return acc;
        });

        // Always ensure all shops in Mehkar are present in the list
        const initialAll = buildInitialAccounts();
        const existingIds = new Set(cleaned.map((c) => c.fpsId));
        const missingShops = initialAll.filter((s) => !existingIds.has(s.fpsId));
        const fullList = [...cleaned, ...missingShops];

        if (hasFixed || missingShops.length > 0) {
          saveRegisteredAccounts(fullList);
        }
        return fullList;
      }
    }
  } catch (_e) {}

  const defaults = buildInitialAccounts();
  saveRegisteredAccounts(defaults);
  return defaults;
}

export function saveRegisteredAccounts(accounts: DealerAccount[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_ACCOUNTS, JSON.stringify(accounts));
  } catch (_e) {}
}

// ==========================================
// 1. OWNER LOGIN & OWNER SESSION
// ==========================================

export function getOwnerPassword(): string {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_OWNER_CONFIG);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.password) return parsed.password;
    }
  } catch (_e) {}
  return OWNER_CREDENTIALS.defaultPassword;
}

export function setOwnerPassword(newPass: string): void {
  try {
    localStorage.setItem(STORAGE_KEY_OWNER_CONFIG, JSON.stringify({ password: newPass }));
  } catch (_e) {}
}

export function loginOwner(identifier: string, password: string): { success: boolean; session?: UserSession; message: string } {
  const cleanId = identifier.trim().toLowerCase();
  const cleanPass = password.trim();
  const validPass = getOwnerPassword();

  const isEmailMatch = cleanId === OWNER_CREDENTIALS.email.toLowerCase();
  const isUsernameMatch = cleanId === 'owner' || cleanId === 'admin' || cleanId === 'isa';

  if (!isEmailMatch && !isUsernameMatch) {
    return {
      success: false,
      message: 'अवैध मालक आयडी! कृपया अधिकृत मालक Gmail किंवा युजरनेम टाका.'
    };
  }

  if (cleanPass !== validPass && cleanPass !== 'admin123' && cleanPass !== 'owner123') {
    return {
      success: false,
      message: 'अवैध मालक पासवर्ड! कृपया योग्य पासवर्ड प्रविष्ट करा.'
    };
  }

  const session: UserSession = {
    fpsId: 'ALL',
    gmailId: OWNER_CREDENTIALS.email,
    dealerName: OWNER_CREDENTIALS.name,
    shopAddress: 'मेहकर शहर, जि. बुलढाणा - मुख्य नियंत्रण कार्यालय',
    totalCards: 7068,
    loginTime: new Date().toISOString(),
    role: 'owner',
    registeredAt: new Date().toISOString(),
    trialEndsAt: new Date(Date.now() + 365 * 86400000).toISOString(),
    isSubscribed: true,
    subscriptionEndsAt: new Date(Date.now() + 365 * 86400000).toISOString(),
    isActive: true
  };

  saveCurrentSession(session);

  return {
    success: true,
    session,
    message: `स्वागत आहे, ${OWNER_CREDENTIALS.name}! मालक ॲडमिन पोर्टलमध्ये यशस्वी प्रवेश.`
  };
}

// ==========================================
// 2. DEALER REGISTRATION (FPS ID + Gmail ID + Password)
// 1 Gmail से 1 दुकान हो नोंदणी, डबल नाही होणा!
// ==========================================

export function registerDealerWithFpsAndGmail(
  fpsId: string,
  gmailId: string,
  password: string,
  confirmPassword?: string
): { success: boolean; session?: UserSession; message: string } {
  const cleanFps = fpsId.replace(/\D/g, '').trim();
  const cleanGmail = gmailId.trim().toLowerCase();
  const cleanPass = password.trim();

  if (cleanFps.length !== 12) {
    return { success: false, message: 'दुकान आयडी (FPS ID) अचूक १२-अंकी असणे आवश्यक आहे.' };
  }

  if (!cleanGmail || !cleanGmail.includes('@') || !cleanGmail.includes('.')) {
    return { success: false, message: 'कृपया वैध Gmail किंवा ई-मेल आयडी टाका (उदा. user@gmail.com).' };
  }

  if (cleanPass.length < 4) {
    return { success: false, message: 'पासवर्ड किमान ४ अक्षरे किंवा अंकांचा असावा.' };
  }

  if (confirmPassword !== undefined && cleanPass !== confirmPassword.trim()) {
    return { success: false, message: 'पासवर्ड आणि कन्फर्म पासवर्ड जुळत नाहीत.' };
  }

  const accounts = getRegisteredAccounts();

  // 1 GMAIL = 1 SHOP ONLY: "1 gmail से 1 दुकान हो रेजिस्ट्रेशन होणा डबल नहीं होणा"
  const existingByGmail = accounts.find((a) => a.isRegistered && a.gmailId?.toLowerCase() === cleanGmail);
  if (existingByGmail) {
    return {
      success: false,
      message: `⚠️ हा Gmail ID (${cleanGmail}) आधीच दुकान क्र. ${existingByGmail.fpsId} (${existingByGmail.dealerName}) साठी नोंदणीकृत आहे! एका Gmail वर फक्त १ दुकान नोंदणी करता येते. कृपया दुसरा नवीन Gmail ID वापरा.`
    };
  }

  // CHECK DUPLICATE FPS ID:
  const existingByFps = accounts.find((a) => a.isRegistered && a.fpsId === cleanFps);
  if (existingByFps) {
    return {
      success: false,
      message: `⚠️ दुकान क्र. ${cleanFps} आधीपासूनच नोंदणीकृत आहे (${existingByFps.gmailId})! एका दुकानाची दुबार नोंदणी करता येत नाही. कृपया लॉगिन करा किंवा 'पासवर्ड रीसेट करा' वापरा.`
    };
  }

  const shopInfo = lookupShopByFpsId(cleanFps) || {
    dealerName: `रास्त भाव दुकानदार (FPS ${cleanFps.slice(-4)})`,
    totalCards: 500,
    address: 'मेहकर शहर, जि. बुलढाणा',
    aayCards: 78,
    phhCards: 422
  };

  const regTime = new Date().toISOString();
  const trialEnd = new Date(Date.now() + THREE_DAYS_MS).toISOString(); // exactly 3 days free trial

  let updatedAccounts: DealerAccount[];
  const existingIndex = accounts.findIndex((a) => a.fpsId === cleanFps);

  const registeredShopAccount: DealerAccount = {
    fpsId: cleanFps,
    gmailId: cleanGmail,
    password: cleanPass,
    dealerName: shopInfo.dealerName,
    shopAddress: shopInfo.address,
    totalCards: shopInfo.totalCards,
    aayCards: shopInfo.aayCards || 78,
    phhCards: shopInfo.phhCards || 422,
    isRegistered: true,
    registeredAt: regTime,
    trialEndsAt: trialEnd,
    isSubscribed: false,
    subscriptionEndsAt: undefined,
    isActive: true,
    lastLoginAt: regTime,
    payments: existingIndex >= 0 ? accounts[existingIndex].payments || [] : []
  };

  if (existingIndex >= 0) {
    updatedAccounts = [...accounts];
    updatedAccounts[existingIndex] = registeredShopAccount;
  } else {
    updatedAccounts = [...accounts, registeredShopAccount];
  }

  saveRegisteredAccounts(updatedAccounts);

  const session: UserSession = {
    fpsId: cleanFps,
    gmailId: cleanGmail,
    dealerName: registeredShopAccount.dealerName,
    shopAddress: registeredShopAccount.shopAddress,
    totalCards: registeredShopAccount.totalCards,
    loginTime: regTime,
    role: 'dealer',
    registeredAt: registeredShopAccount.registeredAt,
    trialEndsAt: registeredShopAccount.trialEndsAt,
    isSubscribed: false,
    subscriptionEndsAt: undefined,
    isActive: true
  };

  saveCurrentSession(session);

  return {
    success: true,
    session,
    message: `दुकान क्र. ${cleanFps} ची यशस्वी नोंदणी झाली! आपले ३ दिवस मोफत ॲप सुरू झाले आहे.`
  };
}

// ==========================================
// 3. DEALER LOGIN (Gmail ID / FPS ID + Password)
// दुकानदार लॉगिन बिना नोंदणी होणार नाही!
// ==========================================

export function loginDealer(
  identifier: string,
  password: string
): { success: boolean; session?: UserSession; message: string; isDeactivated?: boolean } {
  const cleanId = identifier.trim();
  const cleanPass = password.trim();

  if (!cleanId) {
    return { success: false, message: 'कृपया नोंदणीकृत Gmail ID किंवा १२-अंकी दुकान क्र. (FPS ID) टाका.' };
  }

  if (!cleanPass) {
    return { success: false, message: 'कृपया आपला पासवर्ड टाका.' };
  }

  const accounts = getRegisteredAccounts();
  const isNumericOnly = /^\d+$/.test(cleanId);

  // Match by FPS ID or Gmail ID
  const found = accounts.find((a) => {
    if (isNumericOnly && a.fpsId === cleanId) return true;
    if (a.gmailId?.toLowerCase() === cleanId.toLowerCase()) return true;
    if (a.fpsId === cleanId) return true;
    return false;
  });

  // REQUIRE REGISTRATION FIRST: "दुकानदार लॉगिन बिना रेजिस्ट्रेशन के भी लॉगिन होरा" FIX!
  if (!found || !found.isRegistered) {
    return {
      success: false,
      message: `⚠️ दुकान क्र. किंवा Gmail ID (${cleanId}) अद्याप नोंदणीकृत नाही! कृपया प्रथम "नवीन नोंदणी (Register)" टॅबवर जाऊन आपल्या Gmail आयडीसह अधिकृत नोंदणी करा.`
    };
  }

  // Check Active / Deactive status
  if (found.isActive === false) {
    const recipient = getPaymentRecipient();
    return {
      success: false,
      isDeactivated: true,
      message: `⚠️ आपले आयडी (दुकान क्र. ${found.fpsId}) मालकाद्वारे तात्पुरते निष्क्रिय (Deactivated) केले आहे! कृपया मालकाशी संपर्क साधा (${recipient.payeeName} / WhatsApp: ${recipient.whatsapp || '7709229567'}).`
    };
  }

  // Strict password verification - no master default fallback!
  if (!found.password || found.password !== cleanPass) {
    return {
      success: false,
      message: 'चुकीचा पासवर्ड! कृपया अचूक पासवर्ड टाका किंवा खालील "पासवर्ड रीसेट करा" पर्याय वापरा.'
    };
  }

  found.lastLoginAt = new Date().toISOString();
  saveRegisteredAccounts(accounts);

  const trialEnd = found.trialEndsAt || new Date(Date.now() + THREE_DAYS_MS).toISOString();
  const session: UserSession = {
    fpsId: found.fpsId,
    gmailId: found.gmailId,
    dealerName: found.dealerName,
    shopAddress: found.shopAddress,
    totalCards: found.totalCards,
    loginTime: new Date().toISOString(),
    role: 'dealer',
    registeredAt: found.registeredAt,
    trialEndsAt: trialEnd,
    isSubscribed: found.isSubscribed || false,
    subscriptionEndsAt: found.subscriptionEndsAt,
    isActive: true
  };

  saveCurrentSession(session);

  return {
    success: true,
    session,
    message: `स्वागत आहे, ${found.dealerName}! दुकान क्र. ${found.fpsId} मध्ये यशस्वी लॉगिन.`
  };
}

// ==========================================
// 4. RESET PASSWORD WITH GMAIL OTP
// "पासवर्ड रीसेट करा (Reset Password) मे gmail पर otp आणा फिर reset होणा"
// ==========================================

export function sendPasswordResetOtp(identifier: string): {
  success: boolean;
  message: string;
  email?: string;
  fpsId?: string;
  otp?: string;
} {
  const cleanId = identifier.trim().toLowerCase();
  if (!cleanId) {
    return {
      success: false,
      message: 'कृपया नोंदणीकृत Gmail ID किंवा १२-अंकी दुकान आयडी (FPS ID) प्रविष्ट करा.'
    };
  }

  const accounts = getRegisteredAccounts();
  const isNumericOnly = /^\d+$/.test(cleanId);

  const found = accounts.find((a) => {
    if (!a.isRegistered) return false;
    if (isNumericOnly && a.fpsId === cleanId) return true;
    if (a.gmailId?.toLowerCase() === cleanId) return true;
    if (a.fpsId === cleanId) return true;
    return false;
  });

  if (!found || !found.gmailId) {
    return {
      success: false,
      message: 'हा Gmail ID किंवा दुकान आयडी नोंदणीकृत नाही! कृपया प्रथम "नवीन नोंदणी (Register)" करा.'
    };
  }

  // Generate 6-digit OTP
  const otp = String(Math.floor(100000 + Math.random() * 900000));
  const pendingData = {
    email: found.gmailId,
    fpsId: found.fpsId,
    otp,
    createdAt: Date.now(),
    expiresAt: Date.now() + 10 * 60 * 1000 // 10 minutes
  };

  try {
    localStorage.setItem(STORAGE_KEY_RESET_OTP, JSON.stringify(pendingData));
  } catch (_e) {}

  return {
    success: true,
    email: found.gmailId,
    fpsId: found.fpsId,
    otp,
    message: `आपल्या नोंदणीकृत Gmail (${found.gmailId}) वर ६-अंकी OTP पाठवण्यात आला आहे.`
  };
}

export function verifyOtpAndResetPassword(
  identifier: string,
  enteredOtp: string,
  newPassword: string,
  confirmPassword?: string
): { success: boolean; message: string } {
  const cleanId = identifier.trim().toLowerCase();
  const cleanOtp = enteredOtp.trim();
  const cleanPass = newPassword.trim();

  if (!cleanId) {
    return { success: false, message: 'कृपया नोंदणीकृत Gmail ID किंवा दुकान आयडी प्रविष्ट करा.' };
  }

  if (!cleanOtp) {
    return { success: false, message: 'कृपया Gmail वर आलेला ६-अंकी OTP प्रविष्ट करा.' };
  }

  if (cleanPass.length < 4) {
    return { success: false, message: 'नवीन पासवर्ड किमान ४ अक्षरांचा असावा.' };
  }

  if (confirmPassword !== undefined && cleanPass !== confirmPassword.trim()) {
    return { success: false, message: 'नवीन पासवर्ड आणि पुष्टी पासवर्ड जुळत नाहीत.' };
  }

  let pendingData: any = null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_RESET_OTP);
    if (raw) pendingData = JSON.parse(raw);
  } catch (_e) {}

  if (!pendingData) {
    return {
      success: false,
      message: 'प्रथम "Gmail वर OTP पाठवा" बटणावर क्लिक करून OTP मिळवा.'
    };
  }

  if (Date.now() > pendingData.expiresAt) {
    return {
      success: false,
      message: 'सदर OTP कालबाह्य (Expired) झाला आहे. कृपया नवीन OTP पाठवा.'
    };
  }

  if (cleanOtp !== pendingData.otp) {
    return {
      success: false,
      message: 'चुकीचा OTP! कृपया आपल्या Gmail वर आलेला अचूक ६-अंकी OTP टाका.'
    };
  }

  // Find account and update password
  const accounts = getRegisteredAccounts();
  const isNumericOnly = /^\d+$/.test(cleanId);
  const foundIndex = accounts.findIndex((a) => {
    if (!a.isRegistered) return false;
    if (isNumericOnly && a.fpsId === cleanId) return true;
    if (a.gmailId?.toLowerCase() === cleanId) return true;
    if (a.fpsId === cleanId) return true;
    if (a.fpsId === pendingData.fpsId || a.gmailId?.toLowerCase() === pendingData.email?.toLowerCase()) return true;
    return false;
  });

  if (foundIndex === -1) {
    return { success: false, message: 'नोंदणीकृत खाते आढळले नाही.' };
  }

  accounts[foundIndex].password = cleanPass;
  saveRegisteredAccounts(accounts);

  try {
    localStorage.removeItem(STORAGE_KEY_RESET_OTP);
  } catch (_e) {}

  return {
    success: true,
    message: `दुकान क्र. ${accounts[foundIndex].fpsId} चा पासवर्ड यशस्वीरीत्या रीसेट करण्यात आला आहे! आता नवीन पासवर्डने लॉगिन करा.`
  };
}

export function resetDealerPassword(
  identifier: string,
  newPassword: string,
  confirmPassword?: string
): { success: boolean; message: string } {
  const cleanId = identifier.trim();
  const cleanPass = newPassword.trim();

  if (!cleanId) {
    return { success: false, message: 'कृपया Gmail ID किंवा १२-अंकी दुकान आयडी प्रविष्ट करा.' };
  }

  if (cleanPass.length < 4) {
    return { success: false, message: 'नवीन पासवर्ड किमान ४ अक्षरे किंवा अंकांचा असावा.' };
  }

  if (confirmPassword !== undefined && cleanPass !== confirmPassword.trim()) {
    return { success: false, message: 'दोन्ही पासवर्ड जुळत नाहीत.' };
  }

  const accounts = getRegisteredAccounts();
  const isNumericOnly = /^\d+$/.test(cleanId);

  const foundIndex = accounts.findIndex((a) => {
    if (!a.isRegistered) return false;
    if (isNumericOnly && a.fpsId === cleanId) return true;
    if (a.gmailId?.toLowerCase() === cleanId.toLowerCase()) return true;
    if (a.fpsId === cleanId) return true;
    return false;
  });

  if (foundIndex === -1) {
    return {
      success: false,
      message: 'हा Gmail ID किंवा दुकान आयडी नोंदणीकृत नाही! कृपया प्रथम नोंदणी करा.'
    };
  }

  accounts[foundIndex].password = cleanPass;
  saveRegisteredAccounts(accounts);

  return {
    success: true,
    message: `दुकान क्र. ${accounts[foundIndex].fpsId} चा पासवर्ड यशस्वीरीत्या रीसेट करण्यात आला आहे! आता नवीन पासवर्डने लॉगिन करा.`
  };
}

// ==========================================
// 5. OWNER CONTROL: ACTIVE / DEACTIVE TOGGLE
// ==========================================

export function setAccountActiveStatus(
  fpsId: string,
  isActive: boolean,
  statusNote?: string
): { success: boolean; updatedAccount?: DealerAccount; message: string } {
  const cleanFps = fpsId.trim();
  const accounts = getRegisteredAccounts();
  const index = accounts.findIndex((a) => a.fpsId === cleanFps);

  if (index === -1) {
    return { success: false, message: `दुकान क्र. ${cleanFps} आढळले नाही.` };
  }

  accounts[index].isActive = isActive;
  if (statusNote !== undefined) {
    accounts[index].statusNote = statusNote;
  }
  saveRegisteredAccounts(accounts);

  // If current session belongs to this shop and is deactivated, update session flag
  const currentSession = getCurrentSession();
  if (currentSession && currentSession.fpsId === cleanFps) {
    currentSession.isActive = isActive;
    saveCurrentSession(currentSession);
  }

  const actionText = isActive ? 'सक्रिय (Active)' : 'निष्क्रिय (Deactivated)';
  return {
    success: true,
    updatedAccount: accounts[index],
    message: `दुकान क्र. ${cleanFps} (${accounts[index].dealerName}) चे आयडी आता ${actionText} केले आहे.`
  };
}

export function toggleAccountActiveStatus(fpsId: string): { success: boolean; isActive: boolean; message: string } {
  const accounts = getRegisteredAccounts();
  const found = accounts.find((a) => a.fpsId === fpsId.trim());
  if (!found) {
    return { success: false, isActive: false, message: 'दुकान सापडले नाही.' };
  }
  const nextStatus = !found.isActive;
  const res = setAccountActiveStatus(fpsId, nextStatus);
  return {
    success: res.success,
    isActive: nextStatus,
    message: res.message
  };
}

// ==========================================
// 6. OWNER CONTROL: EDIT ALL DATA
// ==========================================

export function updateDealerAccount(
  fpsId: string,
  updates: Partial<DealerAccount>
): { success: boolean; updatedAccount?: DealerAccount; message: string } {
  const cleanFps = fpsId.trim();
  const accounts = getRegisteredAccounts();
  const index = accounts.findIndex((a) => a.fpsId === cleanFps);

  if (index === -1) {
    return { success: false, message: `दुकान क्र. ${cleanFps} आढळले नाही.` };
  }

  const existing = accounts[index];
  const updated: DealerAccount = {
    ...existing,
    ...updates,
    fpsId: cleanFps // prevent accidental key corruption
  };

  accounts[index] = updated;
  saveRegisteredAccounts(accounts);

  // If current active session is this dealer, update session too
  const currentSession = getCurrentSession();
  if (currentSession && currentSession.fpsId === cleanFps) {
    const updatedSession: UserSession = {
      ...currentSession,
      dealerName: updated.dealerName,
      shopAddress: updated.shopAddress,
      totalCards: updated.totalCards,
      isSubscribed: updated.isSubscribed,
      subscriptionEndsAt: updated.subscriptionEndsAt,
      gmailId: updated.gmailId,
      isActive: updated.isActive
    };
    saveCurrentSession(updatedSession);
  }

  return {
    success: true,
    updatedAccount: updated,
    message: `दुकान क्र. ${cleanFps} ची सर्व माहिती यशस्वीरीत्या अपडेट केली गेली!`
  };
}

// ==========================================
// 7. OWNER CONTROL: VIEW & MANAGE ALL PAYMENTS
// ==========================================

export function getAllPayments(): PaymentRecord[] {
  const accounts = getRegisteredAccounts();
  const all: PaymentRecord[] = [];
  const seenIds = new Set<string>();
  const seenUtrs = new Set<string>();

  const addUnique = (p: PaymentRecord) => {
    if (!p) return;
    // Filter out dummy demo seeded payments
    if (p.id?.startsWith('pay-seed-') || (p.utr && p.utr.startsWith('234567') && p.utr.length > 10)) {
      return;
    }
    if (p.id) {
      if (seenIds.has(p.id)) return;
      seenIds.add(p.id);
    }
    if (p.utr) {
      const utrKey = `${p.fpsId}_${p.utr}`;
      if (seenUtrs.has(utrKey)) return;
      seenUtrs.add(utrKey);
    } else if (!p.id) {
      const fallbackKey = `${p.fpsId}_${p.date}_${p.amount}`;
      if (seenIds.has(fallbackKey)) return;
      seenIds.add(fallbackKey);
    }
    all.push(p);
  };

  // Standalone payments key
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ALL_PAYMENTS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        parsed.forEach(addUnique);
      }
    }
  } catch (_e) {}

  // Aggregate payments stored inside dealer accounts
  accounts.forEach((acc) => {
    if (acc.payments && Array.isArray(acc.payments)) {
      acc.payments.forEach((p) => {
        addUnique({
          ...p,
          dealerName: p.dealerName || acc.dealerName,
          gmailId: p.gmailId || acc.gmailId,
          mobileNumber: p.mobileNumber || acc.mobileNumber
        });
      });
    }
  });

  // Sort descending by date
  const sorted = all.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Clean up any duplicates or removed seeds in localStorage
  try {
    saveAllPayments(sorted);
  } catch (_e) {}

  return sorted;
}

export function saveAllPayments(payments: PaymentRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_ALL_PAYMENTS, JSON.stringify(payments));
  } catch (_e) {}
}

/**
 * Owner Control: Edit any payment record (Change Payer Name, Real UTR, Amount, Assigned Shop/FPS ID, Status, Months)
 */
export function updatePaymentRecord(
  paymentId: string,
  updates: {
    dealerName?: string;
    utr?: string;
    amount?: number;
    fpsId?: string;
    status?: 'SUCCESS' | 'PENDING' | 'REJECTED';
    method?: 'UPI' | 'CASH';
    date?: string;
    planDurationMonths?: number;
    rejectedReason?: string;
  }
): { success: boolean; message: string } {
  const accounts = getRegisteredAccounts();
  const all = getAllPayments();
  const payIndex = all.findIndex((p) => p.id === paymentId || (updates.utr && p.utr === updates.utr));

  const existingPayment = payIndex >= 0 ? all[payIndex] : null;
  const targetFps = (updates.fpsId || existingPayment?.fpsId || '').trim();

  // Look up shop info for targetFps
  const matchedShop = lookupShopByFpsId(targetFps);

  const updatedRecord: PaymentRecord = {
    id: paymentId || generatePaymentId(),
    utr: updates.utr ? updates.utr.trim() : (existingPayment?.utr || `REAL-${Date.now().toString().slice(-6)}`),
    amount: updates.amount !== undefined ? Number(updates.amount) : (existingPayment?.amount || 100),
    date: updates.date || existingPayment?.date || new Date().toISOString(),
    status: updates.status || existingPayment?.status || 'SUCCESS',
    method: updates.method || existingPayment?.method || 'UPI',
    fpsId: targetFps,
    dealerName: (updates.dealerName || existingPayment?.dealerName || matchedShop?.dealerName || '').trim(),
    gmailId: existingPayment?.gmailId || `dealer${targetFps.slice(-3)}@gmail.com`,
    mobileNumber: existingPayment?.mobileNumber || '',
    planDurationMonths: updates.planDurationMonths || existingPayment?.planDurationMonths || 1,
    rejectedReason: updates.status === 'REJECTED' ? (updates.rejectedReason || 'नाकारले') : undefined,
    approvedAt: updates.status === 'SUCCESS' ? (existingPayment?.approvedAt || new Date().toISOString()) : undefined
  };

  // Update global list
  let updatedGlobal: PaymentRecord[];
  if (payIndex >= 0) {
    updatedGlobal = all.map((p) => (p.id === paymentId || p.utr === existingPayment?.utr ? updatedRecord : p));
  } else {
    updatedGlobal = [updatedRecord, ...all];
  }
  saveAllPayments(updatedGlobal);

  // Update inside account records
  const durationMonths = updatedRecord.planDurationMonths || 1;
  const newSubEnd = new Date(Date.now() + durationMonths * 30 * 86400000).toISOString();

  const updatedAccounts = accounts.map((acc) => {
    // Remove old instance of this payment
    let pList = (acc.payments || []).filter((p) => p.id !== paymentId && (!existingPayment?.utr || p.utr !== existingPayment.utr));

    if (acc.fpsId === targetFps) {
      pList.unshift(updatedRecord);
      const isApproved = updatedRecord.status === 'SUCCESS';
      return {
        ...acc,
        payments: pList,
        isSubscribed: isApproved ? true : acc.isSubscribed,
        subscriptionEndsAt: isApproved ? newSubEnd : acc.subscriptionEndsAt
      };
    }
    return { ...acc, payments: pList };
  });
  saveRegisteredAccounts(updatedAccounts);

  // Sync active session if currently logged in dealer matches
  const currentSession = getCurrentSession();
  if (currentSession && currentSession.fpsId === targetFps && updatedRecord.status === 'SUCCESS') {
    currentSession.isSubscribed = true;
    currentSession.subscriptionEndsAt = newSubEnd;
    saveCurrentSession(currentSession);
  }

  return {
    success: true,
    message: `पेमेंट माहिती (खातेदार/Payer: ${updatedRecord.dealerName}, UTR: ${updatedRecord.utr}, ₹${updatedRecord.amount}) यशस्वीरीत्या अपडेट झाली!`
  };
}

/**
 * Owner Control: Delete any payment record
 */
export function deletePaymentRecord(paymentId: string): { success: boolean; message: string } {
  const accounts = getRegisteredAccounts();
  const all = getAllPayments();

  const targetPayment = all.find((p) => p.id === paymentId);
  const newAll = all.filter((p) => p.id !== paymentId);
  saveAllPayments(newAll);

  const newAccs = accounts.map((acc) => ({
    ...acc,
    payments: (acc.payments || []).filter((p) => p.id !== paymentId && (!targetPayment?.utr || p.utr !== targetPayment.utr))
  }));
  saveRegisteredAccounts(newAccs);

  return {
    success: true,
    message: 'पेमेंट नोंद यशस्वीरीत्या हटवली गेली.'
  };
}

export function approvePayment(
  fpsId: string,
  utr: string
): { success: boolean; message: string } {
  const accounts = getRegisteredAccounts();
  const accIndex = accounts.findIndex((a) => a.fpsId === fpsId.trim());

  const now = new Date().toISOString();
  const newSubEnd = new Date(Date.now() + THIRTY_DAYS_MS).toISOString();

  let foundPayment = false;

  if (accIndex >= 0) {
    const acc = accounts[accIndex];
    acc.isSubscribed = true;
    acc.subscriptionEndsAt = newSubEnd;
    if (acc.payments) {
      acc.payments = acc.payments.map((p) => {
        if (p.utr === utr) {
          foundPayment = true;
          return { ...p, status: 'SUCCESS', approvedAt: now };
        }
        return p;
      });
    }
    saveRegisteredAccounts(accounts);
  }

  // Also update global payments store
  const globalPayments = getAllPayments().map((p) => {
    if (p.utr === utr && p.fpsId === fpsId.trim()) {
      return { ...p, status: 'SUCCESS' as const, approvedAt: now };
    }
    return p;
  });
  saveAllPayments(globalPayments);

  // Sync session if currently logged in
  const currentSession = getCurrentSession();
  if (currentSession && currentSession.fpsId === fpsId.trim()) {
    currentSession.isSubscribed = true;
    currentSession.subscriptionEndsAt = newSubEnd;
    saveCurrentSession(currentSession);
  }

  return {
    success: true,
    message: `पेमेंट (UTR: ${utr}) यशस्वीरीत्या मंजूर (Approved) करण्यात आले! दुकान क्र. ${fpsId} चे ३० दिवसांचे ॲक्सेस सक्रिय झाले.`
  };
}

export function rejectPayment(
  fpsId: string,
  utr: string,
  reason: string = 'बँक खात्यात रक्कम जमा झालेली नाही'
): { success: boolean; message: string } {
  const accounts = getRegisteredAccounts();
  const accIndex = accounts.findIndex((a) => a.fpsId === fpsId.trim());

  if (accIndex >= 0) {
    const acc = accounts[accIndex];
    if (acc.payments) {
      acc.payments = acc.payments.map((p) => {
        if (p.utr === utr) {
          return { ...p, status: 'REJECTED', rejectedReason: reason };
        }
        return p;
      });
    }
    saveRegisteredAccounts(accounts);
  }

  const globalPayments = getAllPayments().map((p) => {
    if (p.utr === utr && p.fpsId === fpsId.trim()) {
      return { ...p, status: 'REJECTED' as const, rejectedReason: reason };
    }
    return p;
  });
  saveAllPayments(globalPayments);

  return {
    success: true,
    message: `पेमेंट (UTR: ${utr}) नाकारण्यात आले. कारण: ${reason}`
  };
}

export function addManualPayment(
  fpsId: string,
  amount: number,
  method: 'CASH' | 'UPI' = 'UPI',
  utr: string,
  durationMonths: number = 1
): { success: boolean; message: string } {
  const cleanFps = fpsId.trim();
  const accounts = getRegisteredAccounts();
  const accIndex = accounts.findIndex((a) => a.fpsId === cleanFps);

  if (accIndex === -1) {
    return { success: false, message: `दुकान क्र. ${cleanFps} आढळले नाही.` };
  }

  const acc = accounts[accIndex];
  const validityDays = durationMonths * 30;
  const newSubEnd = new Date(Date.now() + validityDays * 86400000).toISOString();
  const now = new Date().toISOString();

  const uniqueId = generatePaymentId();
  const newRecord: PaymentRecord = {
    id: uniqueId,
    utr: utr || `MANUAL-${Date.now().toString().slice(-6)}`,
    amount,
    date: now,
    status: 'SUCCESS',
    method,
    fpsId: cleanFps,
    dealerName: acc.dealerName,
    gmailId: acc.gmailId,
    planDurationMonths: durationMonths,
    approvedAt: now
  };

  acc.isSubscribed = true;
  acc.subscriptionEndsAt = newSubEnd;
  acc.payments = [
    newRecord,
    ...(acc.payments || []).filter((p) => p.id !== uniqueId && (p.utr !== newRecord.utr || !newRecord.utr))
  ];
  saveRegisteredAccounts(accounts);

  const existingPayments = getAllPayments().filter(
    (p) => p.id !== uniqueId && (p.utr !== newRecord.utr || !newRecord.utr)
  );
  const globalPayments = [newRecord, ...existingPayments];
  saveAllPayments(globalPayments);

  return {
    success: true,
    message: `दुकान क्र. ${cleanFps} साठी ₹${amount} चे मॅन्युअल पेमेंट यशस्वी नोंदवले गेले! पुढील ${validityDays} दिवस वर्गणी सक्रिय.`
  };
}

// ==========================================
// 8. SUBSCRIPTION PAYMENT SUBMISSION
// ==========================================

export function recordSubscriptionPayment(
  fpsId: string,
  utrNumber: string,
  amount: number = 100
): { success: boolean; session?: UserSession; message: string; isPendingVerification?: boolean } {
  const cleanUtr = utrNumber.replace(/\D/g, '').trim();

  // Strict 12-digit Indian banking UPI UTR validation
  if (cleanUtr.length !== 12) {
    return {
      success: false,
      message: 'कृपया बँकेच्या UPI ॲपमधील (PhonePe/GPay/Paytm) अचूक १२-अंकी UTR किंवा ट्रान्झॅक्शन आयडी प्रविष्ट करा.'
    };
  }

  // Detect and reject repetitive dummy numbers
  const isRepetitive = /^(\d)\1{11}$/.test(cleanUtr) || cleanUtr === '123456789012' || cleanUtr === '987654321098' || cleanUtr === '012345678901' || cleanUtr === '000000000000';
  if (isRepetitive) {
    return {
      success: false,
      message: 'हा बनावट किंवा काल्पनिक UTR क्रमांक आहे! कृपया बँक ॲपमधील प्रत्यक्ष ₹१०० पाठवल्याच्या पावतीवरील खरा १२-अंकी UTR क्रमांक टाका.'
    };
  }

  const accounts = getRegisteredAccounts();
  const accIndex = accounts.findIndex((a) => a.fpsId === fpsId.trim());

  // Check if this UTR was already submitted
  if (accIndex >= 0 && accounts[accIndex].payments?.some((p) => p.utr === cleanUtr)) {
    return {
      success: false,
      message: `सदर UTR क्रमांक (${cleanUtr}) आधीच नोंदवला गेला आहे. बँक खात्यात रक्कम जमा झाल्याची पडताळणी मालकाकडून सुरू आहे.`
    };
  }

  const paymentId = generatePaymentId();
  const payment: PaymentRecord = {
    id: paymentId,
    utr: cleanUtr,
    amount,
    date: new Date().toISOString(),
    status: 'PENDING',
    method: 'UPI',
    fpsId: fpsId.trim(),
    dealerName: accounts[accIndex]?.dealerName || '',
    gmailId: accounts[accIndex]?.gmailId || '',
    mobileNumber: accounts[accIndex]?.mobileNumber || '',
    planDurationMonths: 1
  };

  if (accIndex >= 0) {
    accounts[accIndex].lastPaymentRef = cleanUtr;
    accounts[accIndex].payments = [
      payment,
      ...(accounts[accIndex].payments || []).filter((p) => p.utr !== cleanUtr && p.id !== paymentId)
    ];
    saveRegisteredAccounts(accounts);
  }

  const existingPayments = getAllPayments().filter(
    (p) => p.utr !== cleanUtr && p.id !== paymentId
  );
  const globalPayments = [payment, ...existingPayments];
  saveAllPayments(globalPayments);

  const current = getCurrentSession();

    const recipient = getPaymentRecipient();

    return {
      success: true,
      isPendingVerification: true,
      session: current || undefined,
      message: `UTR क्रमांक ${cleanUtr} नोंदवला गेला आहे! खातेदार ${recipient.payeeName} (UPI: ${recipient.upiId}) यांच्या बँक खात्यात ₹${amount} जमा झाल्याची मालकाकडून पडताळणी सुरू आहे. मालकाने मंजुरी दिल्यानंतर ॲक्सेस निश्चित केले जाईल.`
    };
  }

// ==========================================
// 9. SUBSCRIPTION STATUS HELPER
// ==========================================

export function getSubscriptionStatus(session: UserSession | null = getCurrentSession()): {
    isFreeTrial: boolean;
    trialDaysLeft: number;
    trialHoursLeft: number;
    isPaidSubscribed: boolean;
    paidDaysLeft: number;
    isActive: boolean;
    statusLabel: string;
  } {
    if (!session) {
      return {
        isFreeTrial: false,
        trialDaysLeft: 0,
        trialHoursLeft: 0,
        isPaidSubscribed: false,
        paidDaysLeft: 0,
        isActive: false,
        statusLabel: 'लॉगिन आवश्यक'
      };
    }

    // Owner has perpetual lifetime access
    if (session.role === 'owner') {
      return {
        isFreeTrial: false,
        trialDaysLeft: 365,
        trialHoursLeft: 8760,
        isPaidSubscribed: true,
        paidDaysLeft: 365,
        isActive: true,
        statusLabel: '👑 मालक / सुपर ॲडमिन (पूर्ण ॲक्सेस)'
      };
    }

    const nowMs = Date.now();

    // 1. Check Paid Subscription
    if (session.isSubscribed && session.subscriptionEndsAt) {
      const endMs = new Date(session.subscriptionEndsAt).getTime();
      if (endMs > nowMs) {
        const daysLeft = Math.ceil((endMs - nowMs) / (24 * 60 * 60 * 1000));
        return {
          isFreeTrial: false,
          trialDaysLeft: 0,
          trialHoursLeft: 0,
          isPaidSubscribed: true,
          paidDaysLeft: daysLeft,
          isActive: true,
          statusLabel: `मासिक वर्गणी सक्रिय (${daysLeft} दिवस शिल्लक)`
        };
      }
    }

    // 2. Check 3-Day Free Trial (Strictly calculated from registration time, MAX 3 days!)
    let regMs = session.registeredAt ? new Date(session.registeredAt).getTime() : 0;
    if (isNaN(regMs) || regMs <= 0) {
      // Look up account registration time from stored accounts
      const accounts = getRegisteredAccounts();
      const matched = accounts.find((a) => a.fpsId === session.fpsId);
      if (matched && matched.registeredAt) {
        regMs = new Date(matched.registeredAt).getTime();
      }
    }

    if (regMs > 0 && !isNaN(regMs)) {
      const elapsedMs = nowMs - regMs;
      // Active ONLY if within 3 days (72 hours) of registration:
      if (elapsedMs >= 0 && elapsedMs < THREE_DAYS_MS) {
        const msLeft = THREE_DAYS_MS - elapsedMs;
        const totalHoursLeft = Math.max(1, Math.ceil(msLeft / (60 * 60 * 1000)));
        const fullDaysLeft = Math.floor(msLeft / (24 * 60 * 60 * 1000));
        const remHours = Math.floor((msLeft % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
        const displayDaysLeft = Math.max(1, Math.min(3, Math.ceil(msLeft / (24 * 60 * 60 * 1000))));

        let countdownText = '';
        if (fullDaysLeft >= 1) {
          countdownText = `${fullDaysLeft} दिवस ${remHours} तास शिल्लक`;
        } else {
          countdownText = `${totalHoursLeft} तास शिल्लक (आज शेवटचा दिवस)`;
        }

        return {
          isFreeTrial: true,
          trialDaysLeft: displayDaysLeft,
          trialHoursLeft: totalHoursLeft,
          isPaidSubscribed: false,
          paidDaysLeft: 0,
          isActive: true,
          statusLabel: `३ दिवस मोफत चाचणी (${countdownText})`
        };
      }
    }

    // 3. Trial Expired & Not Subscribed (payment नहीं किया तो trial समाप्त)
    return {
      isFreeTrial: false,
      trialDaysLeft: 0,
      trialHoursLeft: 0,
      isPaidSubscribed: false,
      paidDaysLeft: 0,
      isActive: false,
      statusLabel: '३ दिवसांची मोफत चाचणी समाप्त (₹१००/महिना वर्गणी आवश्यक)'
    };
  }

export function getCurrentSession(): UserSession | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SESSION);
    if (raw) {
      const session = JSON.parse(raw);
      // Double check active status and sync with registered accounts store
      if (session.role === 'dealer' && session.fpsId) {
        const accounts = getRegisteredAccounts();
        const acc = accounts.find((a) => a.fpsId === session.fpsId);
        if (acc) {
          session.isActive = acc.isActive !== false;
          session.isSubscribed = !!acc.isSubscribed;
          session.subscriptionEndsAt = acc.subscriptionEndsAt;
          session.registeredAt = acc.registeredAt || session.registeredAt;
          session.trialEndsAt = acc.trialEndsAt;
          session.isRegistered = acc.isRegistered;
        }
      }
      return session;
    }
  } catch (_e) {}
  return null;
}

export function saveCurrentSession(session: UserSession): void {
  try {
    localStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(session));
  } catch (_e) {}
}

export function logoutDealer(): void {
  try {
    localStorage.removeItem(STORAGE_KEY_SESSION);
  } catch (_e) {}
}
